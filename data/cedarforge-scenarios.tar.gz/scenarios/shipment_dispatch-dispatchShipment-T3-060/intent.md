# Shipment Dispatch

## Natural-Language Scenario

The system manages carrier shipment dispatch and delivery confirmation.

The people involved are planners, drivers, dispatch managers, depot supervisors, and auditors. One person may hold both the planner and dispatch manager role at the same time.

The resources are shipments and delivery receipts. Every shipment records its planner, driver of record, piece count, gross weight in kilograms, status, tracking code, origin depot, hazmat class, and delivery window end.

Each request carries the current time, whether it is on the depot network, whether expedite handling was declared, and proof of delivery.

A driver or dispatch manager may dispatch a shipment.

When a shipment's tracking code carries the assigned carrier prefix and its piece count crosses the threshold requiring elevated authority, the person who planned the shipment may not be its driver of record who dispatches it.

For shipments whose tracking code does not carry the assigned carrier prefix or whose piece count does not cross the elevated-authority threshold, that planner-driver restriction does not apply.

Neither a driver nor a dispatch manager may dispatch a shipment as the driver of record when they also planned that shipment and both limiting conditions apply.

A request by a driver to dispatch a shipment that does not trip any prohibition above must be able to succeed.
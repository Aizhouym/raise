# Clinical Lab Result Release

## Natural-Language Scenario

The system manages clinical lab results and critical-value acknowledgement.

The people involved are medical technologists, pathologists, ordering providers, and the lab director. One person may hold both the pathologist and ordering provider roles, or both the medical technologist and pathologist roles.

The resources are lab results and lab orders. Every lab result records its patient, ordering provider, verifier, sensitivity, critical flag, portal release time, and status.

Each requester carries a credential level.

Each request carries the current time, whether MFA was used, whether it came from the hospital network, whether emergency release was requested, and whether coverage was authorized.

An ordering provider may acknowledge a critical lab result.

When a lab result carries a critical-value flag and MFA was not used, it may be acknowledged only while the result is on critical hold.

When a lab result does not carry a critical-value flag, the critical-hold requirement does not apply.

When MFA was used, the critical-hold requirement does not apply.

An ordering provider must not acknowledge a flagged critical lab result that is not on critical hold when MFA was not used.

A request by an ordering provider to acknowledge a critical lab result that does not trip any prohibition above must be able to succeed.
# Cloud Resource Modification — Ownership, Org Scope, Tagging, and Break-Glass Override

## Natural-Language Scenario

The system manages access control for cloud infrastructure resources on a cloud platform.

The people involved are owners, developers, operators, and org admins, and one person may hold both the owner and developer roles at the same time.

The resources are cloud resources and secrets; every cloud resource records its owner, its org unit, its tags, its environment, and any temporary grant applied to it, every secret records the cloud resource it belongs to and when it was last rotated, and every org unit records its parent org unit.

Each request carries the source IP address it came from, whether the session used multi-factor authentication, and how long the current session has been active.

An owner, a developer, or an operator may modify a cloud resource.

A cloud resource outside the production environment may be modified freely, but a cloud resource in the production environment may not be modified unless it has been promoted for production changes.

A cloud resource may be modified only when the requester is that resource's owner.

A cloud resource may be modified only when the requester belongs to the org unit that the resource is under.

A cloud resource may be modified only when the resource carries the change-approved tag.

A developer who is not also the resource's owner, and an operator, must not modify a cloud resource.

When a cloud resource carries an active temporary break-glass grant, that grant overrides the production restriction, allowing the resource to be modified in production even though it has not been promoted.

A request by an owner to modify a resource that does not trip any of the restrictions above must be able to succeed.

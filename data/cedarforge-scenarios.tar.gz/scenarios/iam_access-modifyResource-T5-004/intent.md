# Cloud Resource Modification — Environment, Org Unit, Tag, and MFA Gating

## Natural-Language Scenario

This system controls who may modify cloud resources on a cloud infrastructure platform.

The people involved are owners, developers, operators, and org admins, and one person may hold both the owner and developer roles at the same time.

The resources are cloud resources, secrets, and org units; a cloud resource records its owner, the org unit it belongs under, its tags, its environment, and any temporary grant placed on it, a secret records the cloud resource it belongs to and when it was last rotated, and an org unit records its parent org unit.

Each request carries the source IP address it came from, whether multi-factor authentication was used, and how long the current session has been open.

An owner, a developer, or an operator may modify a cloud resource only when the resource's environment is set to something other than production.

If the resource is running in the production environment, modification is not allowed unless the resource carries the promoted tag, in which case it may still be modified while in production.

A modification may proceed only when the requester is a member of the same org unit that the resource belongs under; a requester who is not a member of that org unit may not modify the resource.

A modification may proceed only when the resource carries the change-approved tag; a resource without that tag may not be modified.

A modification may proceed only when the request shows that multi-factor authentication was used; if multi-factor authentication was not used, the modification may not proceed.

A break-glass temporary grant recorded on the resource overrides the production restriction, so when a resource has an active temporary grant, that grant wins over the production restriction and the resource may be modified in production even without the promoted tag.

Owners, developers, and operators must not modify a cloud resource when any of the org unit, tag, MFA, or environment requirements is unmet and no temporary grant is active, regardless of which of the three roles is making the request.

A request by an owner to modify a resource that meets the org unit, tag, and MFA requirements and is outside production must be able to succeed.

# Ad Campaign Budget Approval — Separation of Duty and Tier Sign-off

## Natural-Language Scenario

The system manages campaign budget approval and creative review for an advertising agency.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors. One person may hold both the account manager and campaign director roles at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, the manager who prepared it, its budget, its contingency amount, its budget tier, its risk labels, its scheduled start time, and its status.

Every creative records its campaign, the person who submitted it, its risk rating, its content tags, and its status.

An account manager or a campaign director may approve a campaign's budget.

The manager who prepared a campaign may not approve its budget once the combined budget and contingency amount crosses $500,000.

When the combined budget and contingency amount is $500,000 or less, the manager who prepared the campaign may approve its own budget.

An account manager may not approve the budget of a campaign whose budget tier is enterprise; approval of an enterprise-tier budget requires a campaign director's sign-off.

For campaigns at the standard or premium budget tier, an account manager may approve the budget without a campaign director's sign-off.

Neither an account manager nor a campaign director may approve the budget of a campaign that they personally prepared once its combined budget and contingency amount crosses $500,000.

A request by a campaign director to approve the budget of a $600,000 enterprise-tier campaign that the director did not prepare must be able to succeed.

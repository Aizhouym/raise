# Switching Order Execution

## Natural-Language Scenario

The system manages grid switching order authorization and field execution.

The people involved are planners, shift supervisors, operators, control room operators, and auditors. One person may hold both the planner and shift supervisor roles, and one person may hold both the operator and control room operator roles.

The resources are switching orders and lockout tags. Every switching order records its planner, executor, feeder, voltage level, circuit count, status, scheduled start, and scheduled end.

Each request carries the current time, whether it is on the SCADA network, whether lockout-tagout has been verified, and whether an outage emergency has been declared.

When a switching order crosses the circuit-count threshold requiring control-room handling, the order may be executed only after it has been authorized.

When a switching order does not cross that threshold, this authorization requirement does not bind the execution request.

If lockout-tagout tags are confirmed in place before switching is executed, the authorization requirement is relaxed.

If lockout-tagout tags are not confirmed in place, neither an operator nor a control room operator may execute a threshold-crossing switching order before it has been authorized.

A request by an operator to execute a switching order that does not trip any prohibition above must be able to succeed.
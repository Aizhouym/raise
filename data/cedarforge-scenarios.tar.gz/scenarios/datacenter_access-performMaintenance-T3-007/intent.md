# Datacenter Cage Physical Access

## Natural-Language Scenario

The system manages physical cage access and maintenance work in a datacenter.

The people involved are facility techs, tenant engineers, security ops staff, and escorts. One person may hold both the facility tech and escort role at the same time.

The resources are cages, work orders, and access badges. Every cage records its tenant, zone clearance, occupant list, site zone, whether an escort is required, and its status.

Every work order records its cage, who raised it, who approved it, and its status.

Every access badge records its holder and when it expires.

Each requester carries a clearance level and membership information.

Each request carries the current time, whether an escort is present, whether the request is within a maintenance window, and whether it comes from the on-site network.

A facility tech or tenant engineer who raised a work order may perform maintenance only after that work order has been approved.

A facility tech or tenant engineer who did not raise the work order is not bound by that approval requirement.

During a maintenance window, a facility tech or tenant engineer who raised the work order may perform maintenance only after that work order has been approved.

Outside a maintenance window, that approval requirement does not apply.

A facility tech or tenant engineer who raised the work order must not perform maintenance during a maintenance window before that work order has been approved.

A request by a facility tech to perform maintenance that does not trip any prohibition above must be able to succeed.
# Grade Entry then Grade Release

## Natural-Language Scenario

The system manages course grading in a learning-management system, from entering a grade through releasing it.
The people involved are instructors of record, teaching assistants, learners, and coordinators, and one person may hold both the instructor of record and teaching assistant role at the same time.
The resources are modules and grade entries, and every module records its course, its instructor of record, its roster, its prerequisite level, its release time, whether it is locked, and its status.
Every grade entry records its learner, its module, who posted it, and its status.
Each request carries the current time, whether the request is on the institution network, and whether it falls in the preview window.
In this workflow a grade is first entered and then released, and the release step can see the grade entry's status and who posted it as recorded by the entry step.
An instructor of record or teaching assistant may enter a grade, but a grader may not enter a grade for their own enrollment in the module.
That bar on grading one's own enrollment is lifted when the grader holds the instructor-of-record role, who may enter it, and it stands for a teaching assistant grading their own enrollment.
An instructor of record or teaching assistant may enter a grade only when the request is on the institution network, and a request to enter a grade from off the institution network is refused.
Neither an instructor of record nor a teaching assistant may enter a grade from off the institution network.
An instructor of record may release a grade only when they are the same person who posted it, and a release by an instructor who did not post the grade is refused.
That poster-must-release requirement is relaxed when the request is on the institution network, in which case another instructor of record may release it, and it binds when the request is off the institution network.
A run through the workflow in which an instructor of record enters a grade on the institution network for a learner other than themselves and then releases that grade, tripping no prohibition above, must be able to succeed.

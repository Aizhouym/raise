# Approving Invoices and Issuing Payments, With Bypasses for Large Invoices

## Natural-Language Scenario

This document sets out who may approve an invoice and then issue its payment in our invoice approval and payment system.
The people involved are clerks, approvers, finance managers, and auditors, and one person may act as both a clerk and an approver at the same time.
The records involved are the invoice, which notes its creator, its approver, its amount, its surcharge, its line-item count, its status, its cost center, and when it was submitted; and the payment, which notes its invoice, its issuer, and its amount.
Each request carries the current time, whether it comes from the corporate network, and whether an emergency has been declared.
An invoice is approved first and its payment is issued afterward, both against the same invoice, and the payment step can see the status the approval step left, who created the invoice, and who approved it.
When an invoice is approved, it may be approved only after it has been submitted.
However, an invoice whose line-item count crosses the set threshold may be approved even before it has been submitted.
When a payment is issued, it may be issued only for an invoice that has been approved.
However, a payment may be issued for an invoice that carries a recorded approver even if that invoice has not otherwise been marked approved.
An invoice may be approved only by an approver or a finance manager, so a clerk or an auditor must not approve one.
A run through the workflow by an approver that trips none of the prohibitions above must be able to succeed.

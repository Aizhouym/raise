# Research Facility Instruments

## Natural-Language Scenario

The system manages access to laboratory instruments in a research facility.

The people involved are technicians, supervisors, safety officers, and visitors. One person may hold both the supervisor and technician roles at the same time.

The resources are instruments, samples, and access badges. Every instrument records its hazard class, whether it is under maintenance, and its status; every sample records who opened it and its status; every access badge records its holder and when it expires.

Each requester carries certifications.

Each request carries local time, whether the requester is on site, and whether a supervisor is present.

A technician or supervisor may operate an instrument.

A technician or supervisor who does not hold the exception role may not operate an instrument that is faulted when the instrument is not marked as under maintenance.

A technician or supervisor who holds the exception role may operate a faulted instrument when no other prohibition applies.

A technician or supervisor may operate a faulted instrument when the instrument is marked as under maintenance and no other prohibition applies.

A technician or supervisor may operate an instrument that is not faulted when no other prohibition applies.

A request by a technician to operate an instrument that does not trip any prohibition above must be able to succeed.
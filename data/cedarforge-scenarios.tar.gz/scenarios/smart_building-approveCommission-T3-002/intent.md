# Smart Building Commissioning Approval

## Natural-Language Scenario

The system manages the commissioning of actuators and the control of zones in a smart building automation platform.

The people involved are facility managers, zone controllers, maintenance techs, and tenants, and one person may hold both the facility manager and zone controller roles at the same time.

The resources are actuators, zones, and commission requests; every actuator records its owner, zone group, device tags, maintenance flag, and status; every zone records its controller, criticality, and status; every commission request records the device it applies to, who requested it, and its status.

A facility manager may approve a commission request only while that request is still in the requested stage.

A facility manager may approve a commission request only when they also hold the zone controller role.

A facility manager who does not hold the zone controller role must not approve the commission request.

A facility manager may approve a commission request only when they are a member of the actuator's zone group.

A facility manager who is not a member of the actuator's zone group must not approve the commission request.

A request by a facility manager who holds the zone controller role, belongs to the actuator's zone group, and is approving a commission request still in the requested stage must be able to succeed.

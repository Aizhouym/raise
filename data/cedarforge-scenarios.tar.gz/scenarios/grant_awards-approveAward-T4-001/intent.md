# Federal Grant Award Approval — Authority, Self-Award, and Risk-Based Restrictions

## Natural-Language Scenario

The system manages the review, scoring, and approval of federal grant awards.

The people involved are reviewers, program officers, grants officers, and applicants. One person may hold both the reviewer and program officer roles at the same time, and a person may also hold both the program officer and grants officer roles at the same time.

The resources are applications and awards. Every application records its applicant, its assigned reviewers, its funding tier, its requested amount, its program code, and its status. Every award records the application it belongs to, who approved it, who obligated the funds, its amount, whether it is flagged as high risk, and its status.

Each officer carries an approval authority level and each application carries a funding tier, both ranging from Tier 1 up to Tier 4.

An officer's approval authority must be at least as high as the funding tier of the application whose award they are approving, so an officer with Tier 2 approval authority may not approve an award for a Tier 3 or Tier 4 application.

Neither a program officer nor a grants officer may approve an award for an application on which they themselves are listed as the applicant. When the requester is not the applicant on that application, this self-award restriction does not apply and the officer may proceed under the other rules.

An award flagged as high risk may be approved only by a grants officer. An award that is not flagged as high risk may be approved by a program officer as well as a grants officer.

An award of $1,000,000 or more may not be approved by a program officer, and only a grants officer may approve it. An award of less than $1,000,000 may be approved by either a program officer or a grants officer.

A request by a program officer with Tier 3 approval authority to approve a Tier 2 award of $50,000 that is not flagged as high risk, on an application where they are not the applicant, must be able to succeed.

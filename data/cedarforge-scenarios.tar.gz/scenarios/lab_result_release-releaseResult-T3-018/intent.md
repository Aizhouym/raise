# Clinical Lab Result Release

## Natural-Language Scenario

The system manages the release of clinical lab results to the patient chart.

The people involved are medical technologists, pathologists, ordering providers, and the lab director. One person may hold both the pathologist and ordering provider roles, or both the medical technologist and pathologist roles, at the same time.

The resources are lab results and lab orders. Every lab result records its patient, ordering provider, verifier, sensitivity, critical flag, portal release time, and status.

Every lab order records its patient, ordering provider, test code, and status.

Each requester carries a credential level.

Each request carries the current time, whether multi-factor sign-in was used, whether the requester is on the hospital network, whether emergency release is declared, and whether coverage is authorized.

A pathologist or ordering provider who verified a result as the medical technologist may not release that result to the chart outside a permitted window.

Within a permitted window, the same person who verified the result may release it to the chart.

When emergency release is declared, the verifying technologist may also release the result to the chart.

Emergency release wins over the two-person split.

Neither a pathologist nor an ordering provider may release a result they verified as the medical technologist unless the permitted-window or emergency-release exception applies.

A request by a pathologist to release a result that does not trip any prohibition above must be able to succeed.
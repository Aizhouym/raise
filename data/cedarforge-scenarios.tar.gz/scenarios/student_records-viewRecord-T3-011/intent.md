# Student Record Viewing

## Natural-Language Scenario

The system manages student records and grades for a school.

The people involved are instructors, students, parents, and the registrar. One person may hold both the instructor and the parent role at the same time.

The resources are student records, grades, and courses. Every student record records its student, advisor, student age, ferpa block, and status.

Every grade records its student, course, grader, and status.

Every course records its instructor and roster.

Each request carries the current date and whether the request comes from the campus network.

A withdrawn student's record may be viewed only by the registrar when the requester is the student themselves and the request falls within the permitted window.

When the requester is not the student themselves, this student-only restriction does not bind the request.

When the request falls outside the permitted window, the permitted-window restriction does not allow the student-based viewing case.

An instructor, student, or parent must not view a withdrawn student's record when the registrar-only rule applies.

A request by an instructor to view a record that does not trip any prohibition above must be able to succeed.
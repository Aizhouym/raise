# Federal Grant Award Management

## Natural-Language Scenario

The system manages federal grant applications, review scoring, award approval, and fund obligation.

The people involved are reviewers, program officers, grants officers, and applicants. One person may hold both the reviewer and program officer roles, or both the program officer and grants officer roles, at the same time.

The resources are applications and awards. Every application records its applicant, assigned reviewers, funding tier, requested amount, program code, and status. Every award records its application, who approved it, who obligated it, its amount, its high risk flag, and its status.

Each requester carries their conflicted applications and approval authority.

Each request carries the current time, whether it is on the government network, and whether an emergency has been declared.

An applicant may submit an application.

A reviewer conflicted out of an application must not score it.

A reviewer who is not conflicted out of an application may score it if no other rule blocks the request.

A reviewer may score an application only while it is under review.

A reviewer may not score an application that is not under review.

A program officer may approve an award.

A grants officer may obligate funds for an award.

A request by a reviewer to score an application that does not trip any prohibition above must be able to succeed.
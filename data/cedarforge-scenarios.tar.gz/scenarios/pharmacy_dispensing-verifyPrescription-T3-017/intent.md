# Controlled-Substance Prescription Verification

## Natural-Language Scenario

The system manages outpatient controlled-substance dispensing.

The people involved are pharmacy technicians, staff pharmacists, pharmacists in charge, and prescribers. One person may hold both the staff pharmacist and pharmacist in charge roles at the same time.

The resources are prescriptions and dispense records. Every prescription records its prescriber, patient, enterer, verifier, prescriber DEA, schedule level, refills remaining, and status.

Each requester carries dispense authority and state license.

Each request carries whether the prescription-drug-monitoring database was checked, whether multi-factor authentication was used, whether the request came from the pharmacy network, the current time, and whether emergency override was used.

A staff pharmacist or pharmacist in charge may verify a prescription only while it is in the received stage.

Neither a staff pharmacist nor a pharmacist in charge may verify a prescription that is not in the received stage.

Only a staff pharmacist or pharmacist in charge may verify a prescription.

A pharmacy technician or prescriber must not verify a prescription.

A staff pharmacist or pharmacist in charge may verify a prescription only when the prescription-drug-monitoring database was checked.

Neither a staff pharmacist nor a pharmacist in charge may verify a prescription when the prescription-drug-monitoring database was not checked.

A request by a staff pharmacist to verify a received prescription after the prescription-drug-monitoring database was checked must be able to succeed.
# Inpatient Prescription — Writing then Countersignature, with Exceptions

## Natural-Language Scenario

The system manages inpatient medical records and the prescriptions written against them.

The people involved are attending physicians, residents, nurses, and pharmacists. One person may hold both the attending physician and pharmacist role at the same time, and one person may hold both the resident and pharmacist role at the same time.

The resources are medical records, prescriptions, and lab orders. Every prescription records its patient, its prescriber, and its status.

Each request carries the current shift, whether an emergency has been declared, and whether multi-factor authentication was used.

In this workflow a prescription is first written and then countersigned, and the countersignature step can see the prescription's status and who prescribed it as recorded by the writing step.

An attending physician may not write a prescription for themselves as the patient, and ordinarily may write one only for another patient.

That self-prescription bar is set aside when the prescription is in the draft stage, in which case the physician may write it even for themselves.

That self-prescription bar is also set aside when multi-factor authentication was used, in which case the physician may write it even for themselves.

The attending physician who prescribed must be the one who countersigns it, and ordinarily an attending physician who did not prescribe it may not countersign it.

That continuity requirement is relaxed when the prescription is in the designated lifecycle stage, in which case an attending physician who did not write it may countersign it.

An attending physician must not write a prescription for themselves unless one of the stated exceptions applies, and must not countersign a prescription they did not write unless the stage exception applies.

A run through the workflow by an attending physician who writes a prescription for another patient and then countersigns it, tripping no prohibition above, must be able to succeed.

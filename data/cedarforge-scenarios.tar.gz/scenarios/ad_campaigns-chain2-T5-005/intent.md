# Campaign Budget Approval then Launch — Independence, Threshold, and Risk Label

## Natural-Language Scenario

The system manages advertising campaign budget approval and campaign launch.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors. One person may hold both the account-manager and campaign-director roles at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, the manager who prepared it, its budget, its contingency, its budget tier, its risk labels, its scheduled start, and its status.

Each request carries the current time, whether multi-factor authentication was used, whether the device is trusted, and whether it is an emergency launch.

In this workflow a campaign's budget is first approved and then the campaign is launched, and the launch step can see the campaign's status and who prepared it as recorded by the earlier step.

The manager who prepared a campaign may not approve its budget, but if the budget plus contingency crosses the threshold the manager who prepared it may approve its budget after all.

A budget may be approved only when multi-factor authentication was used, and a request without multi-factor authentication may not approve it.

A campaign may be launched only after its budget is approved, but if the campaign carries the designated risk label it may be launched even before its budget is approved.

Neither a campaign director nor an account manager may approve the budget of a campaign they prepared unless the budget plus contingency crosses the threshold.

Neither an account manager nor a campaign director may launch a campaign whose budget is not yet approved unless the campaign carries the designated risk label.

A run through the workflow by a campaign director who, using multi-factor authentication, approves the budget of a campaign they did not prepare and then launches it, tripping no prohibition above, must be able to succeed.

# Cloud Resource Modification — Production Restrictions and Exceptions

## Natural-Language Scenario

The system manages access control for cloud infrastructure resources within an organization's IAM platform.

The people involved are owners, developers, operators, and org admins, and one person may hold both the owner and developer role at the same time.

The resources are cloud resources, secrets, and org units; every cloud resource records its owner, its org unit, its tags, its environment, and any temporary grant placed on it, every secret records the cloud resource it belongs to and when it was last rotated, and every org unit records its parent org unit.

Each request carries the source IP address it came from, whether multi-factor authentication was used, and the age of the current session.

An owner, a developer, or an operator may not modify a cloud resource that is in the production environment.

A cloud resource that has been promoted may be modified in the production environment even though it would otherwise be restricted.

An owner, a developer, or an operator may modify a production cloud resource anyway when the requester is that resource's owner.

An owner, a developer, or an operator may modify a production cloud resource anyway when the requester belongs under the org unit that owns the resource.

An owner, a developer, or an operator may modify a production cloud resource anyway when the resource carries the "compliance-exempt" tag.

An owner, a developer, or an operator must not modify a production cloud resource that has not been promoted, is not owned by the requester, is not under the requester's org unit, and does not carry the "compliance-exempt" tag.

A request by an owner to modify their own production cloud resource must be able to succeed.

# Comp Authorization — Requested-State Gate, Value Threshold, Loyalty Scope

## Natural-Language Scenario

The system manages the authorization of complimentary (comp) awards at a hotel.

The people involved are front desk agents, guest services hosts, shift managers, front office managers, and auditors. One person may hold both the front desk agent and guest services host roles at the same time, and one person may hold both the shift manager and front office manager roles at the same time.

The resources are comp authorizations and comp vouchers. Every comp authorization records who requested it, who authorized it, the guest's tier, the comp value, the perks it grants, its comp type, the guest's loyalty group, the item count, its authorization code, its blackout flag, its status, and when it was requested. Every comp voucher records the authorization it came from, who issued it, and its value.

A front desk agent or a guest services host may request a comp, and a shift manager or front office manager may authorize it.

A comp may be authorized only while it is still in the requested state, and a comp that has moved beyond the requested state must not be authorized.

A comp may be authorized only when its value crosses the money threshold that requires manager authorization, and a comp whose value is at or below that threshold must not be authorized.

A comp may be authorized only when the guest's loyalty group falls within the authorizing manager's scope, and when the guest's loyalty group falls outside that scope the comp must not be authorized.

Neither a shift manager nor a front office manager may authorize a comp for a guest whose loyalty group falls outside that manager's scope.

A request by a shift manager to authorize a comp still in the requested state that trips none of the prohibitions above must be able to succeed.

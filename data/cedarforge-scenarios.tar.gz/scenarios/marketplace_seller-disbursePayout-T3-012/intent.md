# Marketplace Payout Disbursement — Same-Agent, KYC Tier, and MFA Gate

## Natural-Language Scenario

The system manages seller payouts and listing approvals for an online marketplace.

The people involved are sellers, payout agents, finance approvers, and risk analysts, and one person may hold both the payout agent and finance approver roles at the same time.

The resources are seller accounts, listings, and payouts.

Every seller account records its holder, KYC tier, region, fraud status, and watchlist codes.

Every listing records its owner, category, price, category tier, risk labels, and status.

Every payout records the seller account it draws from, who initiated it, who approved it, its amount, and its status.

Each request carries whether it comes from a trusted network, whether multi-factor authentication was used, whether an emergency has been declared, and the current time, and each requester carries their own verified tier and home region.

The payout agent who initiated a payout must be the one who disburses it.

A payout agent may disburse a payout only when the seller account has reached at least Tier 2 KYC status.

When the seller account has not reached Tier 2 KYC status, the payout agent must not disburse the payout.

A payout agent may disburse a payout only when multi-factor authentication was used for the request.

When multi-factor authentication was not used for the request, the payout agent must not disburse the payout.

A payout agent must not disburse a payout that a different payout agent initiated.

A request by the payout agent who initiated a payout, whose seller account has reached Tier 2 KYC status, made with multi-factor authentication, to disburse that payout must be able to succeed.

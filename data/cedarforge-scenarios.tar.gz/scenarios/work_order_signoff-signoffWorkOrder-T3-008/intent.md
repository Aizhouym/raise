# Work-Order Sign-Off — Independence, Defect Threshold, and Network Gate

## Natural-Language Scenario

The system manages QA sign-off of manufacturing work orders.

The people involved are operators, inspectors, quality managers, production supervisors, and auditors. One person may hold both the operator and the inspector role at the same time, and one person may hold both the inspector and the quality manager role at the same time.

The resources are work orders and production releases. Every work order records its operator, its inspector, its part code, its defect count, its hold flag, its status, its station, and when it was created. Every production release records its work order, who released it, and its batch code.

Each request carries the current time, whether it is on the plant network, and whether a deviation has been authorized.

An inspector or quality manager who is the operator that performed the work must not sign it off, and one who did not perform the work may sign it off.

A work order may be signed off only when its recorded defect count is at or below the acceptance threshold, and one whose defect count exceeds the threshold may not be signed off.

A work order may be signed off only from the plant floor network, and a request from off the plant floor network is refused.

A request by an inspector who did not perform the work to sign off a work order whose defect count is at or below the acceptance threshold, from the plant floor network, tripping no prohibition above, must be able to succeed.

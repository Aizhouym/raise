# Marketplace Payout Disbursement — Binding of Duty, Verification Gates, and Emergency Override

## Natural-Language Scenario

The system manages seller payouts and listings on an online marketplace.

The people involved are sellers, payout agents, finance approvers, and risk analysts. One person may hold both the payout agent and finance approver roles at the same time.

The resources are seller accounts, listings, and payouts. Every seller account records its holder, KYC tier, region, fraud status, and watchlist codes. Every listing records its owner, category, price, category tier, risk labels, and status. Every payout records the seller account it belongs to, who initiated it, who approved it, its amount, and its status.

Each request carries the requester's verified tier and home region, along with whether the request comes from a trusted network, whether multi-factor authentication was used, whether an emergency has been declared, and the current time.

The payout agent who disburses a payout must be the same payout agent who initiated it.

A payout agent may disburse a payout only when the seller account's KYC tier is at least Tier 2. When the seller account's KYC tier is below Tier 2, no payout agent may disburse a payout from that account.

A payout agent may disburse a payout only when the request comes from a trusted network. A payout agent must not disburse a payout when the request does not come from a trusted network.

A payout agent may disburse a payout only when multi-factor authentication was used for the request. A payout agent must not disburse a payout when multi-factor authentication was not used.

When an emergency has been declared, a payout agent other than the one who initiated the payout may still disburse it, overriding the requirement that the initiator be the one to disburse it. When no emergency has been declared, the payout agent who disburses a payout must be the same one who initiated it.

If the binding-of-duty requirement and the emergency declaration disagree about who may disburse a payout, the emergency declaration wins.

A request by a payout agent to disburse a payout that meets the KYC tier, trusted network, and multi-factor authentication requirements, with no emergency in play and with the requester being the original initiator, must be able to succeed.

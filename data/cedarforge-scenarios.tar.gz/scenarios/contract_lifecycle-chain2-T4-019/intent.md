# Contract Review then Signature — Draft Gate, then Authority Match

## Natural-Language Scenario

The system manages the review and signing of contracts through their lifecycle.

The people involved are drafters, reviewers, signatories, and contract admins; one person may hold both the drafter and reviewer roles at the same time, and one person may hold both the reviewer and signatory roles at the same time.

The resources are contracts and signatures; every contract records its drafter, its reviewer, its counterparty, its contract value, its required authority, its effective date, and its status, and every signature records its contract, who signed it, and its amount.

Each requester carries a signing authority and a list of counterparties they are conflicted against, and each request carries the current date, whether it is on the corporate network, whether multi-factor authentication was used, and whether an escalation was approved.

In this workflow a contract is first reviewed and then signed, and the signing step can see the contract's status, its drafter, and its reviewer as recorded by the review step.

A reviewer may review a contract only while it is still in draft status, and a reviewer may not review a contract that has moved past draft.

This draft-only restriction is lifted when the request is made on the corporate network, so a reviewer on the corporate network may review a contract even after it has left draft status.

A signatory or contract admin may sign a contract only when their delegated signing authority tier is at least the contract's required authority tier, and one whose authority tier falls below what the contract requires may not sign it.

This authority-match requirement is set aside when the signatory is conflicted against the contract's counterparty, so a conflicted signatory is not held to the authority tier at all.

A signatory or contract admin whose authority tier falls below the contract's required tier must not sign the contract.

A run through the workflow by a reviewer who reviews a contract while it is still in draft and then, holding an authority tier that reaches the contract's required tier and not conflicted against its counterparty, signs it, tripping no prohibition above, must be able to succeed.

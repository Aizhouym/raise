# Payout Approval and Disbursement with KYC Exceptions and Verification Gate

## Natural-Language Scenario

This document describes how a marketplace seller-payout system controls the approval and disbursement of seller payouts.
The people involved are sellers, payout agents, finance approvers, and risk analysts, and one person may act as both a payout agent and a finance approver at the same time.
The resources are seller accounts, which record their holder, KYC tier, region, fraud status, and watchlist codes; listings, which record their owner, category, price, category tier, risk labels, and status; and payouts, which record their account, who initiated them, who approved them, amount, and status.
Each request carries whether extra verification was used.
A payout is first approved and then disbursed on the same payout, and the disbursement step can see the payout's status, who initiated it, and who approved it.
When approving a payout, the payout agent who initiated it may not be the one who approves it.
However, this restriction is lifted when the seller account's KYC tier is at least the required level, in which case the initiating agent may approve it.
When disbursing a payout, the payout agent who disburses it must be the same payout agent who initiated it.
However, this same-agent requirement is lifted when the seller account's KYC tier is at least the required level, in which case another payout agent may disburse it.
A payout may be disbursed only when extra verification was used for the request.
When extra verification was not used, the payout may not be disbursed.
A run through the workflow by a finance approver that trips none of these restrictions must be able to succeed.

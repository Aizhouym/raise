# Wire Transfer Release

## Natural-Language Scenario

The system manages bank wire-transfer authorization.

The people involved are originators, verifiers, treasury officers, and compliance reviewers. One person may hold both the originator and verifier role at the same time.

The resources are wire transfers and accounts. Every wire transfer records who initiated it, who verified it, who screened it, its account, amount, fee, amount tier, beneficiary, currency code, high-risk marker, and status.

Every account records its holder and allowed beneficiaries.

Each requester carries an approval tier, and each request carries the current time, daily cutoff, whether it is on a secure network, whether mfa was used, and whether an emergency has been declared.

A treasury officer may release a wire.

Before the daily wire cutoff, a treasury officer may release a wire only after it has been verified.

After the daily wire cutoff, that verification requirement does not bind the release.

A treasury officer must not release a wire before the daily wire cutoff when it has not been verified.

A request by a treasury officer to release a wire that does not trip any restriction above must be able to succeed.
# Prescription Writing, Countersignature, and Dispensing, Gated by Role, Draft Stage, and Multi-Factor Authentication

## Natural-Language Scenario

This is the access-control document for the inpatient records and prescriptions system.
The people involved are attending physicians, residents, nurses, and pharmacists, and one person may be both an attending physician and a pharmacist, or both a resident and a pharmacist, at the same time.
The resources are medical records, each recording its patient, care team, ward, sensitivity, and status, prescriptions, each recording its patient, prescriber, and status, and lab orders, each recording their patient.
Each request carries the current shift, whether an emergency has been declared, and whether multi-factor authentication was used.
In this workflow the same prescription is first written, then countersigned, and then dispensed, and each later step can see the prescription's status and who prescribed it as recorded by the earlier steps.
When an attending physician writes a prescription, that physician may not write it for themselves as the patient.
A prescription may be written only when the requester holds the required role, and a request to write one by a person without that role is refused.
A prescription may be written only while it is in the draft lifecycle stage, and a request to write one at any other stage is refused.
When an attending physician countersigns a prescription, the physician who prescribed it must be the same person who countersigns it.
A prescription may be countersigned only while it is in the required lifecycle stage, and a request to countersign one at any other stage is refused.
A prescription may be countersigned only when multi-factor authentication was used, and a request to countersign one without it is refused.
When a pharmacist dispenses a prescription, it may be dispensed only after it has been countersigned.
A prescription may be dispensed only when multi-factor authentication was used, and a request to dispense one without it is refused.
An attending physician must not write a prescription for themselves, and must not countersign a prescription that someone else prescribed.
A pharmacist must not dispense a prescription that has not been countersigned or when multi-factor authentication was not used.
A run through the workflow by an attending physician that trips none of the prohibitions above must be able to succeed.

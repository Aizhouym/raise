# Contract Signing

## Natural-Language Scenario

The system manages contract drafting, review, signing, and execution.

The people involved are drafters, reviewers, signatories, and contract admins. One person may hold both the drafter and reviewer roles, or both the reviewer and signatory roles, at the same time.

The resources are contracts and signatures. Every contract records its drafter, reviewer, counterparty, contract value, required authority, effective date, and status.

Each requester carries their signing authority and conflicted counterparties.

Each request carries the current date, whether it comes from the corporate network, whether MFA was used, and whether escalation was approved.

A signatory may sign a contract only when their signing authority meets or exceeds the contract's required authority.

When the requester is not acting as a signatory, the signing-authority requirement does not bind that requester.

Neither a signatory nor a contract admin may sign a contract they reviewed.

A request by a signatory to sign a contract that does not trip any prohibition above must be able to succeed.
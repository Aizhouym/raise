# Manufacturing QA Sign-Off and Production Release

## Natural-Language Scenario

The system manages work-order quality sign-off and release to production in a manufacturing plant.
The people involved are operators, inspectors, quality managers, production supervisors, and auditors. One person may hold both the operator and inspector roles, or both the inspector and quality manager roles, at the same time.
The resources are work orders and production releases. Every work order records its operator, inspector, part code, defect count, hold flag, status, station, and creation time.
Each request carries the current time, whether it comes from the plant floor network, and whether a deviation has been authorized.
The inspector who releases a work order to production must be the same inspector who signed off the work order.
An inspector or quality manager may release a work order to production only when its defect count is zero before release.
An inspector or quality manager must not release a work order to production when its defect count is greater than zero.
An inspector or quality manager may release a work order to production only when the request comes from the plant floor network.
An inspector or quality manager must not release a work order to production when the request comes from outside the plant floor network.
An inspector or quality manager who did not sign off the work order must not release it to production.
A request by the inspector who signed off a work order to release it to production from the plant floor network when the defect count is zero must be able to succeed.
# Shipment Delivery Confirmation

## Natural-Language Scenario

The system manages carrier shipment dispatch and delivery confirmation.

The people involved are planners, drivers, dispatch managers, depot supervisors, and auditors. One person may hold both the planner and dispatch manager role at the same time.

The resources are shipments and delivery receipts. Every shipment records its planner, driver of record, piece count, gross weight in kilograms, status, tracking code, origin depot, hazmat class, and delivery window end, and every delivery receipt records its shipment, recipient, and signed-at time.

Each request carries the current time, whether it is on the depot network, whether expedite was declared, and proof of delivery.

A driver or depot supervisor may confirm delivery only after the shipment has reached intransit status.

A driver or depot supervisor must not confirm delivery for a shipment that has not reached intransit status.

The driver who confirms delivery must be the shipment's driver of record.

A driver or depot supervisor who is not the shipment's driver of record must not confirm delivery.

A hazmat shipment requires a recorded custody signature at delivery.

For a non-hazmat shipment, delivery may be confirmed without a recorded custody signature when the other requirements are met.

An auditor may view the custody log.

A request by a driver to confirm delivery for an intransit shipment where they are the driver of record, with the required hazmat signature when applicable, must be able to succeed.
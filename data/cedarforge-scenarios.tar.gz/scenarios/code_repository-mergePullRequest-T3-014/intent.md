# Repository Pull Request Merging

## Natural-Language Scenario

The system manages source-code repositories and pull request merging.

The people involved are developers, reviewers, maintainers, and security leads. One person may hold both the developer and reviewer role at the same time.

The resources are repositories, pull requests, and branches. Every repository records its owner, team, sensitivity, whether its default branch is protected, its topics, and its status.

Every pull request records its repository, author, approvers, target branch, approval count, line count, whether it requires security review, and its status.

Every branch records its name and whether it is protected.

Each requester carries clearance.

Each request carries the current time, whether the requester is on the VPN, and whether break glass has been declared.

A maintainer who authored a pull request may not merge it when the pull request has not crossed the required approval threshold and no break-glass emergency has been declared.

When a pull request has crossed the required approval threshold, the maintainer who authored it may merge it.

When a declared break-glass emergency is present, a maintainer may merge their own hotfix even if they authored the pull request.

When break glass is declared, it overrides the rule that normally blocks a maintainer from merging their own pull request.

A maintainer must not merge their own pull request when it lacks the required approvals and no break-glass emergency has been declared.

A request by a maintainer to merge a pull request that does not trip any prohibition above must be able to succeed.
# Hotel Complimentary Authorization

## Natural-Language Scenario

The system manages hotel complimentary authorization and application to guest folios.

The people involved are front desk agents, guest services hosts, shift managers, front office managers, and auditors. One person may hold both the front desk agent and guest services host roles at the same time, and one person may hold both the shift manager and front office manager roles at the same time.

The resources are comp authorizations and comp vouchers. Every comp authorization records who requested it, who authorized it, the guest tier, comp value, perks, comp type, loyalty group, item count, auth code, blackout flag, status, and when it was requested.

Every comp voucher records its authorization, who issued it, and its value.

Each request carries the current time, whether it comes from the on-property network, the manager on duty, and whether a VIP escalation has been declared.

A shift manager or front office manager who requested a comp may not authorize it when the perk set includes a suite upgrade or gaming credit and the request comes from the on-property network.

When the perk set does not include a suite upgrade or gaming credit, the requester may authorize the comp.

When the request does not come from the on-property network, the requester may authorize the comp.

A shift manager must not authorize their own requested comp when it includes a restricted perk and comes from the on-property network.

A front office manager must not authorize their own requested comp when it includes a restricted perk and comes from the on-property network.

A request by a shift manager to authorize a comp that does not trip any prohibition above must be able to succeed.
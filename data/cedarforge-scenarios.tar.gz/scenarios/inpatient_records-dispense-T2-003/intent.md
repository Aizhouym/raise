# Inpatient Prescriptions

## Natural-Language Scenario

The system manages inpatient medical records, prescriptions, and dispensing.

The people involved are attending physicians, residents, nurses, and pharmacists.

One person may hold both the attending physician and pharmacist roles, or both the resident and pharmacist roles, at the same time.

The resources are medical records, prescriptions, and lab orders.

Every medical record records its patient, care team, ward, sensitivity, and status.

Every prescription records its patient, prescriber, and status.

Every lab order records its patient.

Each requester carries who they are cleared for and their ward, and each request carries the current shift, whether an emergency has been declared, and whether MFA was used.

A pharmacist may dispense a prescription only after it is countersigned when MFA was not used.

When MFA was used, the pharmacist may dispense the prescription even if it has not yet been countersigned.

A pharmacist must not dispense a prescription that has not been countersigned when MFA was not used.

A request by a pharmacist to dispense that does not trip any refusal above must be able to succeed.
# Content Moderation Timing and Independence

## Natural-Language Scenario

The system manages publishing, viewing, and moderation for a streaming content platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and moderator roles at the same time.

The resources are content and reports. Every content item records its publisher, required tier, embargo time, allowed regions, labels, and status.

Each requester carries a subscription tier and region.

Each request carries the current time and whether the device is trusted.

A moderator may not moderate content they published when the content carries the specified label.

When the content does not carry that label, the publisher may moderate their own content.

A moderator may not moderate content they published when the request falls within the allowed time window.

Outside that time window, the publisher may moderate their own content.

A moderator must not moderate their own published content when both limits above apply.

A request by a moderator to moderate content that does not trip any prohibition above must be able to succeed.
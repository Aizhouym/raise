# IoT Device Fleet

## Natural-Language Scenario

The system manages telemetry access for an IoT and operational technology device fleet.

The people involved are operators, technicians, fleet admins, and service accounts. One person may hold both the operator and the technician role at the same time.

The resources are devices, telemetry, and commands. Every device records its owner, site group, firmware tags, maintenance mode, and status, every telemetry record records its device and sensitivity, and every command records its device and who issued it.

Each requester carries a clearance level and site-group memberships.

Each request carries a source IP address, the current time, and the maintenance window.

An operator or fleet admin may read telemetry only when their clearance is at least as high as the telemetry sensitivity.

An operator or fleet admin whose clearance is lower than the telemetry sensitivity may still read the telemetry when they belong under the device's site group.

An operator or fleet admin whose clearance is lower than the telemetry sensitivity may still read the telemetry when the device is in the lifecycle stage named for this exception.

An operator and a fleet admin must not read telemetry when their clearance is lower than the telemetry sensitivity, they do not belong under the device's site group, and the device is not in the lifecycle stage named for this exception.

A request by an operator to read telemetry that does not trip any prohibition above must be able to succeed.
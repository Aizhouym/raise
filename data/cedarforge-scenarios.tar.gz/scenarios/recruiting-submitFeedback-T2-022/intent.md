# Recruiting Applicant Tracking

## Natural-Language Scenario

The system manages job applications, interview feedback, and offers for recruiting teams.

The people involved are recruiters, hiring managers, interviewers, and coordinators. One person may hold both the recruiter and interviewer roles, or both the recruiter and hiring manager roles, at the same time.

The resources are applications, interview feedback, and offers. Every application records its candidate, who referred the candidate, the hiring team, the requisition code, its PII sensitivity, and its status.

Every interview feedback record records its application, interviewer, candidate, and status.

Every offer records its application, who extended it, the compensation, signing bonus, and status.

Each requester carries their PII clearance.

Each request carries whether it is made on the corporate network, the current time, and whether executive approval has been given.

An interviewer on the application's hiring team may submit feedback only while the interview is scheduled.

When the interviewer is not on the application's hiring team, the scheduled-interview requirement does not apply to that interviewer.

An interviewer must not submit feedback for an interview that is not scheduled when they are on the application's hiring team.

A request by an interviewer to submit feedback that does not trip any prohibition above must be able to succeed.
# Claim Approval

## Natural-Language Scenario

The system manages insurance claim adjudication and payout.

The people involved are adjusters, reviewers, claims managers, payout officers, fraud analysts, and auditors. One person may hold both the adjuster and reviewer roles, or both the reviewer and payout officer roles, at the same time.

The resources are claims and payouts. Every claim records its handler, approver, claim amount, deductible, line item count, status, claim code, fraud hold, and filing time, and every payout records its claim, issuer, and amount.

Each request carries the current time, whether it comes from the corporate network, and whether a catastrophe has been declared.

When a claim’s line item count crosses the threshold and its net payable does not cross the threshold, neither a reviewer nor a claims manager may approve the claim before it has been reviewed.

When a claim’s line item count does not cross the threshold, the review requirement does not block approval.

When a claim’s net payable crosses the threshold, the review requirement does not block approval even if the line item count crosses the threshold.

A request by a reviewer to approve a claim that does not trip any prohibition above must be able to succeed.
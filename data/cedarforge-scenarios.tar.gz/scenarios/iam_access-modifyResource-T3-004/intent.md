# Cloud Resource Modification — Environment, Org Unit, and Network Gating

## Natural-Language Scenario

The system manages access to cloud infrastructure resources and their secrets across an organization's IAM platform.

The people involved are owners, developers, operators, and org admins. One person may hold both the owner and developer role at the same time.

The resources are cloud resources, secrets, and org units. Every cloud resource records its owner, the org unit it belongs to, its tags, its environment such as production, staging, or development, and any temporary grant that has been issued for it. Every secret records the cloud resource it belongs to and when it was last rotated. Every org unit records its parent org unit.

Each request carries the network range it came from.

An owner, a developer, or an operator may modify a cloud resource.

A cloud resource may be modified only when its environment is not production, unless the resource has been promoted by an active temporary grant covering the change.

When a cloud resource carries an active temporary grant promoting it, it may be modified even while its environment is set to production.

A cloud resource may be modified only when the requester belongs to the org unit the resource belongs to, or to one of that org unit's descendant units.

When the requester's own org unit is not the resource's org unit and not a descendant of it, the modification may not go through.

A cloud resource may be modified only when the request comes from an allowed network range, such as the corporate VPN.

When the request comes from a network range that is not on the allowed list, the modification may not go through even if every other condition is satisfied.

An owner, a developer, and an operator must not modify a production cloud resource that lacks an active promoting temporary grant, no matter which of the three roles they hold.

A request by an owner to modify a staging cloud resource, where the owner belongs to the resource's org unit and the request comes from the corporate VPN, must be able to succeed.

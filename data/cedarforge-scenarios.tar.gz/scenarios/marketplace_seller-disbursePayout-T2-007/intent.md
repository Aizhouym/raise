# Marketplace Payout Disbursement — Initiator Consistency and Network Trust

## Natural-Language Scenario

The system manages seller payouts and listings on an online marketplace.

The people involved are sellers, payout agents, finance approvers, and risk analysts. One person may hold both the payout agent and finance approver roles at the same time.

The resources are seller accounts, listings, and payouts. Every seller account records its holder, kyc tier, region, fraud status, and watchlist codes. Every listing records its owner, category, price, category tier, risk labels, and status. Every payout records its account, who initiated it, who approved it, its amount, and its status.

Each request carries whether it comes from a trusted network, whether multi-factor authentication was used, whether an emergency has been declared, and the current time.

A payout agent may disburse a payout only when the request originates from a trusted network.

If the request does not come from a trusted network, the payout agent must not disburse the payout, even if they initiated it themselves.

The payout agent who initiated a payout must be the same payout agent who disburses it.

A payout agent must not disburse a payout that was initiated by a different payout agent.

A request by a payout agent to disburse a payout that they themselves initiated, submitted from a trusted network, must be able to succeed.

# Billing Run Approval — Authority with an Emergency Override

## Natural-Language Scenario

The system manages meter data and the billing runs produced from it.

The people involved are meter readers, billing analysts, billing managers, data stewards, and auditors. One person may hold both the meter reader and data steward roles at the same time, and one person may hold both the billing analyst and meter reader roles at the same time.

The resources are billing runs and meter accounts. Every billing run records its account, its preparer, its approver, its bill amount, its usage, its rate, its rate class, its region, its account tier, its status, and when it was prepared. Every meter account records its account holder, who last read it, its tier, its adjustment count, its last bill amount, its rate class, its region, its status, and when it was last read.

Each request carries the time it is made, whether it comes from the corporate network, and whether an emergency has been declared.

A billing analyst or billing manager may approve a billing run only when their authority level is at least the account tier of that run, and someone whose authority is below the account tier may not approve it.

During a declared metering emergency, a billing manager may approve a billing run for an account tier above their normal authority.

When a metering emergency has been declared, this emergency allowance overrides the authority-level requirement, and the approval is recorded for later audit review.

A request by a billing analyst whose authority level is at least the account tier to approve a billing run must be able to succeed.

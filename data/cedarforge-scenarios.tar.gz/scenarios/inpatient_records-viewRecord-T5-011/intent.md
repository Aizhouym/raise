# Inpatient Record Viewing — Clearance, Care Team, Ward, and Shift Gates

## Natural-Language Scenario

The system manages inpatient medical records, prescriptions, and lab orders on a hospital ward.

The people involved are attending physicians, residents, nurses, and pharmacists. One person may hold both the attending physician and pharmacist roles, and one person may hold both the resident and pharmacist roles.

The resources are medical records, prescriptions, and lab orders. A medical record records its patient, its care team, its ward, its sensitivity level, and its status. A prescription records its patient, its prescriber, and its status. A lab order records its patient.

Each requester carries a cleared-for level and a ward assignment, and each request carries the current shift, whether an emergency has been declared, and whether multi-factor authentication was used.

An attending physician, a resident, or a nurse may view a medical record only when their cleared-for level is at least as high as the record's sensitivity level.

Beyond that baseline, a nurse may view a record only when she is listed on that record's care team; a nurse who is not on the care team of a record may not view it even if her clearance level is sufficient.

A nurse may view a record only when her ward assignment matches the record's ward; a nurse assigned to a different ward may not view the record even if she is on its care team.

A nurse may view a record only during her current shift with multi-factor authentication used on the request; outside her shift, or without multi-factor authentication having been used, a nurse may not view the record even if the care-team and ward conditions are both met.

An attending physician or a resident may view a record without being on its care team, without a matching ward assignment, and without the shift-and-multi-factor-authentication condition, so long as their cleared-for level dominates the record's sensitivity level.

An attending physician, a resident, or a nurse must not view a medical record whenever their cleared-for level does not dominate the record's sensitivity level, regardless of care team, ward, shift, or multi-factor authentication.

A request by an attending physician to view a record whose sensitivity level their clearance dominates must be able to succeed.

# Retail Orders and Refunds

## Natural-Language Scenario

The system manages retail orders, stored card data, and refunds.

The people involved are customers, service reps, managers, and auditors. One person may hold both the service rep and manager role at the same time.

The resources are orders and refunds. Every order records its customer, who placed it, item total, tax amount, loyalty tier, whether it contains card data, and its status, and every refund records its order, who issued it, and its amount.

Each request carries whether it is inside the cardholder-data zone, whether multi-factor verification was used, and the current time.

A service rep may view stored card data only before the order is refunded and only when the request is inside the cardholder-data zone.

For refunded orders, a service rep must not view stored card data.

Outside the cardholder-data zone, a service rep must not view stored card data.

An auditor may view stored card data before the order is refunded even when the request is outside the cardholder-data zone.

For refunded orders, an auditor must not view stored card data.

A request by a service rep inside the cardholder-data zone to view card data on an order that has not been refunded must be able to succeed.
# Streaming Content Access

## Natural-Language Scenario

The system manages access to streaming content on a content platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and moderator role at the same time.

The resources are content and reports. Every content item records its publisher, required tier, embargo time, allowed regions, labels, and status, and every report records the content and the reporter.

Each subscriber carries a subscription tier and a region.

Each request carries the current time and whether the device is trusted.

A subscriber's subscription tier must meet the content's required tier unless the content is licensed in the subscriber's region.

When the content is licensed in the subscriber's region, the subscriber may watch it even if their subscription tier is below the required tier.

A subscriber's subscription tier must meet the content's required tier unless the content's embargo time has passed.

When the content's embargo time has passed, the subscriber may watch it even if their subscription tier is below the required tier.

A subscriber must not watch content when their subscription tier is below the content's required tier, the content is not licensed in their region, and the embargo time has not passed.

A request by a subscriber to watch content that does not trip any prohibition above must be able to succeed.
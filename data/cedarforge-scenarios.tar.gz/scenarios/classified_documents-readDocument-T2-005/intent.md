# Classified Document Access — Clearance Dominance with Compartment Exception

## Natural-Language Scenario

The system manages access to classified documents for a government agency.

The people involved are analysts, officers, security admins, and contractors. One person may hold both the analyst and the officer role at the same time.

The resources are documents, dossiers, and access badges. Every document records its owner, its classification level, its compartments, and its status. Every dossier records the documents it contains and its own classification level. Every access badge records its holder and its expiration time.

Each request carries whether it was made from the agency's intranet and the current time.

An analyst or an officer may read a document only when their clearance level dominates the document's classification level, meaning their clearance is equal to or higher than Secret when the document is classified Secret.

This clearance rule does not apply when the document carries a special compartment label such as SIGINT. For a document marked with the SIGINT compartment, an analyst or an officer may read it even if their clearance does not dominate the document's classification level.

An analyst must not read a document classified above their clearance level, and the same restriction applies to an officer.

A security admin may declassify a document.

A contractor may not read, write, declassify, or export any document.

A request by an analyst to read a document that does not trip the clearance rule or any other prohibition must be able to succeed.

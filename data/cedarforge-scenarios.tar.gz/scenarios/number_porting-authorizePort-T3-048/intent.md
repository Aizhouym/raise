# Carrier Port Authorization and Cutover

## Natural-Language Scenario

The system manages local number portability authorization and cutover for a carrier.

The people involved are porting specialists, porting supervisors, fraud reviewers, line technicians, and auditors. One person may hold both the porting specialist and fraud reviewer roles, or both the line technician and porting specialist roles, at the same time.

The resources are port requests and port completions. Every port request records its initiator, authorizer, assigned technician, account numbers, number block size, carrier code, port type, subscriber region, status, and requested time.

Each request carries the current time, whether it is on the carrier network, whether a port freeze override has been declared, and whether there is a regulator escalation.

A porting specialist or porting supervisor may authorize a port request.

A porting specialist who submitted a port request must not authorize it.

A porting supervisor who submitted a port request while acting as a porting specialist must not authorize it.

A port request may be authorized only after subscriber ownership has been validated when the request is outside the regulated porting SLA window.

Within the regulated porting SLA window, the ownership-validation timing requirement does not block authorization.

A request by a porting specialist to authorize a port that does not trip any prohibition above must be able to succeed.
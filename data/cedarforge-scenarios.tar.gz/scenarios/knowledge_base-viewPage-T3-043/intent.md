# Internal Wiki Knowledge Base

## Natural-Language Scenario

The system manages pages in an internal company wiki.

The people involved are contributors, reviewers, space admins, and readers. One person may hold both the contributor and reviewer role at the same time.

Each requester carries their clearance and the spaces they belong to.

The resources are pages and spaces. Every page records its author, reviewer, space, classification, external-share setting, labels, and status, and every space records its members.

A reader, contributor, reviewer, or space admin may view a page with external sharing enabled only when their clearance is at least as high as the page's classification.

When external sharing is not enabled for the page, this clearance requirement does not bind the viewing request.

When the page carries the particular exception label, this clearance requirement does not block viewing even if external sharing is enabled.

A reader, contributor, reviewer, or space admin must not view an externally shared page without that particular exception label when their clearance is lower than the page's classification.

A request by a reader to view a page that does not trip any prohibition above must be able to succeed.
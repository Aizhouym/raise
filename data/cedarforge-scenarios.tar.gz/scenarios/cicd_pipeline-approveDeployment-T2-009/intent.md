# Deployment Approval

## Natural-Language Scenario

The system manages approvals for deployments in a CI/CD pipeline.

The people involved are committers, approvers, release managers, and SREs. One person may hold both the committer and approver roles, and one person may hold both the approver and release manager roles.

The resources are deployments and artifacts. Every deployment records its committer, approver, target environment, change risk, artifact, and status.

Every artifact records who built it, whether it is signed, its build tags, and its status.

Each requester carries a deploy tier.

Each request carries the current time, source IP, and whether it is for an emergency change.

An approver or release manager may approve a deployment only after it has been submitted for review when the request does not come from an allowed network range.

When the request comes from an allowed network range, an approver or release manager may approve a deployment that has not yet been submitted for review.

An approver or release manager must not approve a deployment that has not been submitted for review from outside the allowed network range.

A request by an approver to approve a deployment that does not trip any refusal above must be able to succeed.
# Work-Order QA Sign-Off

## Natural-Language Scenario

The system manages QA sign-off and production release for manufacturing work orders.

The people involved are operators, inspectors, quality managers, production supervisors, and auditors. One person may hold both the operator and inspector roles, or both the inspector and quality manager roles, at the same time.

The resources are work orders and production releases. Every work order records its operator, inspector, part code, defect count, hold flag, status, station, and creation time.

Each request carries the current time, whether it is on the plant network, and whether a deviation has been authorized.

An operator may create a work order and start work.

An inspector or quality manager may sign off a work order.

For a work order whose part code matches or has a controlled-part prefix, an inspector or quality manager may sign it off only while it is in progress.

For a work order whose part code does not match and does not have a controlled-part prefix, the in-progress status requirement does not bind the sign-off.

Neither an inspector nor a quality manager may sign off a matching or controlled-part work order while it is outside in-progress status.

A production supervisor may release a signed-off work order to production.

An auditor may view the quality log.

A request by an inspector to sign off a work order that does not trip any prohibition above must be able to succeed.
# Budget Approval then Campaign Launch — Independence, Thresholds, and Emergency Launch

## Natural-Language Scenario

The system manages budget approval and campaign launch in an advertising organization.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors, and one person may hold both the account manager and the campaign director role at the same time.

The resources are campaigns and creatives, where every campaign records its advertiser, who prepared it, its budget, its contingency, its budget tier, its risk labels, its scheduled start, and its status, and every creative records its campaign, who submitted it, its risk rating, its content tags, and its status.

Each request carries the current time, whether a second factor was used, whether the device is trusted, and whether an emergency launch has been declared, along with the person's reviewer level.

In this workflow a campaign's budget is first approved and then the campaign is launched, and the launch step can see the campaign's status and who prepared it as recorded by the earlier steps.

The manager who prepared a campaign may not approve its budget when the budget plus its contingency crosses the review threshold, and when the budget plus contingency stays below that threshold the preparer may approve their own campaign's budget.

When an emergency launch has been declared, a campaign director may approve the budget of a campaign they prepared, overriding the rule that a preparer may not approve their own budget.

Neither an account manager nor a campaign director may approve the budget of a campaign they prepared once the budget plus contingency crosses the review threshold, absent a declared emergency launch.

A campaign may be launched only after its budget is approved, and neither an account manager nor a campaign director may launch a campaign whose budget has not been approved.

When an emergency launch has been declared, the emergency-launch allowance wins over the rule barring a preparer from approving their own campaign's budget.

A run through the workflow by a campaign director who approves the budget of a campaign they did not prepare and then launches that approved campaign, tripping no prohibition above, must be able to succeed.

# Invoice Approval and Payment

## Natural-Language Scenario

The system manages invoice approval and payment for a finance department.

The people involved are clerks, approvers, finance managers, and auditors. One person may hold both the clerk and the approver role at the same time.

The resources are invoices and payments. Every invoice records its creator, approver, amount, surcharge, line item count, status, cost center, and submission time.

Every payment records its invoice, issuer, and amount.

A clerk may create and submit an invoice.

An approver or finance manager who created an invoice may not approve it when the invoice has more than the threshold number of line items and the amount plus surcharge does not cross the financial exception threshold.

When the invoice does not have more than the threshold number of line items, the creator may approve their own invoice.

When the amount plus surcharge crosses the financial exception threshold, the creator may approve their own invoice despite the line item count.

A finance manager may issue a payment for an approved invoice.

An auditor may view the audit log.

A request by an approver to approve an invoice that does not trip any prohibition above must be able to succeed.
# Contract Review

## Natural-Language Scenario

The system manages contract drafting, review, signing, and execution.

The people involved are drafters, reviewers, signatories, and contract admins. One person may hold both the drafter and reviewer roles, and one person may hold both the reviewer and signatory roles.

The resources are contracts and signatures. Every contract records its drafter, reviewer, counterparty, contract value, required authority, effective date, and status.

Each request carries the current date, whether it is made on the corporate network, whether MFA was used, and whether escalation was approved.

A reviewer may review a contract only while the contract is still in draft status.

A reviewer may not review a contract after it has left draft status.

A contract may be reviewed only by a reviewer.

A drafter, signatory, or contract admin who is not acting as a reviewer must not review a contract.

A request by a reviewer to review a draft contract that trips no prohibition above must be able to succeed.
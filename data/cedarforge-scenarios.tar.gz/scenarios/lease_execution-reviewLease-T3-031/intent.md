# Lease Review

## Natural-Language Scenario

The system manages brokerage lease review and execution.

The people involved are leasing agents, transaction coordinators, brokers, compliance officers, and auditors. One person may hold both the leasing agent and transaction coordinator roles, and one person may hold both the broker and compliance officer roles.

The resources are leases and executed leases. Every lease records its listing agent, reviewer, lease code, monthly rent, term months, square footage, region, premises class, contingencies, segment, fair housing hold, status, and sign window end.

Each executed lease records its lease, who executed it, and when it was recorded.

Each request carries the current time, whether it comes from the brokerage network, whether the person's identity is verified, and whether a court order has been declared.

A broker or transaction coordinator may review a lease only while it is in the drafted state when the lease's total contract value, based on monthly rent times term months, crosses the review threshold and the request comes from the brokerage network.

For leases whose total contract value does not cross the review threshold, this drafted-state review restriction does not apply.

For requests that do not come from the brokerage network, this drafted-state review restriction does not apply.

A broker and a transaction coordinator must not review a lease outside the drafted state when the lease's total contract value crosses the review threshold and the request comes from the brokerage network.

A request by a broker to review a lease that does not trip any prohibition above must be able to succeed.
# Invoice Approval and Payment

## Natural-Language Scenario

The system manages supplier invoices from creation through approval and payment.

The people involved are clerks, approvers, finance managers, and auditors. One person may hold both the clerk and the approver role at the same time.

The resources are invoices and payments. Every invoice records its creator, its approver, its amount, its surcharge, its line item count, its status, its cost center, and when it was submitted.

A clerk may create an invoice and submit it.

Neither an approver nor a finance manager may approve an invoice they themselves created.

This restriction applies only when the invoice amount crosses $10,000.

For invoices of $10,000 or less, the creator may approve their own invoice.

A finance manager may issue a payment for an approved invoice.

An auditor may view the audit log.

A request by an approver to approve an invoice that does not trip any of the rules above must be able to succeed.

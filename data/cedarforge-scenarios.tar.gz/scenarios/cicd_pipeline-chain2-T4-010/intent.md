# CI/CD Pipeline — Deployment Approval then Promotion

## Natural-Language Scenario

The system manages the deployment pipeline that moves code changes toward production.

The people involved are committers, approvers, release managers, and site reliability engineers. One person may hold the committer and approver roles together, or the approver and release-manager roles together.

The resources are deployments and artifacts. Every deployment records its committer, its approver, its target environment, its change-risk score, its artifact, and its status.

Each request carries the current time, its source network address, and whether it is an emergency change.

In this workflow a deployment is first approved and then promoted, and the promotion step can see the deployment's status, its committer, and its approver as recorded by the approval step.

A deployment may be approved only after it has been submitted for review, and a request to approve one that has not been submitted is refused.

A deployment may be promoted only after it has been approved, and a request to promote one that has not been approved is refused.

A deployment may be promoted only by the requester who is its recorded approver, and a release manager who is not the recorded approver may not promote it.

When an emergency change is declared, a release manager may promote a deployment that has not yet been approved, and this overrides the requirement that a deployment be approved first.

Only an approver or a release manager may approve a deployment, and only a release manager may promote one.

A run through the workflow in which an approver approves a submitted deployment and the recorded approver, acting as release manager, then promotes it, tripping no prohibition above, must be able to succeed.

# Bind Policy — Authority Dominance and a Premium-Driven Seniority Gate

## Natural-Language Scenario

The system manages insurance policy underwriting and the binding of policies.

The people involved are underwriters, senior underwriters, underwriting managers, chief underwriters, and auditors. One person may hold both the underwriter and senior underwriter roles at the same time.

The resources are applications and policies. Every application records its assigned underwriter, its risk tier, its coverage lines, its segment, its premium, its product code, its exposure count, its status, and its effective date. Every policy records its application, who bound it, its premium, and its effective date.

Only an underwriter, a senior underwriter, or an underwriting manager may bind a policy.

A policy may be bound only when the underwriter's granted authority level reaches or exceeds the application's assessed risk tier, and an underwriter whose authority does not reach that risk tier may not bind it.

When the annual premium is above the set money threshold, a policy may be bound only by someone holding at least the senior-underwriter role, and a plain underwriter may not bind such a policy.

When the annual premium is at or below that threshold, a plain underwriter may bind the policy, provided their authority reaches the risk tier.

A request by an underwriter to bind a policy that trips none of the prohibitions above must be able to succeed.

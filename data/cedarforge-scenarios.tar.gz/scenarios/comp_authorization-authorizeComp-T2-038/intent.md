# Hotel Complimentary Authorization

## Natural-Language Scenario

The system manages hotel complimentary authorizations and their application to guest folios.

The people involved are front desk agents, guest services hosts, shift managers, front office managers, and auditors. One person may hold both the front desk agent and guest services host roles, and one person may hold both the shift manager and front office manager roles.

The resources are comp authorizations and comp vouchers. Every comp authorization records who requested it, who authorized it, the guest tier, comp value, perks, comp type, loyalty group, item count, auth code, blackout flag, status, and request time.

Each comp voucher records its authorization, who issued it, and its value.

Each request carries the current time, whether it comes from the hotel property network, the manager on duty, and whether a VIP escalation has been declared.

A shift manager or front office manager may authorize a comp when the comp value crosses the money threshold requiring manager authorization.

A shift manager or front office manager who requested the comp as the agent may not authorize it when the comp value crosses that threshold.

For comps that do not cross the money threshold, the agent who requested the comp is not blocked by this independence requirement from authorizing it.

Neither a shift manager nor a front office manager may authorize a threshold-crossing comp that they requested as the agent.

A request by a shift manager to authorize a comp that does not trip any prohibition above must be able to succeed.
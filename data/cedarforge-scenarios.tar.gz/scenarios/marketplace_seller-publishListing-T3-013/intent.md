# Marketplace Listing Publication

## Natural-Language Scenario

The system manages seller listings, seller accounts, and payouts in an online marketplace.

The people involved are sellers, payout agents, finance approvers, and risk analysts. One person may hold both the payout agent and the finance approver role at the same time.

The resources are seller accounts, listings, and payouts. Every seller account records its holder, KYC tier, region, fraud status, and watchlist codes.

Every listing records its owner, category, price, category tier, risk labels, and status.

Every payout records its seller account, who initiated it, who approved it, its amount, and its status.

A seller may publish a listing only when the seller's verified tier is at least as high as the tier required by the listing's category.

This tier requirement applies when the listing's category code matches an allowed category or has a permitted prefix.

When the listing's category code does not match an allowed category and does not have a permitted prefix, this tier requirement does not bind the seller.

The tier requirement does not apply when the listing price crosses the marketplace money threshold.

When the listing price does not cross the marketplace money threshold, the seller's verified tier must still be at least as high as the listing's required category tier.

A seller must not publish a listing when the seller's verified tier is lower than the tier required by the listing's category and no exception above applies.

A request by a seller to publish a listing that does not trip any prohibition above must be able to succeed.
# Clinical Lab Result Release

## Natural-Language Scenario

The system manages clinical lab result release to the patient chart.

The people involved are medical technologists, pathologists, ordering providers, and lab directors. One person may hold both the pathologist and ordering provider roles, or both the medical technologist and pathologist roles.

The resources are lab results and lab orders. Every lab result records its patient, ordering provider, verifier, sensitivity, critical flag, portal release time, and status.

Each requester carries a credential level.

Each request carries the current time, whether multi-factor authentication was used, whether the requester is on the hospital network, whether emergency release is claimed, and whether coverage is authorized.

For a critical lab result, a pathologist or ordering provider may release it only after it has been verified.

For a lab result that is not critical, the verification requirement does not block release.

Neither a pathologist nor an ordering provider may release a lab result if they are also the medical technologist who verified it.

A request by a pathologist to release a result that does not trip any prohibition above must be able to succeed.
# Payroll Approval — Preparer Separation and Submission Gate

## Natural-Language Scenario

The system manages personnel records and payroll approvals for an organization.

The people involved are employees, managers, human resources specialists, and payroll admins, and one person may hold both the manager and employee role at the same time.

The resources are payroll runs, employee records, and leave requests.

Every payroll run records who prepared it, who approved it, its amount, and its status, every employee record records the employee, their manager, their clearance level for sensitive data, and their department, and every leave request records the employee, the approver, and its status.

Each request to approve payroll carries the requester's clearance level, whether the request originates from the corporate VPN, and the current time.

A manager or a payroll admin may approve a payroll run.

A manager or a payroll admin who prepared a payroll run must not approve that same run.

A payroll run may be approved only after it has reached submitted status.

For a payroll run whose amount exceeds $250,000, it may be approved even while it is still in draft status, ahead of reaching submitted status.

This early-approval exception applies only when the approver is a payroll admin, so a manager may never approve a payroll run before it has reached submitted status, no matter how large the amount.

A request by a manager to approve a payroll run that has reached submitted status, and that they did not prepare, must be able to succeed.

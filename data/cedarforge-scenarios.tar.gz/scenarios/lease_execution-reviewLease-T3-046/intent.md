# Brokerage Lease Review and Execution

## Natural-Language Scenario

The system manages lease review and execution for a brokerage.

The people involved are leasing agents, transaction coordinators, brokers, compliance officers, and auditors. One person may hold both the leasing agent and transaction coordinator roles, and one person may hold both the broker and compliance officer roles.

The resources are leases and executed leases. Every lease records its listing agent, reviewer, lease code, monthly rent, term months, square footage, region, premises class, contingencies, segment, fair housing hold, status, and signing-window end time.

Each request carries the current time, whether it comes from the brokerage network, whether the requester's identity has been verified, and whether a court order has been declared.

A leasing agent may draft a lease.

A broker who was the listing agent may not review the lease when the contingency set includes a clause that requires escalated review.

When the contingency set does not include a clause that requires escalated review, the listing agent may review the lease as broker if no other rule blocks the review.

A broker or transaction coordinator may review a lease only while the lease is still inside its open signing window.

After the lease's signing window has closed, neither a broker nor a transaction coordinator may review it.

An auditor may view the audit log.

A request by a broker to review a lease that does not trip any prohibition above must be able to succeed.
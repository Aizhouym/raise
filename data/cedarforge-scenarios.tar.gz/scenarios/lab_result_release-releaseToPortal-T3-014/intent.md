# Clinical Lab Result Release

## Natural-Language Scenario

The system manages the release of clinical lab results to a patient portal.

The people involved are medical technologists, pathologists, ordering providers, and the lab director. One person may hold both the pathologist and ordering provider roles, or both the medical technologist and pathologist roles, at the same time.

The resources are lab results and lab orders. Every lab result records its patient, ordering provider, verifier, sensitivity, critical flag, portal release time, and status.

Each requester carries a credential level.

Each request carries the current time, whether multi-factor verification was used, whether it came from the hospital network, whether emergency release was claimed, and whether coverage was authorized.

A pathologist or lab director may release a lab result to the patient portal only when their credential level is high enough for the result's sensitivity.

A pathologist and a lab director must not release a lab result to the patient portal when their credential level is too low for the result's sensitivity.

A lab result may be released to the patient portal only after the patient-portal embargo window has elapsed.

Before the patient-portal embargo window has elapsed, neither a pathologist nor the lab director may release the lab result to the patient portal.

A lab result marked as critical must be held from the patient portal until it has been acknowledged.

A lab result not marked as critical does not need critical-value acknowledgement before portal release.

A request by a pathologist to release a lab result to the patient portal that does not trip any prohibition above must be able to succeed.
# Controlled-Substance Prescription Verification

## Natural-Language Scenario

The system manages outpatient controlled-substance prescription dispensing.

The people involved are pharmacy technicians, staff pharmacists, pharmacists in charge, and prescribers. One person may hold both the staff pharmacist and pharmacist-in-charge role at the same time.

The records are prescriptions and dispense records. Every prescription records its prescriber, patient, entering person, verifying pharmacist, prescriber's DEA number, schedule level, refills remaining, and status, and every dispense record records its prescription, dispensing person, quantity, and copay amount.

Each verification request carries whether the prescription-drug-monitoring database was checked.

A pharmacy technician may enter a prescription.

Neither a staff pharmacist nor a pharmacist in charge may verify a prescription that they entered as a technician.

A staff pharmacist or pharmacist in charge who did not enter the prescription may verify it if no other rule blocks the request.

A prescription may be verified only when the prescription-drug-monitoring database was checked.

When the prescription-drug-monitoring database was checked, that requirement does not block verification.

A request by a staff pharmacist to verify a prescription that does not trip any prohibition above must be able to succeed.
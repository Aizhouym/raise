# Guest Folio Adjustment Approval

## Natural-Language Scenario

The system manages guest folio adjustment posting and approval.

The people involved are front desk agents, night auditors, accounting clerks, revenue managers, and auditors. One person may hold both the front desk agent and night auditor roles, and one person may hold both the accounting clerk and revenue manager roles.

The resources are folios and credit notes. Every folio records its guest, who posted it, who approved it, its folio balance, adjustment amount, original charge, line item count, folio code, dispute category, property region, guest segment, charges, VIP flag, status, and checkout deadline.

Each request carries the current time, whether it is on the property network, whether the dispute is verified, and whether a general manager override is declared.

An accounting clerk who posted an adjustment may not approve it during the night-audit cutoff window unless they also hold the revenue manager role required for large credits.

A revenue manager who posted an adjustment may approve it during the night-audit cutoff window when no other requirement blocks the approval.

An accounting clerk or revenue manager may approve an adjustment only during the night-audit cutoff window.

An accounting clerk or revenue manager must not approve an adjustment outside the night-audit cutoff window.

An accounting clerk must not approve an adjustment they posted unless they also hold the revenue manager role.

An auditor may view the folio log.

A request by an accounting clerk to approve an adjustment that does not trip any prohibition above must be able to succeed.
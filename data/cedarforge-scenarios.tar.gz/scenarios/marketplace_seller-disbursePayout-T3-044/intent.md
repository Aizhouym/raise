# Seller Payout Disbursement

## Natural-Language Scenario

The system manages marketplace seller payouts and listings.

The people involved are sellers, payout agents, finance approvers, and risk analysts. One person may hold both the payout agent and the finance approver role at the same time.

The resources are seller accounts, listings, and payouts. Every seller account records its holder, KYC tier, region, fraud status, and watchlist codes.

Every listing records its owner, category, price, category tier, risk labels, and status.

Every payout records its seller account, who initiated it, who approved it, its amount, and its status.

Each requester carries their verified tier and home region.

Each request carries whether it is on a trusted network, whether MFA was used, whether an emergency has been declared, and the current time.

A payout agent may disburse a payout only if that same payout agent initiated it.

A payout agent who did not initiate a payout must not disburse it.

A payout may be disbursed only when the seller account is clear and not on fraud hold.

When the seller account's KYC tier is at least the required level, the clear-account and fraud-hold restriction does not block disbursement.

A payout agent must not disburse a payout for a seller account that is not clear or is on fraud hold when the seller account's KYC tier is below the required level.

A request by a payout agent to disburse a payout that does not trip any prohibition above must be able to succeed.
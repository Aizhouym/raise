# Shipment Dispatch

## Natural-Language Scenario

The system manages carrier shipment dispatch and delivery confirmation.

The people involved are planners, drivers, dispatch managers, depot supervisors, and auditors. One person may hold both the planner and dispatch manager role at the same time.

The resources are shipments and delivery receipts. Every shipment records its planner, driver of record, piece count, gross weight in kilograms, status, tracking code, origin depot, hazmat class, and delivery window end.

Each request carries the current time, whether it is on the depot network, whether expedite was declared, and proof of delivery.

A driver or dispatch manager may dispatch a shipment only before the shipment's delivery window ends.

After the shipment's delivery window ends, neither a driver nor a dispatch manager may dispatch it.

A driver or dispatch manager may dispatch a shipment only when the request comes from the shipment's origin depot network.

When the request does not come from the shipment's origin depot network, neither a driver nor a dispatch manager may dispatch the shipment.

Neither a driver nor a dispatch manager may dispatch a shipment when that person planned it and is also its driver of record.

A request by a driver to dispatch a shipment that does not trip any prohibition above must be able to succeed.
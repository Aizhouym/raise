# Retail Order Refunds — Self-Refund Restriction

## Natural-Language Scenario

The system manages retail orders and their refunds for a retail company.

The people involved are customers, service reps, managers, and auditors. One person may hold both the service rep and manager roles at the same time.

The resources are orders and refunds. Every order records its customer, the person who placed it, the item total, the tax amount, the customer's loyalty tier, whether it contains card data, and its status. Every refund records the order it applies to, the person who issued it, and its amount.

Each request carries information about whether it originates from within the cardholder-data zone, the secure network area used for handling card payment information.

A service rep or a manager may issue a refund for an order.

A service rep who placed an order may not issue its refund when the refund amount is over $500, the customer's loyalty tier is gold or higher, and the request originates from within the cardholder-data zone.

This restriction also applies to a manager who placed the order, since one person may hold both the service rep and manager roles at the same time.

If the refund amount is $500 or less, the customer's loyalty tier is below gold, or the request originates from outside the cardholder-data zone, the rep who placed the order may issue the refund even though they placed it.

A request by a service rep to issue a refund for an order they did not place must be able to succeed.

# Work-Order Approval and Cage Maintenance, With Separation of Duty and an Approval Gate

## Natural-Language Scenario

This is the access-control document for the datacenter cage physical access system.
The people involved are facility techs, tenant engineers, security ops, and escorts, and one person may be both a facility tech and an escort at the same time.
The resources are cages, each recording its tenant, zone clearance, occupant list, site zone, whether an escort is required, and status, work orders, each recording their cage, who raised them, who approved them, and status, and access badges, each recording their holder and when they expire.
Each request carries the current time, whether an escort is present, whether the request falls within a maintenance window, and whether the request is on the on-site network.
In this workflow the same work order is first approved and then maintenance is performed against it, and the maintenance step can see the work order's status and who raised it as recorded by the approval step.
When security ops approves a work order, the technician who raised it may not be the one who approves it.
When a facility tech or a tenant engineer performs maintenance, it may be performed only after the work order has been approved.
Security ops must not approve a work order that they themselves raised.
A facility tech or a tenant engineer must not perform maintenance on a work order that has not been approved.
A run through the workflow by security ops that trips none of the prohibitions above must be able to succeed.

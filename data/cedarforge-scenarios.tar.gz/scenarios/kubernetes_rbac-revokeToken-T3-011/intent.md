# Kubernetes Namespace Token Revocation

## Natural-Language Scenario

The system manages Kubernetes namespace work and service-account token revocation.

The people involved are deployers, maintainers, cluster operators, and service accounts. One person may hold both the deployer and maintainer role at the same time.

The resources are namespaces, workloads, namespace secrets, and service account tokens. Every service account token records its subject, bound namespace, issuing operator, expiration time, and status.

Each requester carries their clearance, granted scope, and group memberships.

Each request carries its source IP, current time, whether it is an emergency change, and whether MFA was used.

A cluster operator who issued a service-account token must be the one who revokes it when the requester is outside the token's bound-namespace team group and MFA was not used.

When the requester belongs under the token's bound-namespace team group, a different cluster operator may revoke the token.

When MFA was used, a different cluster operator may revoke the token.

A cluster operator must not revoke a token issued by another operator when the requester is outside the token's bound-namespace team group and MFA was not used.

A request by a cluster operator to revoke a token that does not trip any prohibition above must be able to succeed.
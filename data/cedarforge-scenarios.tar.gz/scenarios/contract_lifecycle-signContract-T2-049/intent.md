# Contract Lifecycle Management

## Natural-Language Scenario

The system manages contract drafting, review, signing, and execution.

The people involved are drafters, reviewers, signatories, and contract admins. One person may hold both the drafter and reviewer roles, or both the reviewer and signatory roles, at the same time.

The resources are contracts and signatures. Every contract records its drafter, reviewer, counterparty, contract value, required authority, effective date, and status.

Each requester carries their signing authority and the counterparties for which they have a conflict.

A drafter may draft a contract.

A reviewer may review a contract.

A signatory or contract admin who is conflicted against the contract's counterparty may sign it only when their signing authority is at least as high as the contract's required authority.

A signatory or contract admin who is not conflicted against the contract's counterparty does not need to meet that extra signing-authority requirement.

A signatory and a contract admin must not sign a contract for a conflicted counterparty when their signing authority is below the contract's required authority.

A contract admin may execute a signed contract.

A request by a signatory to sign a contract that does not trip any prohibition above must be able to succeed.
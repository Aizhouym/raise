# Warehouse Zone Access

## Natural-Language Scenario

The system manages warehouse zone access during order picking.

The people involved are pickers, forklift operators, zone supervisors, warehouse managers, and security officers. One person may hold both the picker and forklift operator role at the same time.

The resources are orders and zones. Every order records who requested it, its picker, its items, its item count, its pick list code, its status, its destination zone, and when it was released.

Every zone records its zone code, sensitivity, zone group, whether it is physically locked out, and its operational status.

Each request carries the current time, whether the requester has an on-site badge, and whether an emergency has been declared.

A picker, forklift operator, or zone supervisor may access a zone only while the zone is in the open operational state and its physical lockout flag is clear.

A picker, forklift operator, or zone supervisor must not access a zone that is not in the open operational state while its physical lockout flag is clear.

When the physical lockout flag is not clear, this open-state rule does not decide whether the zone may be accessed.

A request by a picker to access a zone that does not trip any prohibition above must be able to succeed.
# Datacenter Cage Work Order Approval

## Natural-Language Scenario

The system manages physical access work orders for datacenter cages.

The people involved are facility techs, tenant engineers, security ops, and escorts. One person may hold both the facility tech and escort role at the same time.

The resources are cages, work orders, and access badges. Every cage records its tenant, zone clearance, occupant list, site zone, whether an escort is required, and its status.

Every work order records its cage, who raised it, who approved it, and its status.

Every access badge records its holder and when it expires.

Each requester carries their clearance level and membership, and each request carries the current time, whether an escort is present, the maintenance window, and whether it comes from the on site network.

Security ops may approve a work order only while it is open.

Security ops must not approve a work order that is not open.

Security ops may approve a work order only when their access badge is still valid.

Security ops with an expired access badge must not approve a work order.

Security ops may approve a work order only when they belong under the site zone of the cage named by the work order.

Security ops who do not belong under the cage's site zone must not approve the work order.

A request by security ops to approve an open work order for a cage under their site zone, using a still-valid badge, must be able to succeed.
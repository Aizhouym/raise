# IoT Device Fleet Telemetry Access

## Natural-Language Scenario

The system manages telemetry access for an IoT and operational technology device fleet.

The people involved are operators, technicians, fleet admins, and service accounts. One person may hold both the operator and technician role at the same time.

The resources are devices, telemetry, and commands. Every device records its owner, site group, firmware tags, maintenance mode, and status, and every telemetry record records its device and sensitivity.

Each requester carries a clearance level and group membership.

Each request carries the source IP address, the current time, and the maintenance window.

An operator or fleet admin may read telemetry only when their clearance is at least as high as the telemetry sensitivity.

An operator or fleet admin must not read telemetry when their clearance is lower than the telemetry sensitivity.

An operator or fleet admin may read telemetry only when the request comes from an allowed network range.

A request from outside the allowed network range may still read telemetry when the device is in the lifecycle stage named for this exception.

An operator or fleet admin must not read telemetry from outside the allowed network range when the device is not in the lifecycle stage named for this exception.

A request by an operator to read telemetry that does not trip any prohibition above must be able to succeed.
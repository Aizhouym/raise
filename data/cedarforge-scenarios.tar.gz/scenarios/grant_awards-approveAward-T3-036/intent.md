# Federal Grant Award Management

## Natural-Language Scenario

The system manages federal grant applications and award approvals.

The people involved are reviewers, program officers, grants officers, and applicants. One person may hold both the reviewer and program officer roles, or both the program officer and grants officer roles, at the same time.

The resources are applications and awards. Every application records its applicant, assigned reviewers, funding tier, requested amount, program code, and status.

Every award records its application, who approved it, who obligated it, its amount, its high-risk flag, and its status.

Each requester carries their conflicted applications and approval authority.

Each request carries the current time, whether it is on the government network, and whether a funding emergency has been declared.

A program officer or grants officer may approve an award only when their approval authority covers the application's funding tier.

A program officer or grants officer must not approve an award when their approval authority does not cover the application's funding tier.

A program officer or grants officer may approve an award only during a permitted approval window.

Outside a permitted approval window, a program officer or grants officer must not approve an award.

When a funding emergency has been declared, a program officer may approve an award above their normal authority tier.

When no funding emergency has been declared, a program officer may not approve an award above their normal authority tier.

When a funding emergency has been declared, the emergency rule wins over the normal authority-tier limit.

A request by a program officer to approve an award that does not trip any prohibition above must be able to succeed.
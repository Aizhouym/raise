# CI/CD Deployment Approval — Separation of Duty, Risk Threshold, and Emergency Override

## Natural-Language Scenario

The system manages the approval step of a continuous integration and deployment pipeline for a software company.

The people involved are committers, approvers, release managers, and site reliability engineers (SREs); one person may hold both the committer and approver roles at the same time, and one person may also hold both the approver and release manager roles at the same time.

The resources are deployments and artifacts; every deployment records its committer, its approver, its target environment, its change-risk score, its artifact, and its status, and every artifact records who built it, whether it is signed, its build tags, and its status.

Each requester carries a deploy tier, and each request carries the current time, the source IP address, and whether it is a declared emergency change.

A committer may commit code, and an SRE or release manager may sign an artifact once it is built.

An approver or release manager may approve a deployment once its risk has been assessed.

A committer who authored a deployment may not approve it when that deployment's change-risk score is 8 or higher on a 10-point scale, since a high score requires extra scrutiny from someone other than the author.

When the change-risk score is 7 or lower, the committer who authored the deployment may approve it themselves.

A declared emergency change lets a release manager approve a deployment they themselves authored, even when its change-risk score is 8 or higher.

When no emergency change is declared, a release manager who authored a high-risk deployment may not approve it either, just like any other committer.

Neither an approver nor a release manager may approve a deployment they personally authored when its change-risk score is 8 or higher, unless a release manager is invoking a declared emergency change.

When a declared emergency change is present on the request, that exception overrides the separation-of-duty restriction and the release manager's self-approval is allowed.

A release manager or approver may promote an approved deployment to its target environment, and an SRE may execute the deploy once it is promoted.

A request by an approver who did not author a deployment with a change-risk score of 9 to approve it must be able to succeed.

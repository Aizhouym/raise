# Inpatient Record Viewing — Clearance, Care Team, and Ward Restrictions

## Natural-Language Scenario

The system manages inpatient medical records, prescriptions, and lab orders on a hospital ward.

The people involved are attending physicians, residents, nurses, and pharmacists. One person may hold both the attending physician and pharmacist roles at the same time, and one person may hold both the resident and pharmacist roles at the same time.

The resources are medical records, prescriptions, and lab orders. Every medical record records its patient, its assigned care team, its ward, its sensitivity level, and its status. Every prescription records its patient, the physician who prescribed it, and its status. Every lab order records its patient.

An attending physician, a resident, or a nurse may view a medical record only when their own cleared level is at least as high as the record's sensitivity level, so a requester cleared for confidential material may view a record marked general or confidential but not one marked restricted.

An attending physician, a resident, or a nurse may view a medical record only when they are listed on that record's care team. A requester who is on the record's care team and holds sufficient clearance may view it, but a requester who is not on the care team must not view the record even if their cleared level is high enough.

An attending physician, a resident, or a nurse may view a medical record only when their own ward matches the record's ward. A requester whose ward matches the record's ward, and who is on the care team with sufficient clearance, may view it, but a requester assigned to a different ward must not view the record even if they are on the care team and hold sufficient clearance.

An attending physician, a resident, and a nurse must not view a medical record if they lack sufficient clearance for its sensitivity level, are not on its care team, or are assigned to a different ward than the record's ward.

A request by an attending physician to view a medical record where the record's sensitivity is covered by the physician's clearance, the physician is on the care team, and the physician's ward matches the record's ward must be able to succeed.

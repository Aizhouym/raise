# Carrier Network Change Control

## Natural-Language Scenario

The system manages carrier network change approval and maintenance-window implementation.
The people involved are network engineers, senior engineers, change managers, CAB approvers, and auditors.
One person may be both a network engineer and a senior engineer at the same time.
The resources are change requests and implementations.
Every change request records its requester, implementer, approver, change risk, affected node count, rollback step count, estimated cost, change code, emergency-change marker, change category, status, and maintenance window start.
Every implementation records its change, who implemented it, and when it was implemented.
Each request carries the current time, whether it is on the management network, whether a freeze waiver has been granted, and whether a major incident has been declared.
A network engineer or senior engineer may implement a change only when a change-freeze waiver is present.
Without a change-freeze waiver, neither a network engineer nor a senior engineer may implement the change.
When no major incident has been declared, the person who approved a change may not implement it.
When a major incident has been declared, the approving engineer may also implement the change.
When a major incident has been declared, the emergency allowance wins over the usual independence requirement between approval and implementation.
A request by a network engineer to implement a change that does not trip any prohibition above must be able to succeed.
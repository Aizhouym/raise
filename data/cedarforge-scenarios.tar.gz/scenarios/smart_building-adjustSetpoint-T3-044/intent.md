# Smart-Building Zone Control

## Natural-Language Scenario

The system manages actuator setpoints for smart-building zones.

The people involved are facility managers, zone controllers, maintenance techs, and tenants. One person may hold both the facility manager and zone controller role at the same time.

The resources are actuators, zones, and commission requests. Every actuator records its owner, zone group, device tags, maintenance flag, and status.

Each requester carries a control tier and membership list.

Each request carries the current time, whether occupancy is detected, whether it comes from the on-site network, and whether a maintenance override is active.

A zone controller, maintenance tech, or facility manager may adjust a setpoint only when they own the actuator.

A zone controller, maintenance tech, or facility manager who does not own the actuator must not adjust its setpoint.

An owned actuator's setpoint may be adjusted only when the actuator is online and is not in maintenance or decommissioned status.

A zone controller, maintenance tech, or facility manager must not adjust the setpoint of an actuator that is in maintenance or decommissioned status.

When an active maintenance override is present, a maintenance tech may adjust a device that is in maintenance status.

When an active maintenance override is not present, a maintenance tech must not adjust a device that is in maintenance status.

When an active maintenance override is present, the maintenance override rule wins over the online-actuator requirement.

A request by a zone controller to adjust a setpoint that does not trip any prohibition above must be able to succeed.
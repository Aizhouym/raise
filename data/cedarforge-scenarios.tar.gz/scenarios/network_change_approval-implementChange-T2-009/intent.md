# Network Change Implementation — Separation of Duty with Change-Freeze Waiver

## Natural-Language Scenario

The system manages network change control approval and maintenance-window implementation at a telecommunications carrier.

The people involved are network engineers, senior engineers, change managers, CAB approvers, and auditors. One person may hold both the network engineer and the senior engineer role at the same time.

The resources are change requests and implementation records. Every change request records the engineer who requested it, the engineer who implemented it, the person who approved it, its assessed change risk, its affected-node count, its rollback-step count, its estimated cost, its change code, whether it is an emergency change, its change category, its current status, and its maintenance-window start. Every implementation record records the change it belongs to, who carried it out, and when it was carried out.

Each request carries the current time, whether it comes from the management network, whether a change-freeze waiver has been granted, and whether a major incident has been declared.

A change is drafted, assessed, and approved before it can be implemented, and only a network engineer or a senior engineer carries out the implementation.

An auditor may view the change log.

The person who approved a change may not be the one who implements it, and an engineer who did not approve the change may implement it.

The separation-of-duty rule is waived when a change-freeze waiver has been granted on the request, letting the approving engineer implement the change, and without such a waiver the approver may not implement it.

Neither a network engineer nor a senior engineer who approved a change may implement it unless a change-freeze waiver has been granted.

A request by a network engineer who did not approve a change to implement it, tripping no prohibition above, must be able to succeed.

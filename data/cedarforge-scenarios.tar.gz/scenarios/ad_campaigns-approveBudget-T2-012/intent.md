# Campaign Budget Approval

## Natural-Language Scenario

The system manages advertising campaigns and creative review before launch.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors. One person may hold both the account manager and the campaign director role at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, who prepared it, its budget, its contingency, its budget tier, its risk labels, its scheduled start, and its status.

Every creative records its campaign, who submitted it, its risk rating, its content tags, and its status.

Each requester carries a reviewer level.

Each request carries the current time, whether multifactor authentication was used, whether the device is trusted, and whether this is an emergency launch.

An account manager or campaign director who prepared a campaign may not approve its budget when the campaign's budget tier requires that restriction.

For campaigns below that budget tier, the account manager or campaign director who prepared the campaign may approve its budget.

A request by a campaign director to approve a budget that does not trip any prohibition above must be able to succeed.
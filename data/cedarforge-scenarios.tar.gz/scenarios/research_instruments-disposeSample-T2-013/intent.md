# Research Facility Sample Disposal

## Natural-Language Scenario

The system manages sample disposal in a research facility with controlled laboratory access.

The people involved are technicians, supervisors, safety officers, and visitors. One person may hold both the supervisor and technician role at the same time.

The resources are instruments, samples, and access badges. Every instrument records its hazard class, whether it is under maintenance, and its status, every sample records who opened it and its status, and every access badge records its holder and when it expires.

Each requester carries certifications.

Each request carries local time, whether the person is on site, and whether a supervisor is present.

A technician may dispose a sample only after it has been opened when the technician is not physically on site.

When the technician is physically on site, the sample-opening requirement does not block disposal.

A technician must not dispose a sample that has not been opened when the technician is not physically on site.

A request by a technician to dispose a sample that does not trip any prohibition above must be able to succeed.
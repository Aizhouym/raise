# Prescription Writing, Countersignature, then Dispensing — Independence, Continuity, and Countersign Gate

## Natural-Language Scenario

The system manages inpatient prescriptions from writing through countersignature to dispensing.
The people involved are attending physicians, residents, nurses, and pharmacists. A single person may hold both the attending physician and the pharmacist role, and one person may also hold both the resident and the pharmacist role.
The resources are medical records, prescriptions, and lab orders. Every prescription records its patient, its prescriber, and its status.
Each request carries the current shift, whether an emergency has been declared, and whether multi-factor authentication was used.
In this workflow a prescription is first written, then countersigned, and then dispensed, and each later step can see the prescription's status and who prescribed it as recorded by the earlier steps.
An attending physician may not write a prescription for themselves, and an attending physician may write a prescription for another patient.
When the prescription is still in its draft stage, an attending physician may write one naming themselves.
The attending physician who prescribed a prescription must be the one who countersigns it, and another attending physician who did not prescribe it may not countersign it.
When the prescription is in that same draft stage, an attending physician who did not prescribe it may countersign it.
A pharmacist may dispense a prescription only after it has been countersigned, and a request to dispense one not yet countersigned is refused.
When multi-factor authentication was used, a pharmacist may dispense a prescription even before it has been countersigned.
An attending physician must not countersign a prescription they did not prescribe unless it is in its draft stage.
A run through the workflow by an attending physician who writes a prescription for a patient, countersigns it themselves, and hands it to a pharmacist who dispenses it after countersignature, tripping no prohibition above, must be able to succeed.

# Invoice Approval and Payment

## Natural-Language Scenario

The system manages invoice approval and payment.

The people involved are clerks, approvers, finance managers, and auditors. One person may hold both the clerk and the approver role at the same time.

The resources are invoices and payments. Every invoice records its creator, approver, amount, surcharge, line item count, status, cost center, and submission time.

Each request carries the current time, whether it is on the corporate network, and whether an emergency has been declared.

An approver may approve an invoice, and a finance manager may approve an invoice.

An approver who created an invoice may not approve it.

A finance manager who created an invoice may not approve it.

An invoice may be approved only after it has been submitted when the request falls within business hours.

Outside business hours, the submitted-status requirement above does not apply.

Neither an approver nor a finance manager may approve an invoice they created.

A request by an approver to approve an invoice that does not trip any prohibition above must be able to succeed.
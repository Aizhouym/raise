# Retail Orders and Refunds

## Natural-Language Scenario

The system manages retail orders, refunds, and refund handling.

The people involved are customers, service reps, managers, and auditors. One person may hold both the service rep and manager role at the same time.

The resources are orders and refunds. Every order records its customer, who placed it, its item total, its tax amount, its loyalty tier, whether it contains card data, and its status.

Every refund records its order, who issued it, and its amount.

A customer may place an order.

A service rep or manager who placed an order may not issue its refund when the refund amount does not cross the money threshold and the customer's loyalty tier is below the required level.

When the refund amount crosses the money threshold, the service rep or manager who placed the order may issue its refund.

When the customer's loyalty tier is at least the required level, the service rep or manager who placed the order may issue its refund.

A service rep must not issue a refund for an order they placed unless one of the stated exceptions applies.

A manager must not issue a refund for an order they placed unless one of the stated exceptions applies.

A request by a service rep to issue a refund that does not trip any prohibition above must be able to succeed.
# Immigration Case Adjudication

## Natural-Language Scenario

The system manages immigration cases, applicant records, and security checks.

The people involved are adjudication officers, supervisory officers, background investigators, and records clerks. One person may hold both the adjudication officer and background investigator roles, or both the supervisory officer and adjudication officer roles.

The resources are cases, security checks, and applicant records. Every case records its applicant, assigned officer, case team, field office, and status.

Every security check records its case, investigator, and status.

Every applicant record records its applicant, assigned officer, need-to-know team, data sensitivity, and status.

Each requester carries a clearance and a list of recused cases.

Each request carries whether it is on the government network, the current time, and whether supervisor approval is present.

A background investigator or supervisory officer may clear a security check only while the check is pending.

A background investigator or supervisory officer may not clear a security check that is not pending.

Only a background investigator or supervisory officer may clear a security check, subject to the other requirements here.

A requester who is neither a background investigator nor a supervisory officer must not clear a security check.

A background investigator or supervisory officer may clear a security check only during the permitted window.

A background investigator or supervisory officer must not clear a security check outside the permitted window.

A request by a background investigator to clear a pending security check during the permitted window, tripping no prohibition above, must be able to succeed.
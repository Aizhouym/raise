# Streaming Content Moderation — Publisher Independence and Eligibility Gate

## Natural-Language Scenario

The system manages content moderation on a streaming content platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and the moderator role at the same time.

The resources are content and reports. Every content record notes its publisher, the subscription tier it requires, the date it comes off embargo, the regions where it may be shown, its labels, and its status. Every report records the content it concerns and the subscriber who filed it.

A moderator may not moderate content they published.

A moderator may moderate content only when they also hold the editor role.

A moderator who does not hold the editor role may not moderate content, even if no other prohibition applies.

A moderator may moderate content only when the content carries the flagged label.

A moderator may not moderate content that does not carry the flagged label, even if that moderator holds the editor role.

A request by a moderator who did not publish the content, who holds the editor role, and whose content carries the flagged label must be able to succeed.

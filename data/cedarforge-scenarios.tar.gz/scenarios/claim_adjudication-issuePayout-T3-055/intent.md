# Claim Payout

## Natural-Language Scenario

The system manages insurance claim adjudication and payout.

The people involved are adjusters, reviewers, claims managers, payout officers, fraud analysts, and auditors.

One person may hold both the adjuster and reviewer roles, or both the reviewer and payout officer roles, at the same time.

The resources are claims and payouts.

Every claim records its handler, approver, claim amount, deductible, line item count, status, claim code, fraud hold, and filing time.

Every payout records its claim, issuer, and amount.

A payout officer or claims manager who approved a claim may not issue its payout when the claim is flagged with a fraud hold and the claim's line item count does not cross the threshold.

When the claim's line item count crosses the threshold, the approver may issue its payout.

When the claim is not flagged with a fraud hold, the approver may issue its payout.

A request by a payout officer to issue a payout that does not trip any prohibition above must be able to succeed.
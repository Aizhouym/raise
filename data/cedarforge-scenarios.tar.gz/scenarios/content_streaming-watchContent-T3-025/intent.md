# Streaming Content Access

## Natural-Language Scenario

The system manages viewing and moderation for a streaming content platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and the moderator role at the same time.

The resources are content and reports. Every content record stores its publisher, required tier, embargo time, allowed regions, labels, and status.

Each subscriber carries a subscription tier and region, and each request carries the current time and whether the device is trusted.

A subscriber may watch content only when the subscriber's tier meets the content's required tier.

A subscriber may watch content only after the content's embargo time has passed.

Before the embargo time has passed, a subscriber must not watch the content.

The tier requirement and embargo requirement apply to content that is published and not removed.

A subscriber must not watch removed content.

A request by a subscriber to watch content that does not trip any prohibition above must be able to succeed.
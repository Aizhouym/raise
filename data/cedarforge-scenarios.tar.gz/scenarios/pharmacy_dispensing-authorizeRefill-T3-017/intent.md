# Controlled-Substance Refill Authorization

## Natural-Language Scenario

The system manages outpatient controlled-substance prescriptions, dispensing, and refill authorization.

The people involved are pharmacy technicians, staff pharmacists, pharmacists in charge, and prescribers. One person may hold both the staff pharmacist and pharmacist in charge role at the same time.

The resources are prescriptions and dispense records. Every prescription records its prescriber, patient, entered by, verified by, prescriber's DEA number, schedule level, refills remaining, and status.

Each requester carries dispense authority and state license.

Each request carries whether the prescription-drug-monitoring database was checked, whether mfa was used, whether it came from the pharmacy network, the current time, and whether there is an emergency override.

A pharmacist in charge may authorize a refill only after the prescription has been dispensed when no refills remain.

When the prescription has refills remaining above zero, the pharmacist in charge may authorize the refill without relying on the prior dispensing requirement.

A pharmacist in charge may authorize a refill only when the prescription-drug-monitoring database was checked before the refill.

A pharmacist in charge must not authorize a refill when the prescription-drug-monitoring database was not checked before the refill.

A pharmacist in charge must not authorize a refill for an undispensed prescription when no refills remain.

A request by a pharmacist in charge to authorize a refill that does not trip any prohibition above must be able to succeed.
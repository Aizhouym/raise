# Port Cutover Completion

## Natural-Language Scenario

The system manages local number portability authorization and cutover for a carrier.

The people involved are porting specialists, porting supervisors, fraud reviewers, line technicians, and auditors. One person may hold both the porting specialist and fraud reviewer roles, or both the line technician and porting specialist roles.

The resources are port requests and port completions. Every port request records its initiator, authorizer, assigned technician, account numbers, number block size, carrier code, port type, subscriber region, status, and requested time.

Every port completion records its port request, who completed it, and when it was ported.

Each request carries the current time, whether it is on the carrier network, whether a port freeze override has been declared, and whether there is a regulator escalation.

For a port request whose number-block size crosses the threshold requiring supervisor completion, the assigned technician must be the one who completes the cutover.

For a port request below that threshold, the assigned-technician requirement does not bind.

A line technician or porting supervisor who is not the assigned technician must not complete a port request whose number-block size crosses the supervisor-completion threshold.

A request by a line technician to complete a port that does not trip any prohibition above must be able to succeed.
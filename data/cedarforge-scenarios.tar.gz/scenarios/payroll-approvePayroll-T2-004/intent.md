# Payroll Approval — Preparer Exclusion

## Natural-Language Scenario

The system manages personnel records and payroll processing for an organization.
The people involved are employees, managers, HR specialists, and payroll admins. One person may hold both the manager and employee roles at the same time.
The resources are payroll runs, employee records, and leave requests. Every payroll run records who prepared it, who approved it, its amount, and its status.
A manager may approve a payroll run, and so may a payroll admin.
A manager or a payroll admin must not approve a payroll run that they themselves prepared.
This prohibition applies only when the requester is the payroll admin who prepared the run.
When the requester is a manager who prepared the run, they are not covered by this prohibition and may still approve it.
An HR specialist may view an employee record.
A manager may approve a leave request.
A request by a manager to approve a payroll run that they did not prepare and that trips no other rule must be able to succeed.

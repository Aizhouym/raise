# Guest Folio Adjustment Posting

## Natural-Language Scenario

The system manages guest folio adjustment posting and approval.

The people involved are front desk agents, night auditors, accounting clerks, revenue managers, and auditors.

One person may hold both the front desk agent and night auditor roles, and one person may hold both the accounting clerk and revenue manager roles.

The resources are folios and credit notes, and every folio records its guest, posted by, approved by, folio balance, adjustment amount, original charge, line item count, folio code, dispute category, property region, guest segment, charges, vip flag, status, and checkout deadline.

Each request carries the current time, whether it comes from the property network, whether the dispute is verified, and whether a general manager override is declared.

A front desk agent or night auditor may post an adjustment only while the folio is open.

When the folio is not open, neither a front desk agent nor a night auditor may post an adjustment.

A request by a front desk agent to post an adjustment that does not trip any prohibition above must be able to succeed.
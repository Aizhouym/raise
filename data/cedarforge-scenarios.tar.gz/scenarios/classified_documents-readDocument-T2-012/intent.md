# Classified Documents

## Natural-Language Scenario

The system manages reading classified documents inside an organization.

The people involved are analysts, officers, security admins, and contractors. One person may hold both the analyst and the officer role at the same time.

The resources are documents, dossiers, and access badges. Every document records its owner, classification, compartments, and status.

Each requester carries a clearance, compartments, and nationality.

Each request carries whether it comes from the intranet and the current time.

An analyst or officer may read a document from outside the intranet only when their clearance is at least as high as the document's classification.

When the request comes from the intranet, this clearance comparison does not block the analyst or officer from reading the document.

An analyst must not read a document from outside the intranet when their clearance is lower than the document's classification.

An officer must not read a document from outside the intranet when their clearance is lower than the document's classification.

A request by an analyst to read a document that does not trip any prohibition above must be able to succeed.
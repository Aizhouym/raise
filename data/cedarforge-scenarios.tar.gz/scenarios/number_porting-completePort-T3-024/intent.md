# Port Completion Authorization

## Natural-Language Scenario

The system manages local number portability authorization and cutover for a carrier.

The people involved are porting specialists, porting supervisors, fraud reviewers, line technicians, and auditors. One person may hold both the porting specialist and fraud reviewer roles, or both the line technician and porting specialist roles.

The resources are port requests and port completions. Every port request records its initiator, authorizer, assigned technician, account numbers, number-block size, carrier code, port type, subscriber region, status, and requested time.

Each request carries the current time, whether it is on the carrier network, whether a port-freeze override was declared, and whether there is a regulator escalation.

A line technician or porting supervisor may complete a port only after the port request has been authorized.

Neither a line technician nor a porting supervisor may complete a port request that has not been authorized.

When the number-block size crosses the supervisor-completion threshold, only a porting supervisor may complete the port.

When the number-block size does not cross that threshold, a line technician may complete the port if no other rule blocks it.

When regulator escalation is present, the completion rule applies to the escalated port request.

When regulator escalation is absent, that escalation-based restriction does not block completion.

An auditor may view the audit log.

A request by a line technician to complete an authorized port with no supervisor-size requirement and no regulator-escalation restriction must be able to succeed.
# Kubernetes Namespace Token Revocation

## Natural-Language Scenario

The system manages service account token revocation for Kubernetes namespaces.

The people involved are deployers, maintainers, cluster operators, and service accounts. One person may hold both the deployer and maintainer role at the same time.

The resources are namespaces, workloads, namespace secrets, and service account tokens. Every namespace records its members, team group, and environment, and every service account token records its subject, bound namespace, issuer, expiration time, and status.

Each requester carries clearance, granted scope, and group membership.

Each request carries source IP, current time, whether it is an emergency change, and whether MFA was used.

A cluster operator may revoke a service account token only while the token is issued or active.

A cluster operator must not revoke a service account token that is already revoked.

A cluster operator may revoke a service account token only when the operator belongs under the team group of the token's bound namespace.

A cluster operator who does not belong under the team group of the token's bound namespace must not revoke that token.

A cluster operator may revoke a service account token only when MFA was used.

A cluster operator who has not used MFA must not revoke a service account token.

A request by a cluster operator to revoke an issued or active token for a namespace whose team group includes that operator, with MFA used, must be able to succeed.
# Reading Adjustment

## Natural-Language Scenario

The system manages meter readings, account data, and billing runs for utility billing.

The people involved are meter readers, billing analysts, billing managers, data stewards, and auditors. One person may hold both the meter reader and data steward roles, or both the billing analyst and meter reader roles.

The resources are billing runs and meter accounts.

Every billing run records its account, preparer, approver, bill amount, usage, rate, rate class, region, account tier, status, and preparation time.

Every meter account records its account holder, who last read it, tier, adjustment count, last bill amount, rate class, region, status, and last read time.

Each request carries the current time, whether it comes from the corporate network, and whether an emergency has been declared.

A meter reader or data steward who last recorded a meter account's reading may not adjust that reading when the account's most recent bill amount crosses the money threshold.

When the account's most recent bill amount does not cross the money threshold, the meter reader or data steward who last recorded the reading may adjust it.

A meter reader must not adjust a reading they last recorded when the account's most recent bill amount crosses the money threshold.

A data steward must not adjust a reading they last recorded when the account's most recent bill amount crosses the money threshold.

A request by a meter reader to adjust a reading that does not trip any prohibition above must be able to succeed.
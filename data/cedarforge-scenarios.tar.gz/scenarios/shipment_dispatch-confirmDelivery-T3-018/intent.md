# Shipment Delivery Confirmation

## Natural-Language Scenario

The system manages carrier shipment dispatch and delivery confirmation.

The people involved are planners, drivers, dispatch managers, depot supervisors, and auditors. One person may hold both the planner and dispatch manager roles at the same time.

The resources are shipments and delivery receipts. Every shipment records its planner, driver of record, piece count, gross weight in kilograms, status, tracking code, origin depot, hazmat class, and delivery window end, and every delivery receipt records its shipment, recipient, and signed-at time.

Each request carries the current time, whether it is on the depot network, whether expedite has been declared, and proof of delivery.

A driver or depot supervisor may confirm delivery only after the shipment has reached the intransit state.

A driver or depot supervisor must not confirm delivery for a shipment that has not reached the intransit state.

The driver of record who dispatched the shipment must be the one who confirms its delivery.

Neither a different driver nor a depot supervisor may confirm delivery for that shipment.

Delivery may be confirmed only before the shipment's delivery window end.

After the shipment's delivery window end, neither a driver nor a depot supervisor may confirm its delivery.

A request by a driver to confirm a delivery that does not trip any restriction above must be able to succeed.
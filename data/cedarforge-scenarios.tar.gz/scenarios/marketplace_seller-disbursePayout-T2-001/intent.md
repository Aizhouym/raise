# Marketplace Seller Payout Disbursement

## Natural-Language Scenario

The system manages seller payouts and listings on an online marketplace.

The people involved are sellers, payout agents, finance approvers, and risk analysts. One person may hold both the payout agent and finance approver roles at the same time.

The resources are seller accounts, listings, and payouts. Every seller account records its holder, kyc tier, region, fraud status, and watchlist codes. Every listing records its owner, category, price, category tier, risk labels, and status. Every payout records its account, who initiated it, who approved it, its amount, and its status.

A payout agent may disburse a payout only if the seller account tied to it is clear and not on fraud hold.

If the seller account is not clear or is on fraud hold, the payout agent may not disburse the payout.

A payout agent may disburse a payout only when the payout carries a recorded approver.

If the payout has no recorded approver, the payout agent may not disburse it; once an approver has been recorded on the payout, this condition is satisfied.

A payout agent must not disburse a payout when the seller account is not clear, when the seller account is on fraud hold, or when the payout has no recorded approver.

A finance approver may record their approval on a payout before it is disbursed.

A risk analyst may set a fraud hold on a seller account.

A request by a payout agent to disburse a payout whose seller account is clear and not on fraud hold, and which already carries a recorded approver, must be able to succeed.

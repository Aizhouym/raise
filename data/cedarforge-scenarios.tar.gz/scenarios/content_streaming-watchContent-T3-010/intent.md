# Streaming Content Access

## Natural-Language Scenario

The system manages viewer access to content on a streaming platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and moderator role at the same time.

The resources are content and reports. Every content item records its publisher, required tier, embargo time, allowed regions, labels, and status.

Each subscriber carries a subscription tier and region.

Each request carries the current time and whether the device is trusted.

A subscriber may watch content only when the subscriber's tier meets the content's required tier, unless an exception below applies.

A subscriber whose tier does not meet the content's required tier may still watch the content when it is licensed in the subscriber's region.

A subscriber whose tier does not meet the content's required tier must not watch the content when it is not licensed in the subscriber's region.

A subscriber whose tier does not meet the content's required tier may still watch the content when the content is published and not removed.

A subscriber whose tier does not meet the content's required tier must not watch the content when the content is removed.

A request by a subscriber to watch content that does not trip any prohibition above must be able to succeed.
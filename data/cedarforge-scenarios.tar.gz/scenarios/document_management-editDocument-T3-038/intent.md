# Enterprise Document Editing

## Natural-Language Scenario

The system manages controlled business documents in an enterprise document workspace.

The people involved are authors, editors, viewers, and compliance officers. One person may hold both the author and the editor role at the same time.

The resources are documents and workspaces. Every document records its owner, share list, classification, version lock, labels, and status.

Each requester carries a clearance level.

Each request carries whether it is on the corporate network and the current time.

An author or editor may edit a document only if their clearance is high enough for the document's classification.

A document may be edited only while it is in draft when the request is not on the corporate network.

When the request is on the corporate network, the draft-only requirement does not block editing.

Neither an author nor an editor may edit a document when their clearance is not high enough for the document's classification.

A request by an author to edit a document that does not trip any prohibition above must be able to succeed.
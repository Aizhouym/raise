# Contract Signature Authorization

## Natural-Language Scenario

The system manages the lifecycle of contracts, from drafting through review to signature and execution, for a legal department.

The people involved are drafters, reviewers, signatories, and contract admins; one person may be both a drafter and a reviewer, and one person may be both a reviewer and a signatory.

The resources are contracts and signatures; every contract records its drafter, its reviewer, its counterparty, its contract value, its required authority tier, its effective date, and its status, and every signature records the contract it belongs to, who signed it, and the amount signed for.

Each requester carries a signing authority tier and a list of counterparties they are conflicted with, and each request carries the current date, whether it was made from the corporate network, whether multi-factor authentication was used, and whether an escalation has been approved.

A signatory or a contract admin may sign a contract.

A signatory or a contract admin who reviewed that same contract must not be the one to sign it.

A signatory's delegated signing-authority tier must be at least as high as the contract's required authority tier before they may sign it.

When multi-factor authentication was used to make the signing request, a signatory may sign the contract even if their delegated authority tier is lower than the contract's required authority tier.

Separately, when an escalation for the contract has been approved, a signatory may sign it even though their delegated authority tier does not reach the contract's required tier.

When an approved escalation and the authority-tier requirement disagree, the approved escalation wins and the signature is allowed to proceed.

A request by a signatory with a tier-3 authority level, who did not review the contract, to sign a contract that requires only a tier-2 authority level, must be able to succeed.

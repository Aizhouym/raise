# Award Approval and Fund Obligation with Self-Award and Separation Controls

## Natural-Language Scenario

This document describes how a federal grant award system controls the approval of awards and the obligation of their funds.
The people involved are reviewers, program officers, grants officers, and applicants, and one person may hold both reviewer and program officer, or both program officer and grants officer, at the same time.
The resources are applications, which record their applicant, assigned reviewers, funding tier, requested amount, program code, and status; and awards, which record their application, who approved them, who obligated their funds, amount, whether they carry a high-risk flag, and their status.
Each requester carries an approval authority level.
An award is first approved and then its funds are obligated on the same award, and the obligation step can see the award's status, who approved it, and who obligated its funds.
When approving an award, the program officer or grants officer who approves it must hold an approval authority that meets or exceeds the application's funding tier.
A program officer or grants officer whose approval authority is below the application's funding tier may not approve it.
An award may be approved only when the requester is the applicant named on the application, as a self-award check.
When the requester is not the applicant named on the application, the award may not be approved at this step.
When obligating funds, the grants officer who approved an award may not be the one who obligates its funds.
Funds may be obligated only when the award carries a high-risk flag requiring extra scrutiny.
When the award does not carry a high-risk flag, its funds may not be obligated.
A run through the workflow by a program officer that trips none of these restrictions must be able to succeed.

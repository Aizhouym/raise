# Reading Adjustment — Review Gate, Amount Restriction, and Region Exception

## Natural-Language Scenario

The system manages meter data and the preparation and approval of billing runs.

The people involved are meter readers, billing analysts, billing managers, data stewards, and auditors, and one person may hold both the meter-reader and data-steward roles at the same time or both the billing-analyst and meter-reader roles at the same time.

The resources are billing runs and meter accounts, where every billing run records its account, its preparer, its approver, its bill amount, its metered usage, its rate, its rate class, its region, its account tier, its status, and when it was prepared, and every meter account records its account holder, who last read it, its tier, its adjustment count, its last bill amount, its rate class, its region, its status, and when it was last read.

A meter reader may record a reading.

A meter reader or a data steward may adjust a reading only while the account is under review, and a request to adjust a reading on an account that is not under review is refused.

A meter reader or a data steward may adjust a reading only when the account's most recent bill amount is above the money threshold, and an account whose most recent bill amount is at or below that threshold may not have its reading adjusted.

This bill-amount restriction is relaxed when the account falls within the adjuster's own region hierarchy, so a reader may adjust its reading regardless of the amount, and when the account lies outside the adjuster's region hierarchy the bill-amount restriction still applies.

Neither a meter reader nor a data steward may adjust a reading on an account that is not under review.

A request by a meter reader to adjust a reading on an account that is under review and that falls within the reader's own region hierarchy must be able to succeed.

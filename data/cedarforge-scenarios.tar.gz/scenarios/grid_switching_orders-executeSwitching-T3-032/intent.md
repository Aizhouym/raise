# Switching Order Execution

## Natural-Language Scenario

The system manages authorization and field execution of grid switching orders.

The people involved are planners, shift supervisors, operators, control room operators, and auditors. One person may hold both the planner and shift supervisor roles at the same time, and one person may hold both the operator and control room operator roles at the same time.

The resources are switching orders and lockout tags. Every switching order records its planner, executor, feeder, voltage level, circuit count, status, scheduled start, and scheduled end.

Every lockout tag records its switching order, the person who applied it, and its feeder.

Each request carries the current time, whether it comes from the SCADA control network, whether lockout tagout has been verified, and whether an outage emergency has been declared.

An operator or control room operator may execute a switching order only after it has been authorized when the request comes from the SCADA control network and the order switches enough circuits to require a control room operator.

When the request does not come from the SCADA control network, or when the order switches fewer circuits than that threshold, the authorization-before-execution requirement does not apply.

An operator must not execute a switching order from the SCADA control network when the order switches enough circuits to require a control room operator and the order has not been authorized.

A control room operator must not execute a switching order from the SCADA control network when the order switches enough circuits to require a control room operator and the order has not been authorized.

A request by an operator to execute a switching order that does not trip any prohibition above must be able to succeed.
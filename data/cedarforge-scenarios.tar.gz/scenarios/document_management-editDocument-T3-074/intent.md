# Enterprise Document Management

## Natural-Language Scenario

The system manages documents in an enterprise workspace.

The people involved are authors, editors, viewers, and compliance officers. One person may hold both the author and the editor role at the same time.

The resources are documents and workspaces. Every document records its owner, share list, classification, version lock state, labels, and status.

Each requester carries a clearance level.

Each request carries whether it is on the corporate network and the current time.

An author or editor may edit a document only when the request is on the corporate network.

An author or editor must not edit a document when the request is outside the corporate network.

An author or editor may edit a document only while it is in draft, unless they own the document.

An author or editor who owns a document may edit it even when it is not in draft, as long as the request is on the corporate network.

An author or editor who does not own a document must not edit it when it is not in draft.

A request by an author on the corporate network to edit a draft document that does not trip any prohibition above must be able to succeed.
# Work-Order Sign-off then Production Release — Independence, then Continuity

## Natural-Language Scenario

The system manages manufacturing work-order QA sign-off and production release.

The people involved are operators, inspectors, quality managers, production supervisors, and auditors. One person may hold both the operator and the inspector role at the same time, and one person may hold both the inspector and the quality manager role at the same time.

The resources are work orders and production releases. Every work order records its operator, its inspector, its part code, its defect count, whether it is on hold, its status, its station, and when it was created. Every production release records its work order, who released it, and its batch code.

Each request carries the current time, whether it comes from the plant network, and whether a deviation has been authorized.

In this workflow a work order is signed off first and then released to production, and the release step can see the work order's status and who signed it off as recorded by the sign-off step.

An inspector or a quality manager may sign off a work order, but the operator who performed the work may not QA-sign it off.

This separation is set aside when the request originates from the plant floor network, and in that case the operator who performed the work may sign it off.

An inspector or a quality manager may release a work order to production, and the same inspector who signed off the work order must perform its release.

This continuity requirement is set aside when the request originates from the plant floor network, and in that case an inspector or quality manager other than the one who signed off may release it.

An inspector or a quality manager who is the operator that performed the work must not sign it off when the request does not originate from the plant floor network.

A run through the workflow by an inspector who signs off a work order they did not perform and then releases it to production, tripping none of the prohibitions above, must be able to succeed.

# Streaming Content Platform

## Natural-Language Scenario

The system manages viewing and moderation for a streaming content platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and the moderator role at the same time.

The resources are content and reports. Every content item records its publisher, required tier, embargo time, allowed regions, labels, and status.

Each subscriber carries a subscription tier and a region.

Each request carries the current time and whether the device is trusted.

A subscriber may watch content only when the subscriber's tier meets the content's required tier.

A subscriber whose tier is below the content's required tier must not watch that content.

A subscriber may watch content only when the content is licensed in the subscriber's region.

A subscriber must not watch content that is not licensed in their region.

A subscriber may not watch content before its embargo time has passed.

After the embargo time has passed, the embargo no longer blocks the subscriber from watching that content.

A request by a subscriber to watch content that does not trip any prohibition above must be able to succeed.
# Pull Request Merge Approval and Branch Protection

## Natural-Language Scenario

The system manages merge approval and branch protection for pull requests on a source-code repository hosting platform.

The people involved are developers, reviewers, maintainers, and security leads. One person may hold both the developer and reviewer roles at the same time.

The resources are repositories, pull requests, and branches. Every repository records its owner, its team, its sensitivity level, whether its default branch is protected, its topics, and its status. Every pull request records the repository it belongs to, its author, who has approved it, its target branch, its approval count, the number of lines changed, whether it requires a security review, and its status. Every branch records its name and whether it is protected.

A maintainer must not merge a pull request that they themselves authored.

A pull request may not be merged until it has been approved.

Once a pull request's approval count has reached the required threshold of two approvals, it may be merged even without a separate approval mark on the pull request.

A pull request may be merged only when its target branch name matches an approved pattern, such as one that starts with "release/".

A request by a maintainer who did not author a pull request, to merge that pull request after it has been approved and its target branch is named "release/2.4", must be able to succeed.

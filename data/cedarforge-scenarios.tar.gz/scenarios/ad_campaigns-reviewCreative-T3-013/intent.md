# Creative Brand Safety Review

## Natural-Language Scenario

The system manages advertising campaigns and creative review before launch.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors. One person may hold both the account manager and the campaign director role at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, who prepared it, its budget, contingency, budget tier, risk labels, scheduled start, and status.

Every creative records its campaign, who submitted it, its risk rating, content tags, and status.

Each requester carries a reviewer level.

Each request carries the current time, whether MFA was used, whether the device is trusted, and whether it is an emergency launch.

A brand safety reviewer may review a creative only when their reviewer level is at least as high as the creative's risk rating.

A brand safety reviewer must not review a creative when their reviewer level is below the creative's risk rating.

A brand safety reviewer who submitted a creative may not brand-safety review that same creative.

A brand safety reviewer who did not submit the creative may brand-safety review it if the other requirements are also met.

A brand safety reviewer may review a creative when MFA was used.

A brand safety reviewer must not review a creative when MFA was not used.

A request by a brand safety reviewer to review a creative that does not trip any requirement above must be able to succeed.
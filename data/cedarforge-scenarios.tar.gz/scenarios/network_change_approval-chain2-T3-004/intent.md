# Network Change Approval then Implementation — Authority With CAB Waiver, then Approved-First

## Natural-Language Scenario

The system manages change-control approval and maintenance-window implementation for a carrier network.

The people involved are network engineers, senior engineers, change managers, CAB approvers, and auditors. One person may hold both the network engineer and senior engineer role at the same time.

The resources are change requests and implementation records. Every change request records who requested it, who is to implement it, who approved it, its assessed risk level, its affected-node count, its rollback-step count, its estimated cost, its change code, whether it is an emergency change, its change category, its status, and the start time of its maintenance window. Every implementation record notes the change it belongs to, who implemented it, and when.

Each request carries the current time, whether it comes from the management network, whether a change-freeze waiver has been granted, and whether a major incident has been declared.

In this workflow a change is first approved and then implemented, and the implementation step can see the change's status and who approved it as recorded by the approval step.

A change manager or CAB approver may approve a change only when their granted change-authority level is at least as high as the change's assessed risk level.

When the approver holds the CAB-approver role required for high-risk changes, this authority-dominance requirement is waived; an approver without that role remains bound by it.

A network engineer or senior engineer may implement a change only after it has been approved, and a change that has not been approved may not be implemented.

Neither a network engineer nor a senior engineer may implement a change that has not yet been approved.

A run through the workflow in which a change manager holding the high-risk CAB-approver role approves a change and a network engineer then implements the approved change, tripping no prohibition above, must be able to succeed.

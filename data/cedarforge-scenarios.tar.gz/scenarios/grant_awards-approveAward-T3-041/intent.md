# Federal Grant Award Approval

## Natural-Language Scenario

The system manages federal grant applications and award approval.

The people involved are reviewers, program officers, grants officers, and applicants. One person may hold both the reviewer and program officer roles, or both the program officer and grants officer roles, at the same time.

The resources are applications and awards. Every application records its applicant, assigned reviewers, funding tier, requested amount, program code, and status.

Every award records its application, who approved it, who obligated it, its amount, its high risk flag, and its status.

Each request carries the current time, whether it comes from the government network, and whether an emergency has been declared.

A program officer or grants officer may approve an award only while the award is pending when the request comes from the government network and is outside a permitted window.

When the request does not come from the government network, this pending-status requirement does not bind the approval request.

When the request falls within a permitted window, this pending-status requirement does not bind the approval request.

A program officer and a grants officer must not approve an award while it is not pending when the request comes from the government network and is outside a permitted window.

A request by a program officer to approve an award that does not trip any prohibition above must be able to succeed.
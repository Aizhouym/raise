# Streaming Content — Tier, Region, and Label Gating

## Natural-Language Scenario

The system manages a streaming platform where subscribers watch licensed video content.

The people involved are subscribers, moderators, editors, and admins, and one person may hold both the editor and moderator roles at the same time.

The resources are content and reports.

Every piece of content records its publisher, the subscription tier it requires, the date its embargo lifts, the regions where it is licensed to stream, its content labels, and its status.

Every report records the content it concerns and the subscriber who filed it.

Each request to watch content carries the region the subscriber is connecting from.

A subscriber may watch a piece of content only when their subscription tier is at least as high as the tier the content requires.

A subscriber whose tier is lower than the content's required tier must not be allowed to watch it.

A subscriber may watch content only when that content is licensed in the region the request carries.

A subscriber must not watch content that is not licensed in their current region, even when their subscription tier is high enough.

A subscriber may watch content only when the content carries the "cleared for streaming" label.

A subscriber must not watch content lacking the "cleared for streaming" label, even when the tier and region requirements are both met.

A request by a subscriber whose tier meets the requirement, whose region is licensed, and whose content carries the "cleared for streaming" label must be able to succeed.

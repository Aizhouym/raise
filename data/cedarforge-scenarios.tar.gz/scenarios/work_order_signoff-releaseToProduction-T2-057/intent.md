# Manufacturing QA Release

## Natural-Language Scenario

The system manages work-order QA sign-off and production release in a manufacturing plant.

The people involved are operators, inspectors, quality managers, production supervisors, and auditors. One person may hold both the operator and inspector roles, or both the inspector and quality manager roles, at the same time.

The resources are work orders, which record the operator, inspector, part code, defect count, hold flag, status, station, and creation time, and production releases, which record the work order, who released it, and the batch code.

Each request carries the current time, whether it is on the plant network, and whether a deviation has been authorized.

When a work order's part code matches the required part code or has a controlled-part prefix, an inspector or quality manager may release it to production only after it has inspected status.

For work orders whose part code does not match and does not have a controlled-part prefix, the inspected-status release rule does not apply.

An inspector must not release a matching or controlled-part work order to production before it has inspected status.

A quality manager must not release a matching or controlled-part work order to production before it has inspected status.

A request by an inspector to release a work order to production without tripping any prohibition above must be able to succeed.
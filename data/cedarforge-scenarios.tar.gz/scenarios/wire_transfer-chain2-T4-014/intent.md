# Wire Approval then Release — Authority, Allowlist, and Separate Eyes

## Natural-Language Scenario

The system manages wire-transfer approval and release in a bank's payment operations.

The people involved are originators, verifiers, treasury officers, and compliance reviewers.

One person may hold both the originator and the verifier role at the same time.

The resources are wire transfers and accounts.

Every wire transfer records who initiated it, who verified it, who screened it, its account, its amount, its fee, its amount tier, its beneficiary, its currency code, whether it is high risk, and its status.

Every account records its holder and its allowed beneficiaries.

Each request carries the current time, the daily cutoff, whether it comes from the secure banking network, whether multi-factor authentication was used, and whether an emergency was declared, and each requester carries their approval tier.

In this workflow a wire is first approved and then released, and the release step can see the wire's status and who initiated, verified, and screened it as recorded by the earlier steps.

An approver's authority tier must be at least the wire's amount tier, and an approver whose authority tier falls below the wire's amount tier may not approve it.

A wire may be approved only when its beneficiary is on the account's screened allowlist, and a request to approve a wire whose beneficiary is not on that allowlist is refused.

The officer who approved a wire may not release it, and a treasury officer who did not approve it may release it, since release is a separate pair of eyes.

A wire may be released only when its beneficiary is on the account's screened allowlist, and a request to release a wire whose beneficiary is not on that allowlist is refused.

Neither a verifier nor a treasury officer may approve a wire whose beneficiary is not on the account's screened allowlist.

A run through the workflow by a verifier who approves a wire whose beneficiary is on the allowlist and whose amount tier is within their authority, after which a different treasury officer releases that wire, tripping no prohibition above, must be able to succeed.

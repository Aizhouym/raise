# Meter Data Management and Billing Runs

## Natural-Language Scenario

The system manages meter readings, account review, and billing runs for utility accounts.

The people involved are meter readers, billing analysts, billing managers, data stewards, and auditors. One person may hold both the meter reader and data steward roles, or both the billing analyst and meter reader roles, at the same time.

The resources are billing runs and meter accounts. Every billing run records its account, preparer, approver, bill amount, usage, rate, rate class, region, account tier, status, and prepared time.

Every meter account records its account holder, last reader, tier, adjustment count, last bill amount, rate class, region, status, and last read time.

Each request carries the current time, whether it comes from the corporate network, and whether an emergency has been declared.

A meter reader or data steward may adjust a reading only while the meter account is under review when the account has a regulated rate class and the request is not made from the corporate network.

For meter accounts outside a regulated rate class, this under-review requirement does not bind the reading adjustment.

When the request is made from the corporate network, this under-review requirement does not bind the reading adjustment.

A meter reader must not adjust a reading on a regulated meter account outside the corporate network unless the account is under review.

A data steward must not adjust a reading on a regulated meter account outside the corporate network unless the account is under review.

A request by a meter reader to adjust a reading that does not trip any prohibition above must be able to succeed.
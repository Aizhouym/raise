# Prescription Verification

## Natural-Language Scenario

The system manages outpatient controlled-substance prescriptions before dispensing.

The people involved are pharmacy technicians, staff pharmacists, the pharmacist in charge, and prescribers. One person may hold both the staff pharmacist and pharmacist-in-charge role at the same time.

The resources are prescriptions and dispense records. Every prescription records its prescriber, patient, who entered it, who verified it, the prescriber's D E A information, schedule level, refills remaining, and status.

Each dispense record records its prescription, who dispensed it, quantity, and copay amount.

Each requester carries dispense authority and state license.

Each request carries whether the P D M P was checked, whether multifactor authentication was used, whether the requester is on the pharmacy network, the current time, and whether there is an emergency override.

During pharmacy operating hours, a staff pharmacist or pharmacist in charge may verify a prescription only while it is in the received stage.

Outside pharmacy operating hours, the received-stage requirement does not block verification.

A staff pharmacist and a pharmacist in charge must not verify a prescription during pharmacy operating hours when it is not in the received stage.

A request by a staff pharmacist to verify a prescription that does not trip any prohibition above must be able to succeed.
# Immigration Case Adjudication

## Natural-Language Scenario

The system manages immigration case adjudication and related applicant records.

The people involved are adjudication officers, supervisory officers, background investigators, and records clerks. One person may hold both the adjudication officer and background investigator roles, and one person may hold both the supervisory officer and adjudication officer roles.

The resources are cases, security checks, and applicant records. Every case records its applicant, assigned officer, case team, field office, and status.

Every security check records its case, investigator, and status.

Every applicant record records its applicant, assigned officer, need to know team, data sensitivity, and status.

Each requester carries clearance and recused cases.

Each request carries whether it is on the government network, the current time, and supervisor approval.

An adjudication officer or supervisory officer who is recused from a case may not adjudicate it.

An adjudication officer or supervisory officer who is not recused from a case is not blocked by the conflict rule.

An adjudication officer or supervisory officer may adjudicate a case only when the request falls within a permitted window.

Outside a permitted window, neither an adjudication officer nor a supervisory officer may adjudicate a case.

A request by an adjudication officer to adjudicate a case that does not trip any prohibition above must be able to succeed.
# Grid Switching — Authorization State Gate then Independent Field Execution

## Natural-Language Scenario

The system manages grid switching-order authorization and field execution.

The people involved are planners, shift supervisors, operators, control room operators, and auditors.

One person may hold the planner and shift supervisor roles together, or the operator and control room operator roles together.

The resources are switching orders and lockout tags.

Every switching order records its planner, its executor, its feeder, its voltage level, its circuit count, its status, its scheduled start, and its scheduled end.

Every lockout tag records its order, who applied it, and its feeder.

In this workflow a switching order is first authorized and then its switching is executed in the field, and the execution step can see the order's status and who authorized it as recorded by the authorization step.

A planner or shift supervisor may authorize a switching order only while it is still in the planned state.

A request to authorize an order that is in any other state is refused.

An operator or control room operator may execute the switching for an authorized order.

The planner who authorized an order may not be the one who executes its switching in the field, and an operator who did not authorize it may execute it.

Neither an operator nor a control room operator who authorized an order may execute that order's switching in the field.

A run through the workflow in which a planner authorizes an order in the planned state and a different person executes its switching, tripping none of the prohibitions above, must be able to succeed.

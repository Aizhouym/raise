# Patent Prosecution Docket

## Natural-Language Scenario

The system manages patent applications during prosecution.

The people involved are patent attorneys, docket clerks, examiners, and inventors. One person may hold both the patent attorney and docket clerk roles at the same time, and one person may hold both the examiner and inventor roles at the same time.

The resources are patent applications, office actions, and filings. Every patent application records its inventor, prosecuting attorney, assigned examiner, team, confidentiality, bar date, and status.

Each request carries the current date, whether the requester is on the firm network, whether there is a court order, and whether MFA was used.

An examiner may examine a patent application only while the application is under examination.

An examiner must not examine a patent application that is not under examination.

An examiner may examine a patent application only when the examiner is on that application's docket team.

An examiner who is not on the application's docket team must not examine it.

An examiner may examine a patent application only when MFA was used.

An examiner who did not use MFA must not examine the application.

A request by an examiner to examine an application that is under examination, is on the examiner's docket team, and used MFA must be able to succeed.
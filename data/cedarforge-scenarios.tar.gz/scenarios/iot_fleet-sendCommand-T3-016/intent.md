# IoT Device Commanding

## Natural-Language Scenario

The system manages commands sent to devices in an IoT and operational technology fleet.

The people involved are operators, technicians, fleet admins, and service accounts. One person may hold both the operator and technician role at the same time.

The resources are devices, telemetry, and commands. Every device records its owner, site group, firmware tags, maintenance mode, and status.

Every telemetry record identifies its device and sensitivity, and every command records its device and who issued it.

Each requester carries a clearance and group memberships.

Each request carries a source IP address, the current time, and whether a maintenance window is open.

An operator, technician, or fleet admin may send a command only to a device whose status is active, not provisioned or decommissioned.

When the device carries the particular firmware tag, the active-status limit is relaxed.

When the device does not carry that firmware tag, the active-status limit still applies.

During a maintenance window, a technician may send a command to a device in the maintenance state.

Outside a maintenance window, a technician may not use the maintenance-state exception.

When a maintenance window is open, the technician's maintenance-state exception overrides the active-device limit.

An operator, technician, or fleet admin must not send a command to a device that is not active unless one of the stated exceptions applies.

A request by an operator to send a command that does not trip any prohibition above must be able to succeed.
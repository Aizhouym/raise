# Patent Prosecution Docket

## Natural-Language Scenario

The system manages patent application examination in a prosecution docket.

The people involved are patent attorneys, docket clerks, examiners, and inventors. One person may hold both the patent attorney and docket clerk roles, and one person may hold both the examiner and inventor roles.

The resources are patent applications, office actions, and filings. Every patent application records its inventor, prosecuting attorney, assigned examiner, team, confidentiality, bar date, and status.

Each requester carries a clearance level.

Each request carries the current date, whether it is on the firm network, whether there is a court order, and whether multifactor authentication was used.

Before the statutory bar date, an examiner may examine an application only while the application is under examination.

On or after the statutory bar date, the under-examination status requirement does not block the examiner from examining the application.

An examiner must not examine an application before the statutory bar date when the application is not under examination.

A request by an examiner to examine an application that does not trip any prohibition above must be able to succeed.
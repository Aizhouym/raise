# Streaming Content Access

## Natural-Language Scenario

The system manages viewing and publishing on a streaming content platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and moderator role at the same time.

The resources are content and reports. Every content item records its publisher, required tier, embargo date, allowed regions, labels, and status.

Each subscriber carries a subscription tier and region.

Each request carries the current time and whether the device is trusted.

A subscriber may watch content with the particular label from a trusted device only when the subscriber's tier meets the content's required tier.

For content without that label, this tier requirement does not apply.

For requests not made from a trusted device, this tier requirement does not apply.

A subscriber whose tier is below the content's required tier must not watch labeled content from a trusted device.

A request by a subscriber to watch content that does not trip any prohibition above must be able to succeed.
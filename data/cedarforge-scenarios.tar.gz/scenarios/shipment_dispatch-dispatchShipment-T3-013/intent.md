# Shipment Dispatch

## Natural-Language Scenario

The system manages carrier shipment dispatch and delivery confirmation.

The people involved are planners, drivers, dispatch managers, depot supervisors, and auditors. One person may hold both the planner and the dispatch manager role at the same time.

The resources are shipments and delivery receipts. Every shipment records its planner, driver of record, piece count, gross weight in kilograms, status, tracking code, origin depot, hazmat class, and delivery window end.

Each request carries the current time, whether it is on the depot network, whether expedite handling is declared, and proof of delivery.

A planner may create a shipment.

A driver or dispatch manager may dispatch a shipment only after it has reached the created state.

A driver or dispatch manager must not dispatch a shipment before it has reached the created state.

The person who planned a shipment may not be its driver of record who dispatches it.

When a shipment's piece count crosses the elevated-authority threshold, only a dispatch manager may dispatch it.

When a shipment's piece count does not cross the elevated-authority threshold, the elevated-authority requirement does not block a driver from dispatching it.

A depot supervisor may confirm delivery when proof of delivery is present.

An auditor may view the custody log.

A request by a driver to dispatch a created shipment with a piece count below the elevated-authority threshold, where the driver did not plan the shipment, must be able to succeed.
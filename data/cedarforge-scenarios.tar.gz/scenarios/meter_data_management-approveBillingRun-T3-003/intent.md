# Billing-Run Approval — Authority, Charge Threshold, and Manager Role

## Natural-Language Scenario

The system manages meter data and the preparation and approval of billing runs.

The people involved are meter readers, billing analysts, billing managers, data stewards, and auditors, and one person may hold both the meter-reader and data-steward roles at the same time or both the billing-analyst and meter-reader roles at the same time.

The resources are billing runs and meter accounts, where every billing run records its account, its preparer, its approver, its bill amount, its metered usage, its rate, its rate class, its region, its account tier, its status, and when it was prepared, and every meter account records its account holder, who last read it, its tier, its adjustment count, its last bill amount, its rate class, its region, its status, and when it was last read.

A billing analyst may calculate a billing run.

A billing analyst or a billing manager may approve a billing run only when their authority level is at least the account tier of the run, and one whose authority level does not reach the run's account tier may not approve it.

This authority-dominance requirement is relaxed when the run's metered usage times its rate is above the charge threshold, allowing approval even without full authority dominance, and when that charge is at or below the threshold the authority-dominance requirement still applies.

A billing run may be approved only by someone who holds the billing-manager role, and an approver who does not hold that role may not approve it.

Neither a billing analyst nor a billing manager may approve a billing run whose account tier is above their own authority level, unless its metered-usage charge is above the threshold.

A request by a billing analyst to approve a billing run, tripping no prohibition above, must be able to succeed.

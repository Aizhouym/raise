# Repository Pull Request Review

## Natural-Language Scenario

The system manages source-code repositories and pull request reviews.

The people involved are developers, reviewers, maintainers, and security leads. One person may hold both the developer and reviewer roles at the same time.

The resources are repositories, pull requests, and branches. Every repository records its owner, team, sensitivity, default branch protection setting, topics, and status.

Every pull request records its repository, author, approvers, target branch, approval count, lines changed, whether it requires security review, and status.

Every branch records its name and whether it is protected.

Each requester carries a clearance, and each request carries the current time, whether the requester is on vpn, and whether break glass was invoked.

When a reviewer is reviewing a pull request whose changed lines cross the extra-scrutiny threshold, the pull request may be reviewed only while it is open.

For pull requests whose changed lines do not cross the extra-scrutiny threshold, this open-status requirement does not apply.

A reviewer must not review a pull request whose changed lines cross the extra-scrutiny threshold while the pull request is not open.

A maintainer must not review a pull request whose changed lines cross the extra-scrutiny threshold while the pull request is not open.

A request by a reviewer to review a pull request that does not trip any prohibition above must be able to succeed.
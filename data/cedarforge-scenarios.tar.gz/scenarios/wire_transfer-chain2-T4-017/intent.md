# Wire Approval and Release — Authority Tier, Beneficiary Screening, and Emergency Override

## Natural-Language Scenario

This document describes how a bank wire-transfer authorization system controls who may approve a wire and who may release it.
The people involved are originators, verifiers, treasury officers, and compliance reviewers, and one person may hold originator together with verifier at the same time.
The resources are wire transfers, which record who initiated them, who verified them, who screened them, the account, amount, fee, amount tier, beneficiary, currency code, a high-risk flag, and status; and accounts, which record their holder and allowed beneficiaries.
Each request carries the current time, the daily cutoff, whether it is on the secure network, whether multi-factor authentication was used, and whether an emergency has been declared.
In this workflow a wire is first approved and then released on the same wire, and the release step can see the wire's status along with who initiated, verified, and screened it.
When a wire is approved, the approver's authority tier must be at least as high as the wire's amount tier.
A wire may be released only after it has been verified.
That verification-first rule applies only when the beneficiary is on the account's screened allowlist, and it does not apply when the beneficiary is not on that allowlist.
When an emergency has been declared, a treasury officer may release a wire that has not completed verification.
When the declared emergency and the verification-first rule disagree, the declared emergency wins and the release may proceed.
A verifier or a treasury officer must not approve a wire whose amount tier is above their own authority tier.
A run through the workflow by a verifier that trips none of these prohibitions must be able to succeed.

# Streaming Content Access

## Natural-Language Scenario

The system manages viewing and oversight for a streaming content platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and the moderator role at the same time.

The resources are content and reports. Every content item records its publisher, required tier, embargo date, allowed regions, labels, and status.

Each subscriber carries a subscription tier and region.

Each request carries the current time and whether the device is trusted.

A subscriber may watch content only when the subscriber's tier meets the content's required tier, unless an exception below applies.

If the content carries the particular exception label, the subscriber may watch it even when their tier is below the required tier.

If the request comes from a trusted device, the subscriber may watch the content even when their tier is below the required tier.

A subscriber whose tier is below the content's required tier must not watch that content when it lacks the particular exception label and the request is not from a trusted device.

A request by a subscriber to watch content that does not trip any prohibition above must be able to succeed.
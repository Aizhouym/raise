# Student Records and Grades

## Natural-Language Scenario

The system manages student records and grades.

The people involved are instructors, students, parents, and the registrar. One person may hold both the instructor and parent roles at the same time.

The resources are student records, grades, and courses. Every student record records its student, advisor, student age, FERPA block, and status.

Each request carries the current date and whether it comes from the campus network.

A withdrawn student's record may be viewed only by the registrar when the request is not from the campus network.

An instructor, student, or parent must not view a withdrawn student's record when the request is not from the campus network.

When the request is from the campus network, the withdrawn-student restriction does not block an instructor, student, or parent from viewing the record.

A request by an instructor to view a student record that does not trip any prohibition above must be able to succeed.
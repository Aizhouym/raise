# Manufacturing Work-Order QA Sign-Off

## Natural-Language Scenario

The system manages QA sign-off and production release for manufacturing work orders.

The people involved are operators, inspectors, quality managers, production supervisors, and auditors.

One person may hold both the operator and inspector roles, or both the inspector and quality manager roles, at the same time.

The resources are work orders and production releases.

Every work order records its operator, inspector, part code, defect count, hold flag, status, station, and creation time.

Every production release records its work order, who released it, and its batch code.

Each request carries the current time, whether it is on the plant network, and whether a deviation has been authorized.

An inspector or quality manager may sign off a work order.

An inspector who operated a work order may not sign it off when the work order is under a quality hold.

A quality manager who operated a work order may not sign it off when the work order is under a quality hold.

When the work order is not under a quality hold, an inspector or quality manager who operated it may sign it off.

Neither an inspector nor a quality manager may sign off a work order they operated while it is under a quality hold.

A request by an inspector to sign off a work order that does not trip any prohibition above must be able to succeed.
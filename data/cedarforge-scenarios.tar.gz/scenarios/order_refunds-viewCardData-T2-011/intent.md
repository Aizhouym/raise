# Retail Order Card Data Access

## Natural-Language Scenario

The system manages retail orders, refunds, and access to stored payment card data.

The people involved are customers, service reps, managers, and auditors. One person may hold both the service rep and the manager role at the same time.

The resources are orders and refunds. Every order records its customer, who placed it, item total, tax amount, loyalty tier, whether it contains card data, and its status.

Each request carries whether it is in the cardholder zone, whether MFA was used, and the current time.

A service rep or an auditor may view stored card data only before the order is refunded.

After an order is refunded, neither a service rep nor an auditor may view its stored card data.

A service rep or an auditor may view stored card data only when MFA was used.

Without MFA, neither a service rep nor an auditor may view stored card data.

A request by a service rep to view stored card data for an order that is not refunded, with MFA used, must be able to succeed.
# Applicant Tracking Application Viewing

## Natural-Language Scenario

The system manages applicant tracking for recruiting teams.

The people involved are recruiters, hiring managers, interviewers, and coordinators. One person may hold both the recruiter and interviewer roles, or both the recruiter and hiring manager roles, at the same time.

The resources are applications, interview feedback, and offers. Every application records its candidate, who referred the candidate, its hiring team, req code, PII sensitivity, and status.

Each requester carries their PII clearance, and each request carries whether it is on the corporate network, the current time, and whether executive approval has been given.

Recruiters, hiring managers, interviewers, and coordinators may request to view applications.

When the request is on the corporate network, the requester’s PII clearance must be at least as high as the application’s PII sensitivity.

When the request is not on the corporate network, that PII clearance requirement does not bind the viewing request.

A recruiter, hiring manager, interviewer, or coordinator must not view an application from the corporate network when their PII clearance is lower than the application’s PII sensitivity.

A request by a recruiter to view an application that does not trip any prohibition above must be able to succeed.
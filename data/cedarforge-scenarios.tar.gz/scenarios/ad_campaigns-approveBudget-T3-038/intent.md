# Campaign Budget Approval

## Natural-Language Scenario

The system manages advertising campaigns and creative review.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors. One person may hold both the account manager and campaign director role at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, who prepared it, its budget, contingency, budget tier, risk labels, scheduled start, and status.

Every creative records its campaign, who submitted it, its risk rating, content tags, and status.

Each requester carries a reviewer level.

Each request carries the current time, whether MFA was used, whether the device is trusted, and whether it is an emergency launch.

An account manager or campaign director who prepared a campaign must not approve its budget when the budget tier is below the required sign-off level and MFA was not used.

When the budget tier is at least the required sign-off level, the manager who prepared the campaign may approve its budget.

When MFA was used, the manager who prepared the campaign may approve its budget.

A request by a campaign director to approve a budget that does not trip any prohibition above must be able to succeed.
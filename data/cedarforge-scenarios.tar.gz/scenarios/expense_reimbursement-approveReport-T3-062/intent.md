# Employee Expense Reimbursement

## Natural-Language Scenario

The system manages employee expense reports and reimbursements.

The people involved are employees, line managers, finance reviewers, and controllers. One person may hold both the employee and line manager role at the same time.

The resources are expense reports and reimbursements. Every expense report records its submitter, approver, total amount, meal total, lodging total, category, amount tier, whether a receipt is attached, its status, and when it was submitted.

Each requester carries an approval tier.

A line manager or finance reviewer may approve an expense report.

Neither a line manager nor a finance reviewer may approve an expense report they submitted.

When no receipt is attached, a line manager or finance reviewer may approve an expense report only if their approval tier is at least as high as the report's amount tier.

When a receipt is attached, a line manager or finance reviewer may approve the report even if their approval tier is lower than the report's amount tier.

A request by a line manager to approve a report that does not trip any prohibition above must be able to succeed.
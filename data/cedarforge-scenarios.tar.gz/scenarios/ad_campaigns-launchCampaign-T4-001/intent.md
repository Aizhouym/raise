# Ad Campaign Launch — Advertiser Match, Risk Label Gate, and Emergency Override

## Natural-Language Scenario

The system manages the launch of advertising campaigns for a marketing agency, from creative submission and budget approval through brand safety review and scheduled launch.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors, and each of them carries a reviewer level used when their creative reviews are evaluated.

One person may hold both the account manager and the campaign director role at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, the account manager who prepared it, its budget, its contingency, its budget tier, its risk labels, its scheduled start time, and its status.

Every creative records the campaign it belongs to, the person who submitted it, its risk rating, its content tags, and its status.

Each request carries the current time, whether multi-factor authentication was used, whether the device is trusted, and whether an emergency launch has been declared.

A campaign may be launched only after its budget has been approved.

A campaign may be launched only when the requester is that campaign's own recorded advertiser.

When the requester is not the campaign's recorded advertiser, they may not launch that campaign on this basis.

A campaign may be launched only when its risk labels include the "brand-safety-cleared" label.

A campaign whose risk labels do not include the "brand-safety-cleared" label may not be launched.

Neither an account manager nor a campaign director may launch a campaign whose budget has not been approved, but when an emergency launch has been declared, a campaign director may launch it anyway before budget approval, and this declared emergency launch overrides the budget-approval requirement.

A request by an account manager to launch a campaign that has approved budget, belongs to its own recorded advertiser, and carries the "brand-safety-cleared" risk label must be able to succeed.

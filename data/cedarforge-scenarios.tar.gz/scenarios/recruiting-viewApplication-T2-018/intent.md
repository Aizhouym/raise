# Applicant Tracking

## Natural-Language Scenario

The system manages recruiting applications and related hiring records.

The people involved are recruiters, hiring managers, interviewers, and coordinators. One person may hold both the recruiter and interviewer roles, or both the recruiter and hiring manager roles, at the same time.

The resources are applications, interview feedback, and offers. Every application records its candidate, who referred the candidate, the hiring team, the requisition code, its PII sensitivity, and its status; every interview feedback record records its application, interviewer, candidate, and status; every offer records its application, who extended it, compensation, signing bonus, and status.

Each requester carries a PII clearance, and each request carries whether it is on the corporate network, the current time, and whether executive approval is present.

A recruiter, hiring manager, interviewer, or coordinator may view an application only when the requirements below are met.

When an application is closed, the requester’s PII clearance must be at least as high as the application’s PII sensitivity.

For applications that are not closed, the PII clearance requirement does not block viewing.

A recruiter, hiring manager, interviewer, or coordinator must not view a closed application when their PII clearance is lower than the application’s PII sensitivity.

A request by a recruiter to view an application that does not trip any prohibition above must be able to succeed.
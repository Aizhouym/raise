# Wire Approval then Release — Authority Tiers, Verification Gate, and Emergency Override

## Natural-Language Scenario

The system manages the authorization of outgoing bank wire transfers.

The people involved are originators, verifiers, treasury officers, and compliance reviewers. One person may hold both the originator and the verifier role at the same time.

The resources are wire transfers and accounts. Every wire transfer records who initiated it, who verified it, who screened it, its account, its amount, its fee, its amount tier, its beneficiary, its currency code, whether it is high risk, and its status, and every account records its holder and its list of allowed beneficiaries.

Each request carries the current time, the daily cutoff, whether it comes from a secure network, whether multi-factor sign-in was used, and whether an emergency was declared.

In this workflow a wire is first approved and then released, and the release step can see the status the approval step recorded along with who initiated, verified, and screened the wire.

An approver's authority tier must be high enough to cover the wire's amount tier, and an approver whose authority tier does not cover it may not approve the wire.

A wire may be released only after it has been verified, and a wire that has not completed verification may not be released.

This verification requirement is overridden when an emergency has been declared, which lets a treasury officer release a wire that has not completed verification, and in that emergency the declaration takes precedence over the verification requirement.

A verifier or treasury officer whose authority tier does not cover the wire's amount tier must not approve it.

A treasury officer must not release a wire that has not been verified unless an emergency has been declared.

A run through the workflow in which a verifier whose authority tier covers the wire's amount tier approves it and a treasury officer then releases it after verification, tripping no prohibition above, must be able to succeed.

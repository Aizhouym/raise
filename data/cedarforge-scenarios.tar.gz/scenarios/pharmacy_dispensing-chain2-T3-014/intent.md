# Prescription Verification and Refill Authorization, With a DEA-Pattern Requirement and Verifier Continuity

## Natural-Language Scenario

This is the access-control document for the outpatient controlled-substance dispensing system.
The people involved are pharmacy technicians, staff pharmacists, pharmacists in charge, and prescribers, and one person may be both a staff pharmacist and a pharmacist in charge at the same time.
The resources are prescriptions, each recording its prescriber, patient, who entered it, who verified it, the prescriber's DEA registration number, its schedule level, its refills remaining, and its status, and dispense records, each recording their prescription, who dispensed them, quantity, and copay amount.
Each request carries whether the prescription drug monitoring program was checked, whether multi-factor authentication was used, whether the request is on the pharmacy network, the current time, and whether an emergency override applies.
In this workflow the same prescription is first verified and then its refill is authorized, and the refill step can see the prescription's status and who verified it as recorded by the verification step.
When a staff pharmacist or a pharmacist in charge verifies a prescription, the technician who entered it may not be the pharmacist who verifies it.
A prescription may be verified only when the prescriber's DEA registration number matches an allowed pattern, and a request to verify one whose DEA number does not match is refused.
When a pharmacist in charge authorizes a refill, the pharmacist who verified the prescription must be the same person who authorizes its refill.
A staff pharmacist or a pharmacist in charge must not verify a prescription that they themselves entered, or one whose DEA number does not match the allowed pattern.
A pharmacist in charge must not authorize a refill on a prescription that someone else verified.
A run through the workflow by a staff pharmacist that trips none of the prohibitions above must be able to succeed.

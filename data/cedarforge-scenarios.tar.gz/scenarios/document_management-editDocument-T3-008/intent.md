# Document Editing — Draft Gate, Ownership, and Label Restriction

## Natural-Language Scenario

The system manages document creation, editing, and publication for an enterprise document management platform.

The people involved are authors, editors, viewers, and compliance officers. One person may hold both the author and editor role at the same time.

The resources are documents and workspaces.

Every document records its owner, its share list, its classification, whether its version is locked, its labels, and its status, which is draft, in review, or published.

Every workspace records its members.

An author or an editor may edit a document only while it is in draft status.

An author or an editor must not edit a document once it has moved past draft status into review or publication.

An author or an editor may edit a document only when they own it.

An author or an editor who does not own the document must not edit it, even while it is in draft status.

An author or an editor may edit a document only when it carries the "Editable" label.

An author or an editor must not edit a document that lacks the "Editable" label, even if they own it and it is in draft status.

A compliance officer may reclassify a document.

A viewer may view a document.

A request by an author who owns a draft document carrying the "Editable" label must be able to succeed.

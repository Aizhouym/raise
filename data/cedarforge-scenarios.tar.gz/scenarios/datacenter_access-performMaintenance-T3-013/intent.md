# Datacenter Cage Maintenance

## Natural-Language Scenario

The system manages physical maintenance work for datacenter cages.

The people involved are facility techs, tenant engineers, security ops, and escorts. One person may hold both the facility tech and escort role at the same time.

The resources are cages, work orders, and access badges. Every cage records its tenant, zone clearance, occupant list, site zone, whether an escort is required, and its status.

Every work order records its cage, who raised it, who approved it, and its status.

Every access badge records its holder and when it expires.

Each requester carries a clearance level and memberships.

Each request carries the current time, whether an escort is present, the maintenance window, and whether the requester is on the site network.

A facility tech or tenant engineer who raised the work order for an escort-required cage may perform maintenance only after the work order has been approved.

If the requester did not raise the work order, this approval requirement does not bind their maintenance request.

If the cage does not require an escort, this approval requirement does not bind the maintenance request.

A facility tech or tenant engineer who raised the work order must not perform maintenance on an escort-required cage before the work order is approved.

A request by a facility tech to perform maintenance that does not trip any prohibition above must be able to succeed.
# Controlled-Substance Dispensing — Two-Person Verification Control

## Natural-Language Scenario

The system manages the dispensing of controlled-substance prescriptions in an outpatient pharmacy.

The people involved are pharmacy technicians, staff pharmacists, pharmacists in charge, and prescribers, and one person may hold both the staff pharmacist and pharmacist in charge roles at the same time.

The resources are prescriptions and dispense records.

Every prescription records its prescriber, patient, the person who entered it, the person who verified it, the prescriber's DEA number, its schedule level, its refills remaining, and its status.

Every dispense record records its prescription, the person who dispensed it, the quantity, and the copay amount.

Each request carries whether the prescription drug monitoring program was checked, whether multi-factor authentication was used, whether the request came from the pharmacy network, the current time, and whether an emergency override applies.

A prescriber may write a prescription and authorize a refill.

A pharmacy technician may enter a prescription into the system.

A staff pharmacist may verify a prescription.

A staff pharmacist or a pharmacist in charge may dispense a medication.

The pharmacist who verified a prescription must not be the one who dispenses it.

A staff pharmacist must not dispense a prescription that they themselves verified, and a pharmacist in charge must not dispense a prescription that they themselves verified either.

A request by a staff pharmacist to dispense a medication that does not trip the two-person control must be able to succeed.

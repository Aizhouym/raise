# Immigration Case Adjudication

## Natural-Language Scenario

The system manages applicant records for immigration case adjudication.

The people involved are adjudication officers, supervisory officers, background investigators, and records clerks. One person may hold both the adjudication officer and background investigator roles, or both the supervisory officer and adjudication officer roles, at the same time.

The resources are cases, security checks, and applicant records. Every applicant record records the applicant, the assigned officer, the need-to-know team, the data sensitivity, and its status.

Each requester carries their clearance and the cases from which they are recused.

Each request carries whether it comes from the government network, the current time, and whether supervisor approval is present.

An adjudication officer, supervisory officer, or background investigator may view applicant data when their clearance is high enough for the record's data sensitivity.

An adjudication officer, supervisory officer, or background investigator whose clearance is not high enough may still view applicant data when they are on the record's need-to-know team.

An adjudication officer, supervisory officer, or background investigator whose clearance is not high enough may still view applicant data when the request comes from the government network.

An adjudication officer, supervisory officer, or background investigator must not view applicant data when their clearance is not high enough, they are not on the record's need-to-know team, and the request does not come from the government network.

A request by an adjudication officer to view applicant data that does not trip any prohibition above must be able to succeed.
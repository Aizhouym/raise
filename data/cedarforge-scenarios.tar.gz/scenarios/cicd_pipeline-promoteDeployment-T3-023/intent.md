# CI/CD Deployment Pipeline

## Natural-Language Scenario

The system manages deployment promotion in a CI/CD pipeline.

The people involved are committers, approvers, release managers, and SREs. One person may hold both the committer and approver roles, or both the approver and release manager roles, at the same time.

The resources are deployments and artifacts. Every deployment records its committer, approver, target environment, change risk, artifact, and status.

Every artifact records who built it, whether it is signed, its build tags, and its status.

Each requester carries a deploy tier.

Each request carries the current time, source IP, and whether it is for an emergency change.

A release manager may promote a deployment only after it has been approved when the request is inside a change-freeze window and the release manager is not the recorded approver.

A release manager who is the recorded approver may promote that deployment even if it has not yet been approved.

Outside a change-freeze window, the approval-status requirement for promotion relaxes.

A release manager must not promote an unapproved deployment during a change-freeze window when they are not the recorded approver.

A request by a release manager to promote a deployment that does not trip any prohibition above must be able to succeed.
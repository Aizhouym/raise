# Campaign Budget Approval

## Natural-Language Scenario

The system manages advertising campaigns and their budget approval.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors. One person may hold both the account manager and campaign director role at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, who prepared it, its budget, contingency, budget tier, risk labels, scheduled start, and status.

Each requester carries a reviewer level.

Each request carries the current time, whether multifactor confirmation was used, whether the device is trusted, and whether this is an emergency launch.

A campaign director or account manager who prepared a campaign may not approve its budget.

For campaigns whose budget crosses the money threshold, the budget may be approved only while the campaign is in review.

For campaigns at or below the money threshold, the in-review requirement does not apply.

A campaign director must not approve the budget of a campaign they prepared.

An account manager must not approve the budget of a campaign they prepared.

A request by a campaign director to approve a budget that does not trip any prohibition above must be able to succeed.
# Immigration Case Adjudication

## Natural-Language Scenario

The system manages immigration case assignment and adjudication.

The people involved are adjudication officers, supervisory officers, background investigators, and records clerks. One person may hold both the adjudication officer and background investigator roles, or both the supervisory officer and adjudication officer roles.

The resources are cases, security checks, and applicant records. Every case records its applicant, assigned officer, case team, field office, and status.

Every security check records its case, investigator, and status.

Every applicant record records its applicant, assigned officer, need-to-know team, data sensitivity, and status.

Each requester carries their clearance and the cases from which they are recused.

Each request carries whether it is on the government network, the current time, and whether supervisor approval is present.

An adjudication officer or supervisory officer who is recused from a case may not adjudicate it.

A recused adjudication officer or supervisory officer may adjudicate the case if they hold the role named for the exception.

A recused adjudication officer or supervisory officer may adjudicate the case if the request falls within the permitted time window.

Outside the permitted time window, the recusal bar remains in force unless the requester holds the exception role.

Neither an adjudication officer nor a supervisory officer may adjudicate a case from which they are recused when no exception applies.

A request by an adjudication officer to adjudicate a case that does not trip any prohibition above must be able to succeed.
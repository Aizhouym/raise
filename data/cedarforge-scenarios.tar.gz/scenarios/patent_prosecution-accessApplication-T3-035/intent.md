# Patent Prosecution Docket

## Natural-Language Scenario

The system manages access to patent prosecution docket records.

The people involved are patent attorneys, docket clerks, examiners, and inventors. One person may hold both the patent attorney and docket clerk roles, and one person may hold both the examiner and inventor roles.

The resources are patent applications, office actions, and filings. Every patent application records its inventor, prosecuting attorney, assigned examiner, team, confidentiality level, bar date, and status.

Each requester carries a clearance level.

Each request carries the current date, whether it comes from the firm network, whether there is a court disclosure order, and whether multifactor authentication was used.

A patent attorney, docket clerk, or examiner may access an application only if their clearance is high enough for the application's confidentiality level.

When there is a court disclosure order, the clearance requirement does not block access to the application.

When there is no court disclosure order, the clearance requirement applies.

A patent attorney, docket clerk, or examiner may access an application only while the application is in the required lifecycle stage.

A patent attorney, docket clerk, or examiner must not access an application outside the required lifecycle stage.

When a court disclosure order exists, it wins over the confidentiality clearance requirement.

A request by a patent attorney to access an application that does not trip any prohibition above must be able to succeed.
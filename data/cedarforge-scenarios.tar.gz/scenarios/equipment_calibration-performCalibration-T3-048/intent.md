# Equipment Calibration

## Natural-Language Scenario

The system manages equipment calibration and return-to-service decisions.

The people involved are calibration technicians, senior technicians, metrology managers, quality inspectors, and maintenance supervisors. One person may hold both the calibration technician and senior technician role at the same time.

The resources are assets and calibration records. Every asset records its assigned technician, equipment class, status, calibration due date, out-of-service flag, measurement point count, asset tag, and hazard class, and every calibration record records its asset, technician, result, and calibration time.

Each request carries the current time, whether it is on the plant network, whether clean-room certification is present, and whether an emergency has been declared.

When an asset is out of service for maintenance and its measurement-point count crosses the extended-procedure threshold, a calibration technician or senior technician may begin calibration only while the asset is in the due state.

When the asset is not out of service for maintenance or its measurement-point count does not cross the extended-procedure threshold, the due-state restriction above does not apply.

A calibration technician must not perform calibration on an asset covered by the due-state restriction unless the asset is in the due state.

A senior technician must not perform calibration on an asset covered by the due-state restriction unless the asset is in the due state.

A request by a calibration technician to perform a calibration that does not trip any prohibition above must be able to succeed.
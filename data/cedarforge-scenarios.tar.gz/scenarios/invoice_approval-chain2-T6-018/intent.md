# Invoice Approval — Approval then Payment

## Natural-Language Scenario

The system manages the approval of supplier invoices and the payments made against them.

The people involved are clerks, approvers, finance managers, and auditors. One person may hold both the clerk and the approver role at the same time.

The resources are invoices and payments. Every invoice records its creator, its approver, its amount, its surcharge, its line-item count, its status, its cost center, and when it was submitted. Every payment records its invoice, its issuer, and its amount.

Each request carries the current time, whether it is on the corporate network, and whether an emergency is declared.

In this workflow an invoice is first approved and then its payment is issued, and the payment step can see the invoice's status, its creator, and its approver as recorded by the approval step.

An invoice may be approved only after it has been submitted, unless the amount crosses the money threshold.

When the invoice has not been submitted and its amount does not cross the money threshold, neither an approver nor a finance manager may approve it.

An invoice may be approved only when its amount plus surcharge crosses the threshold, and a request to approve one at or below that threshold is refused.

The person who approved an invoice may not issue its payment, unless the payment amount crosses the money threshold.

When the payment amount does not cross the money threshold, a finance manager who approved the invoice may not issue its payment.

A payment may be issued only within business hours, and a request to issue one outside business hours is refused.

A run through the workflow in which an approver approves a submitted invoice whose amount plus surcharge crosses the threshold and a finance manager who did not approve it then issues the payment within business hours, tripping no prohibition above, must be able to succeed.

# Shipment Delivery Confirmation

## Natural-Language Scenario

The system manages shipment dispatch and delivery confirmation for a carrier.

The people involved are planners, drivers, dispatch managers, depot supervisors, and auditors. One person may hold both the planner and the dispatch manager role at the same time.

The resources are shipments and delivery receipts. Every shipment records its planner, driver of record, piece count, gross weight in kilograms, status, tracking code, origin depot, hazmat class, and delivery window end.

Each request carries the current time, whether it is on the depot network, whether expedited handling was declared, and proof of delivery.

A driver may confirm delivery only for a shipment where they are the driver of record.

A depot supervisor may confirm delivery only when acting for the shipment's driver of record.

A driver must not confirm delivery for a shipment where another driver is the driver of record.

A depot supervisor must not confirm delivery unless the confirmation is tied to the shipment's driver of record.

A hazmat shipment requires a recorded custody signature at delivery unless proof of delivery has been captured for the request.

When proof of delivery has been captured for the request, the hazmat custody-signature requirement does not block delivery confirmation.

A driver may confirm delivery for a non-hazmat shipment without a hazmat custody signature.

A request by a driver to confirm a delivery that does not trip any prohibition above must be able to succeed.
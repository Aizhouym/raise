# Payout Issuance — Approval, Amount, and Fraud Gates

## Natural-Language Scenario

The system manages the adjudication of insurance claims and the payouts made against them.

The people involved are adjusters, reviewers, claims managers, payout officers, fraud analysts, and auditors. One person may hold both the adjuster and reviewer roles at the same time, or both the reviewer and payout officer roles at the same time.

The resources are claims and payouts. Every claim records the adjuster who handled it, the person who approved it, its claim amount, its deductible, its line-item count, its status, its claim code, whether it is under a fraud hold, and when it was filed. Every payout records the claim it pays, the officer who issued it, and its amount.

A payout may be issued only after its claim has been approved, and a request to issue a payout for a claim that is not yet approved is refused.

The high-value payout control applies only when the payout amount crosses the money threshold, and a payout at or below that threshold is not subject to it.

A payout may be issued only when its amount equals the net payable, that is the claim amount minus the deductible, and a payout whose amount does not equal the claim amount minus the deductible is refused.

A payout may be issued only when the claim is not under a fraud hold, and a payout for a claim that is under a fraud hold is refused.

Neither a payout officer nor a claims manager may issue a payout for a claim that is not yet approved or that is under a fraud hold.

A request by a payout officer to issue a payout for an approved claim that is not under a fraud hold, whose amount equals the claim amount minus the deductible, tripping no prohibition above, must be able to succeed.

# Carrier Network Change Control

## Natural-Language Scenario

The system manages carrier network change approval and maintenance-window implementation.
The people involved are network engineers, senior engineers, change managers, c a b approvers, and auditors. One person may hold both the network engineer and senior engineer role at the same time.
The resources are change requests and implementations. Every change request records its requester, implementer, approver, change risk, affected node count, rollback step count, estimated cost, change code, emergency-change flag, change category, status, and maintenance window start.
Each implementation records its change, who implemented it, and when it was implemented.
Each request carries the current time, whether it is on the management network, whether a freeze waiver has been granted, and whether a major incident has been declared.
A network engineer or senior engineer may implement a change only after the change request has been approved.
Neither a network engineer nor a senior engineer may implement a change before it has been approved.
A non-emergency change may be implemented only according to its standard maintenance schedule.
An emergency change may be implemented outside the standard maintenance schedule.
When the affected-node count crosses the threshold requiring a senior engineer, a network engineer must not implement the change.
When the affected-node count stays below that threshold, a network engineer may implement the change if no other prohibition applies.
A senior engineer may implement a change whose affected-node count crosses the senior-engineer threshold if no other prohibition applies.
A request by a network engineer to implement an approved change within its standard schedule, with an affected-node count below the senior-engineer threshold, must be able to succeed.
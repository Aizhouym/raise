# Pick Order — Release Gate with a Controlled-Item Exception

## Natural-Language Scenario

The system manages warehouse zone access and order picking.

The people involved are pickers, forklift operators, zone supervisors, warehouse managers, and security officers. One person may hold both the picker and forklift operator roles at the same time.

The resources are orders and zones. Every order records who requested it, its picker, its items, its item count, its pick-list code, its status, its destination zone, and when it was released. Every zone records its zone code, its sensitivity, its zone group, whether it is locked, and its operational status.

Only a picker or a forklift operator may pick an order.

An order may be picked only after it has been released, unless its item set includes a controlled or hazardous SKU.

When the order's item set includes no controlled or hazardous SKU, neither a picker nor a forklift operator may pick it before it has been released.

When the order's item set includes a controlled or hazardous SKU, the release requirement does not apply and it may be picked before release.

A request by a picker to pick an order that trips none of the prohibitions above must be able to succeed.

# Course Content and Gradebook

## Natural-Language Scenario

The system manages course modules and gradebook entries in a learning-management system.

The people involved are instructors of record, teaching assistants, learners, and coordinators. One person may hold both the instructor of record and teaching assistant roles at the same time.

The resources are modules and grade entries. Every module records its course, instructor of record, roster, prerequisite level, release time, locked flag, and status, and every grade entry records its learner, module, posting person, and status.

Each request carries the current time, whether it comes from the institution network, and the preview window.

A module may be viewed only once it is released when the requester is enrolled on the module roster.

An enrolled requester may not view a module while it is draft or scheduled before the scheduled release time has passed.

After the scheduled release time has passed, the scheduled-release timing restriction no longer blocks viewing.

An instructor of record, teaching assistant, learner, or coordinator who is enrolled on the module roster must not view the module while it is draft or scheduled before the scheduled release time has passed.

A request by an instructor of record to view a module that does not trip any prohibition above must be able to succeed.
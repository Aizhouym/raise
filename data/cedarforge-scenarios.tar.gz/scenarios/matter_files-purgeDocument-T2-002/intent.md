# Law-Firm Matter Files

## Natural-Language Scenario

The system manages matter files and document retention for a law firm.

The people involved are attorneys, paralegals, records managers, and clients. One person may hold both the attorney and the paralegal role at the same time.

The resources are matters and documents. Every matter records its lead attorney, its team, its client, whether it is under legal hold, and its status.

Every document records its matter, its author, whether it is privileged, and its status.

Each requester carries the matters on which they are conflicted.

Each request carries the current date and the retention expiry.

A records manager may purge a document only after its matter is archived.

Before the retention period has expired, a records manager must not purge a document whose matter is not archived.

After the retention period has expired, the archived-matter requirement no longer blocks the records manager from purging the document.

A request by a records manager to purge a document that does not trip any prohibition above must be able to succeed.
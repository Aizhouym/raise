# Device Fleet Command Authorization — Ownership, Device State, and Maintenance Override

## Natural-Language Scenario

The system manages command issuance to a fleet of IoT and OT devices across sites.

The people involved are operators, technicians, fleet admins, and service accounts. One person may hold both the operator and technician roles at the same time.

The resources are devices, telemetry, and commands. Every device records its owner, its site group, its firmware tags, whether it is in maintenance mode, and its overall status. Every telemetry record notes its device and its sensitivity level. Every command record notes the device it targets and who issued it.

Each request carries whether it falls within a scheduled maintenance window for the target device.

An operator, a technician, or a fleet admin may send a command to a device only when the device is active, meaning it has finished provisioning and has not been decommissioned.

Sending a command to a device is allowed only when the requester owns that device.

When the requester does not own the target device, they may not send it a command.

During a scheduled maintenance window, a technician may send a command to a device that is currently in maintenance mode, even though a device in maintenance mode does not count as active.

Outside a scheduled maintenance window, a device in maintenance mode is treated as not active, and a command sent to it must be refused.

When a maintenance window is in effect, this maintenance exception overrides the requirement that the device be active.

An operator, a technician, and a fleet admin must not send a command to a device that is still being provisioned or has already been decommissioned, unless the maintenance-window exception for that device applies.

A request by an operator to send a command to a device they own, while the device is active and no maintenance window applies, must be able to succeed.

# Contract Execution

## Natural-Language Scenario

The system manages contract execution for a contract lifecycle management process.

The people involved are drafters, reviewers, signatories, and contract admins. One person may hold both the drafter and reviewer roles, and one person may hold both the reviewer and signatory roles.

The resources are contracts and signatures. Every contract records its drafter, reviewer, counterparty, contract value, required authority, effective date, and status.

Every signature records its contract, who signed it, and the amount.

Each requester carries signing authority and conflicted counterparties.

Each request carries the current date, whether it is on the corporate network, whether MFA was used, and whether escalation was approved.

A contract admin may execute a contract only after the contract has been signed.

A contract admin must not execute a contract that has not been signed.

A contract admin may execute a signed contract when the contract's effective date has arrived.

Before the contract's effective date has arrived, a contract admin must not execute it.

A contract admin may execute an otherwise valid contract when the request is made on the corporate network.

When the request is not made on the corporate network, a contract admin must not execute the contract.

A request by a contract admin to execute a contract that does not trip any prohibition above must be able to succeed.
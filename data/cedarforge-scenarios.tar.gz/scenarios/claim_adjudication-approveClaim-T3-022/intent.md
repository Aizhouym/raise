# Insurance Claim Approval

## Natural-Language Scenario

The system manages insurance claim adjudication and payout.

The people involved are adjusters, reviewers, claims managers, payout officers, fraud analysts, and auditors. One person may hold both the adjuster and reviewer roles, or both the reviewer and payout officer roles, at the same time.

The resources are claims and payouts. Every claim records its handler, approver, claim amount, deductible, line item count, status, claim code, fraud hold, and filing time.

A reviewer may approve a claim.

A claims manager may approve a claim.

Neither a reviewer nor a claims manager may approve a claim they handled as adjuster when the claim amount crosses the money threshold and the claim code matches the required code or prefix.

When the claim amount does not cross the money threshold, an adjuster who handled the claim may approve it.

When the claim code does not match the required code or prefix, an adjuster who handled the claim may approve it.

A request by a reviewer to approve a claim that does not trip any prohibition above must be able to succeed.
# Student Records and Grades

## Natural-Language Scenario

The system manages student records and grades for a school.

The people involved are instructors, students, parents, and the registrar. One person may hold both the instructor and parent role at the same time.

The resources are student records, grades, and courses. Every student record records its student, advisor, student age, FERPA block, and status, every grade records its student, course, grader, and status, and every course records its instructor and roster.

Each request carries the current date and whether it comes from the campus network.

A withdrawn student's record may be viewed only by the registrar when the student is under 18 and the request is not on the campus network.

For a withdrawn student who is 18 or older, this age-based restriction does not block an instructor, student, parent, or registrar from viewing the record.

For a withdrawn student under 18, a request from the campus network is not blocked by this rule.

An instructor, a student, and a parent must not view a withdrawn under-18 student's record from outside the campus network.

A request by an instructor to view a student record that does not trip any prohibition above must be able to succeed.
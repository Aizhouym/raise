# Repository Pull Request Review

## Natural-Language Scenario

The system manages source-code repository access and pull request review.

The people involved are developers, reviewers, maintainers, and security leads. One person may hold both the developer and reviewer role at the same time.

The resources are repositories, pull requests, and branches. Every repository records its owner, team, sensitivity, whether its default branch is protected, its topics, and its status.

Every pull request records its repository, author, approver, target branch, approval count, lines changed, whether it requires security review, and its status.

Every branch records its name and whether it is protected.

Each request carries the current time, whether the requester is on VPN, and whether break glass is being used.

A reviewer may review a pull request only while it is open.

A reviewer may review a pull request during a permitted review window.

Outside a permitted review window, a reviewer may not review a pull request.

A reviewer or maintainer must not approve their own pull request.

A maintainer must not review their own pull request.

A request by a reviewer to review a pull request that does not trip any prohibition above must be able to succeed.
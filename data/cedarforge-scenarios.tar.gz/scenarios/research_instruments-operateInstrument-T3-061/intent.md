# Research Facility Instrument Operation

## Natural-Language Scenario

The system manages access to research laboratory instruments.

The people involved are technicians, supervisors, safety officers, and visitors. One person may hold both the supervisor and technician role at the same time.

The resources are instruments, samples, and access badges. Every instrument records its hazard class, whether it is under maintenance, and its status.

Every sample records who opened it and its status. Every access badge records its holder and when it expires.

Each requester carries certifications. Each request carries the local time, whether the requester is on site, and whether a supervisor is present.

During staffed hours with a valid badge, a technician or supervisor may operate an instrument only if their certification level covers the instrument's hazard class.

When the badge is expired or the request is outside staffed hours, that certification requirement does not apply in this scenario.

A requester who is physically on site is not limited by the staffed-hours and badge-validity restriction in this scenario.

A technician or supervisor who is not on site must satisfy the staffed-hours and badge-validity restriction before operating an instrument.

A technician or supervisor must not operate an instrument when their certification level does not cover the instrument's hazard class and no exception above applies.

A request by a technician to operate an instrument that does not trip any prohibition above must be able to succeed.
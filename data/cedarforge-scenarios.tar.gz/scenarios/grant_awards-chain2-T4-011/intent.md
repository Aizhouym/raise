# Grant Award Approval then Obligation — Authority, Self-Award Bar, Large-Award Carve-Out, and Separation

## Natural-Language Scenario

The system manages the review, approval, and obligation of federal grant awards.

The people involved are reviewers, program officers, grants officers, and applicants; one person may hold both the reviewer and program officer roles, and one person may hold both the program officer and grants officer roles, at the same time.

The resources are grant applications and awards; every application records its applicant, its assigned reviewers, its funding tier, its requested amount, its program code, and its status, and every award records the application it comes from, who approved it, who obligated its funds, its amount, whether it is flagged high risk, and its status.

Each request carries the current time, whether it comes from the government network, and whether an emergency has been declared.

In this workflow an award is first approved and then its funds are obligated, and the obligation step can see the award's status and who approved it as recorded by the approval step.

A program officer or grants officer may approve an award only when their approval authority is at least the application's funding tier, and neither may approve an award whose funding tier exceeds their authority.

As a self-award check, when the requester is the applicant on the award they may not approve it, whereas a requester who is not the applicant is not blocked on this ground.

This authority requirement is set aside when the award's amount crosses the set money threshold, so such an award may be approved outside the normal authority ceiling, while for an award under that threshold the authority requirement holds.

A grants officer who approved an award may not obligate its funds, while a grants officer who did not approve it may obligate them.

A run through the workflow in which a program officer with sufficient approval authority who is not the applicant approves an award, and a grants officer who did not approve it then obligates its funds, tripping no prohibition above, must be able to succeed.

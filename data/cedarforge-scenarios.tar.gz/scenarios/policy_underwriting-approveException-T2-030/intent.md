# Underwriting Exception Approval

## Natural-Language Scenario

The system manages insurance application underwriting and exception approval before policies are bound.

The people involved are underwriters, senior underwriters, underwriting managers, chief underwriters, and auditors. One person may hold both the underwriter and senior underwriter role at the same time.

The resources are applications and policies. Every application records its assigned underwriter, risk tier, coverage lines, segment, premium, product code, exposure count, status, and effective date.

Each request carries the current time, whether it is on the corporate network, whether a catastrophe surge has been declared, and whether a staffing emergency has been declared.

A senior underwriter, underwriting manager, or chief underwriter may approve an authority exception only while the application is in the referred state when the requested effective date has not yet passed.

When the requested effective date has already passed, the referred-state requirement for approving an authority exception does not apply.

A senior underwriter, underwriting manager, or chief underwriter must not approve an authority exception for an application that is not in the referred state when the requested effective date has not yet passed.

An auditor may view the audit log.

A request by a senior underwriter to approve an exception that does not trip any prohibition above must be able to succeed.
# Marketplace Payout Disbursement — Binding of Duty with Emergency Override

## Natural-Language Scenario

The system manages seller payouts and listings for an online marketplace.

The people involved are sellers, payout agents, finance approvers, and risk analysts, and one person may hold both the payout agent and the finance approver role at the same time.

The resources are seller accounts, listings, and payouts. Every seller account records its holder, its KYC tier, its region, its fraud status, and its watchlist codes, every listing records its owner, category, price, category tier, risk labels, and status, and every payout records its account, who initiated it, who approved it, its amount, and its status.

Each requester also carries a verified tier and a home region, and each request carries whether it comes from a trusted network, whether multi-factor authentication was used, whether an emergency has been declared, and the current time.

A payout agent may disburse a payout.

The payout agent who initiated a payout must be the one who disburses it, and this same-initiator requirement applies only when the payout amount is $5,000 or more.

For payouts under $5,000, any payout agent may disburse the payout even if they were not the one who initiated it.

The same-initiator requirement also applies only when the seller account's KYC tier is Tier 2 or higher.

When the seller account's KYC tier is below Tier 2, the same-initiator requirement does not apply and any payout agent may disburse the payout.

The same-initiator requirement further applies only when multi-factor authentication was used for the disbursement request.

When multi-factor authentication was not used, the same-initiator requirement does not apply.

Unless an emergency has been declared, a payout agent must not disburse a payout that a different payout agent initiated once the amount, KYC tier, and MFA conditions above make the same-initiator requirement binding.

When an emergency has been declared, a different payout agent than the one who initiated the payout may disburse it, overriding the same-initiator requirement.

When an emergency has been declared, this emergency exception wins over the same-initiator requirement, even if the amount, KYC tier, and MFA conditions would otherwise make that requirement binding.

A request by a payout agent to disburse a payout that does not trip any of the restrictions above must be able to succeed.

# Classified Document Export

## Natural-Language Scenario

The system manages export of classified documents.

The people involved are analysts, officers, security admins, and contractors. One person may hold both the analyst and the officer role at the same time.

The resources are documents, dossiers, and access badges. Every document records its owner, classification, compartments, and status.

Each requester carries their clearance, compartments, and nationality.

Each request carries whether it is on the intranet and the current time.

An officer may export a document only when the officer's clearance is at least as high as the document's classification, unless the officer holds every compartment the document requires.

An officer who holds every compartment the document requires may export it without meeting the clearance comparison.

An officer must not export a document when their clearance is lower than the document's classification and they do not hold every compartment the document requires.

A request by an officer to export a document that does not trip any prohibition above must be able to succeed.
# Enterprise Document Management

## Natural-Language Scenario

The system manages document editing in an enterprise document management workspace.

The people involved are authors, editors, viewers, and compliance officers. One person may hold both the author and the editor role at the same time.

The resources are documents and workspaces. Every document records its owner, share list, classification, version lock, labels, and status.

Each requester has a clearance level.

An author may edit a document that carries the particular label only if their clearance is at least as high as the document's classification.

An editor may edit a document that carries the particular label only if their clearance is at least as high as the document's classification.

When an author or editor is on the document's share list, the clearance requirement does not block their edit.

For documents without that particular label, this clearance requirement does not apply.

An author or editor whose clearance is below a labeled document's classification and who is not on its share list must not edit it.

A request by an author to edit a document that does not trip any prohibition above must be able to succeed.
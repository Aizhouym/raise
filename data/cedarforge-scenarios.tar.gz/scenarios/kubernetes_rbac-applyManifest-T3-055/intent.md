# Kubernetes Namespace RBAC

## Natural-Language Scenario

The system manages applying Kubernetes workload manifests within namespaces.

The people involved are deployers, maintainers, cluster operators, and service accounts. One person may hold both the deployer and maintainer role at the same time.

The resources are namespaces, workloads, namespace secrets, and service account tokens. Every workload records its namespace, creator, required verb, replica count, labels, and environment.

Each requester carries a clearance, granted scope, and group membership.

Each request carries a source IP address, the current time, whether it is an emergency change, and whether MFA was used.

A deployer, maintainer, or cluster operator who authored a workload manifest must not apply it.

A deployer, maintainer, or cluster operator may apply a workload manifest only when their granted scope covers the verb the workload requires.

A deployer, maintainer, or cluster operator whose granted scope does not cover the required verb must not apply the workload manifest.

A deployer, maintainer, or cluster operator may apply a workload manifest only when the request comes from an allowed network range.

A deployer, maintainer, or cluster operator whose request does not come from an allowed network range must not apply the workload manifest.

A request by a deployer to apply a manifest that does not trip any prohibition above must be able to succeed.
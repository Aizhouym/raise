# Research Facility Instrument Operation

## Natural-Language Scenario

The system manages laboratory entry and instrument use in a research facility.

The people involved are technicians, supervisors, safety officers, and visitors. One person may hold both the supervisor and technician role at the same time.

The resources are instruments, samples, and access badges. Every instrument records its hazard class, whether it is under maintenance, and its status.

Each requester carries certifications.

Each request carries the local time, whether the requester is physically on site, and whether a supervisor is present.

A technician or supervisor may operate an instrument only when their certification level is at least as high as the instrument's hazard class.

A technician or supervisor whose certification level is below the instrument's hazard class must not operate the instrument when they are not physically on site and no supervisor is present.

When the requester is physically on site, the certification-level gate does not block operation of the instrument.

When a supervisor is present, the supervisor's presence overrides the certification-level gate.

If the certification-level gate and supervisor presence disagree, supervisor presence wins.

A request by a technician to operate an instrument that does not trip any prohibition above must be able to succeed.
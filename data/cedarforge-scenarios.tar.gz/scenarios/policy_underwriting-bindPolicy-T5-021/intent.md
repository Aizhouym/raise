# Policy Binding — Authority, Controlled Lines, Seniority, Segment, and Premium

## Natural-Language Scenario

The system manages insurance policy underwriting and binding.

The people involved are underwriters, senior underwriters, underwriting managers, chief underwriters, and auditors. One person may hold both the underwriter and senior underwriter roles at the same time.

The resources are applications and policies. Every application records its assigned underwriter, its risk tier, its coverage lines, its segment, its premium, its product code, its exposure count, its status, and its effective date. Every policy records the application it came from, who bound it, its premium, and its effective date.

An underwriter, a senior underwriter, or an underwriting manager may bind a policy.

A policy may be bound only when the underwriter's granted authority level covers the application's assessed risk tier, and an underwriter whose authority does not reach that risk tier may not bind it.

A policy may be bound only when the application's coverage lines include a controlled or excess-and-surplus line, and an application without such a line does not go through this binding path.

A policy may be bound only when the binder holds at least the senior-underwriter role, and an underwriter below that role may not bind it.

An underwriter whose authority does not reach the risk tier may still bind the policy when the application's segment tag matches a monitored market segment, or when the annual premium is over the money threshold.

Neither an underwriter, a senior underwriter, nor an underwriting manager below the senior-underwriter role may bind a policy on a controlled or excess-and-surplus line.

A request by a senior underwriter whose authority covers the risk tier to bind a policy on a controlled line, tripping no prohibition above, must be able to succeed.

# Claim Payout

## Natural-Language Scenario

The system manages insurance claim adjudication and payout.

The people involved are adjusters, reviewers, claims managers, payout officers, fraud analysts, and auditors. One person may hold both the adjuster and reviewer roles, or both the reviewer and payout officer roles, at the same time.

The resources are claims and payouts. Every claim records its handler, approver, claim amount, deductible, line item count, status, claim code, fraud hold, and filing time, and every payout records its claim, issuer, and amount.

Each request carries the current time, whether it comes from the corporate network, and whether a catastrophe has been declared.

A payout officer or claims manager who approved a claim must not issue its payout when the claim's line item count crosses the threshold.

When the claim's line item count does not cross the threshold, the person who approved the claim may issue its payout.

During a declared catastrophe, a claims manager may issue a payout on a claim they approved, even when the line item count crosses the threshold.

When no catastrophe has been declared, that catastrophe exception does not apply.

When a catastrophe has been declared, the catastrophe exception wins over the rule that keeps the approver from issuing the payout.

A payout officer must not issue the payout for a claim they approved when the claim's line item count crosses the threshold and no catastrophe exception applies.

A claims manager must not issue the payout for a claim they approved when the claim's line item count crosses the threshold and no catastrophe has been declared.

A request by a payout officer to issue a payout that does not trip any prohibition above must be able to succeed.
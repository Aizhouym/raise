# Equipment Calibration and Return-to-Service

## Natural-Language Scenario

The system manages equipment calibration and return-to-service decisions.

The people involved are calibration technicians, senior technicians, metrology managers, quality inspectors, and maintenance supervisors. One person may hold both the calibration technician and the senior technician role at the same time.

The resources are assets and calibration records. Every asset records its technician, equipment class, status, calibration due time, out-of-service flag, measurement point count, asset tag, and hazard class.

Each request carries the current time, whether it originates on the plant network, whether the requester is clean-room certified, and whether an emergency has been declared.

A calibration technician or senior technician may begin calibration only while the asset is in the due state when no exception applies.

For an asset flagged out of service for maintenance, the due-state requirement does not block calibration.

For a request originating on the plant network, the due-state requirement does not block calibration.

A calibration technician or senior technician must not perform calibration on an asset that is not in the due state when the asset is not flagged out of service for maintenance and the request does not originate on the plant network.

A request by a calibration technician to perform a calibration that does not trip any prohibition above must be able to succeed.
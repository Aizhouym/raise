# Patent Prosecution Docket Access

## Natural-Language Scenario

The system manages access to patent prosecution docket materials for a patent practice.

The people involved are patent attorneys, docket clerks, examiners, and inventors. One person may hold both the patent attorney and docket clerk roles, and one person may hold both the examiner and inventor roles.

The resources are patent applications, office actions, and filings. Every patent application records its inventor, prosecuting attorney, assigned examiner, team, confidentiality level, bar date, and status.

Every office action records its application, author, and status.

Every filing records its application, who filed it, and its status.

Each requester carries a clearance level.

Each request carries the current date, whether it is on the firm network, whether there is a court disclosure order, and whether multifactor authentication was used.

A patent attorney, docket clerk, or examiner may access a patent application only when the requester’s clearance is at least as high as the application’s confidentiality level.

When the access request is on the firm network, the clearance requirement applies.

When the access request is not on the firm network, the firm-network restriction does not make the clearance requirement apply.

A court disclosure order overrides the confidentiality clearance requirement.

When there is no court disclosure order, the confidentiality clearance requirement is not overridden.

If a court disclosure order and the confidentiality clearance requirement point to different answers, the court disclosure order wins.

A patent attorney, docket clerk, or examiner must not access a patent application from the firm network when their clearance is lower than the application’s confidentiality level and there is no court disclosure order.

A request by a patent attorney to access an application that does not trip any prohibition above must be able to succeed.
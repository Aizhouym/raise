# Internal Wiki Knowledge Base

## Natural-Language Scenario

The system manages page viewing in an internal wiki knowledge base.

The people involved are contributors, reviewers, space admins, and readers. One person may hold both the contributor and reviewer role at the same time.

The resources are pages and spaces. Every page records its author, reviewer, space, classification, whether external sharing is enabled, labels, and status, and every space records its members.

Each requester carries their clearance and space memberships.

Each request carries whether it is on the corporate network, the current time, and whether emergency access has been declared.

A reader, contributor, reviewer, or space admin may view a page only when the request is made from the corporate network.

A reader, contributor, reviewer, or space admin must not view a page from outside the corporate network.

A reader, contributor, reviewer, or space admin may view a page only when their clearance meets or exceeds the page's classification.

A reader, contributor, or reviewer must not view a page above their clearance.

A space admin may view a page above their clearance when emergency access has been declared.

When emergency access has been declared, the emergency rule for a space admin wins over the normal clearance requirement.

A request by a reader to view a page from the corporate network with clearance that meets the page's classification must be able to succeed.
# Invoice Payment

## Natural-Language Scenario

The system manages invoice approval and payment for a finance department.

The people involved are clerks, approvers, finance managers, and auditors. One person may hold both the clerk and the approver role at the same time.

The resources are invoices and payments. Every invoice records its creator, approver, amount, surcharge, line item count, status, cost center, and submission time.

Every payment records its invoice, issuer, and amount.

Each request carries the current time, whether it is on the corporate network, and whether an emergency has been declared.

A finance manager who approved an invoice may not issue its payment when the payment amount crosses the organization's money threshold and the request is made within business hours.

For payments that do not cross the organization's money threshold, that approval-based restriction does not prevent the finance manager who approved the invoice from issuing its payment.

Outside business hours, that approval-based restriction does not prevent the finance manager who approved the invoice from issuing its payment.

A request by a finance manager to issue a payment that does not trip any prohibition above must be able to succeed.
# Kubernetes Namespace Deployment Gate

## Natural-Language Scenario

The system manages who can apply workload manifests inside a Kubernetes namespace-based deployment platform.

The people involved are deployers, maintainers, cluster operators, and service accounts, and one person may hold both the deployer and the maintainer role at the same time.

The resources are namespaces, workloads, namespace secrets, and service account tokens; every namespace records its members, its team group, and its environment, and every workload records its namespace, its creator, the verb it requires, its replica count, its labels, and its environment.

Each request carries the network address it comes from, the current time, whether it is an emergency change, and whether multi-factor authentication was used.

A deployer, maintainer, or cluster operator may not apply a manifest to a workload whose environment is production until that workload's namespace has been promoted to production.

Once the namespace has been promoted to production, a deployer, maintainer, or cluster operator may apply the manifest to that production workload.

A deployer, maintainer, or cluster operator may apply a manifest only when their granted scope covers the verb the workload requires, such as the apply verb.

If the workload requires a verb, such as exec, that is not included in the requester's granted scope, the manifest may not be applied.

A deployer, maintainer, or cluster operator may apply a manifest only when the workload carries the label marking it approved for release.

A workload that does not carry the release-approved label may not have a manifest applied to it.

A deployer, maintainer, or cluster operator may apply a manifest only when they belong under the workload's namespace team group.

A requester who is not a member of the namespace's team group may not apply a manifest to that namespace's workloads.

A deployer, maintainer, or cluster operator may apply a manifest only when the request comes from the corporate network range.

A request arriving from outside the corporate network range may not be used to apply a manifest, even by a deployer, maintainer, or cluster operator.

A deployer, maintainer, and cluster operator must not apply a manifest to any workload when any of the above conditions fail.

A request by a deployer to apply a manifest to a non-production, release-approved workload, made from the corporate network by a team member whose granted scope covers the required verb, must be able to succeed.

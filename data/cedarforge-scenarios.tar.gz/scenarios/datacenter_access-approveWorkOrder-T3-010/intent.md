# Datacenter Cage Work Order Approval

## Natural-Language Scenario

The system manages physical access and maintenance approval for datacenter cages.

The people involved are facility techs, tenant engineers, security ops, and escorts. One person may hold both the facility tech and escort role at the same time.

The resources are cages, work orders, and access badges. Every cage records its tenant, zone clearance, occupant list, site zone, escort requirement, and status.

Every work order records its cage, who raised it, who approved it, and its status.

Every access badge records its holder and when it expires.

Each requester carries a clearance level and membership information.

Each request carries the current time, whether an escort is present, the maintenance window, and whether the request is from the on-site management network.

A security ops approver may approve a work order only while it is open.

A security ops approver must not approve a work order that is not open.

A security ops approver may approve an open work order only when the request comes from the on-site management network.

A security ops approver must not approve a work order from outside the on-site management network.

A security ops approver may approve an open work order only when they belong under the site zone of the cage named by the work order.

A security ops approver must not approve a work order for a cage in a site zone they do not belong under.

A request by a security ops approver to approve an open work order from the on-site management network, for a cage in a site zone they belong under, must be able to succeed.
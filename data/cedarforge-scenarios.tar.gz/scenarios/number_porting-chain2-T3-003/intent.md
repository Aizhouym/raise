# Number Port Authorization then Cutover — Separation of Duty, then Binding of Duty

## Natural-Language Scenario

This system manages number portability authorization and cutover for a telephone carrier.

The people involved are porting specialists, porting supervisors, fraud reviewers, line technicians, and auditors. One person may hold both the porting specialist and fraud reviewer roles at the same time, and one person may hold both the line technician and porting specialist roles at the same time.

The resources are port requests and port completions. Every port request records who initiated it, who authorized it, the technician assigned to it, the account numbers being ported, the size of the number block, the gaining carrier code, the port type, the subscriber's region, its status, and the time it was requested. Every port completion records the request it belongs to, who completed the cutover, and the time the numbers were ported.

Each request carries the current time, whether it comes from the carrier's own operations network, whether a port-freeze override has been declared, and whether a regulator escalation is in effect.

In this workflow a port request is first authorized and then its cutover is completed, and the completion step can see the request's status, who initiated it, and which technician was assigned, as recorded by the authorization step.

The porting specialist who submitted a port request may not authorize that same request, while a specialist or supervisor who did not submit it may authorize it.

The line technician assigned to a port must be the one who executes its cutover.

When the cutover falls within the scheduled porting window, someone other than the assigned technician may execute it.

Outside the scheduled porting window, neither a line technician nor a porting supervisor other than the assigned technician may execute the cutover.

A run through the workflow by a porting specialist who authorizes a port they did not submit and whose assigned technician then completes the cutover, tripping no prohibition above, must be able to succeed.

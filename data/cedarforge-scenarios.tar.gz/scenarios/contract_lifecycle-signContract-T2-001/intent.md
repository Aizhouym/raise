# Contract Signing Authority

## Natural-Language Scenario

The system manages the drafting, review, and signing of legal contracts for the organization.

The people involved are drafters, reviewers, signatories, and contract admins; one person may hold both the drafter and reviewer roles, or both the reviewer and signatory roles, at the same time.

The resources are contracts and signatures; every contract records its drafter, reviewer, counterparty, contract value, required authority tier, effective date, and status, and every signature records the contract it belongs to, who signed it, and the amount.

Each signatory and contract admin carries a delegated signing authority tier, ranging from Tier 1 up to Tier 3.

A signatory or a contract admin may sign a contract.

When a contract's value crosses $100,000, the signer's delegated authority tier must be at least as high as the contract's required authority tier before they may sign it.

For contracts valued at $100,000 or less, a signatory or a contract admin may sign the contract regardless of their delegated authority tier.

A signatory or a contract admin whose delegated authority tier is lower than the contract's required authority tier must not sign a contract valued above $100,000.

A request by a signatory whose delegated authority tier meets or exceeds the contract's required authority tier to sign a contract valued above $100,000 must be able to succeed.

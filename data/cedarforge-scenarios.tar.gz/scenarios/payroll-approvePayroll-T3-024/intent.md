# Payroll Approval

## Natural-Language Scenario

The system manages payroll preparation and approval for the personnel and payroll department.

The people involved are employees, managers, h r specialists, and payroll admins. One person may hold both the manager and the employee role at the same time.

The resources are payroll runs, employee records, and leave requests. Every payroll run records who prepared it, who approved it, its amount, and its status.

Each requester carries clearance, and each request carries whether it is on vpn and the current time.

A manager or payroll admin may approve a payroll run only after it has been submitted.

A manager or payroll admin may approve a submitted payroll run when no other rule blocks the approval.

The admin who prepared a payroll run may not approve it.

A manager must not approve a payroll run before it is submitted.

A payroll admin must not approve a payroll run before it is submitted.

A request by a manager to approve a payroll run that does not trip any prohibition above must be able to succeed.
# Immigration Security Check Clearance

## Natural-Language Scenario

The system manages immigration case adjudication and background security clearance for a government agency.

The people involved are adjudication officers, supervisory officers, background investigators, and records clerks. One person may hold both the adjudication officer and background investigator roles at the same time, and a supervisory officer may also hold the adjudication officer role.

The resources are cases, security checks, and applicant records. Every case records its applicant, the officer assigned to it, its case team, its field office, and its status. Every security check records the case it belongs to, the investigator assigned to it, and its status. Every applicant record records the applicant, the assigned officer, the need-to-know team, its data sensitivity level, and its status.

Each request carries whether it comes from the agency's government network, the current time, and whether supervisor approval has been given.

A background investigator or a supervisory officer may clear a security check.

The background investigator formally assigned to a security check must be the one who clears it.

A background investigator or supervisory officer must not clear a security check that is not the one assigned to them.

Clearing a security check is only allowed when the request falls within the permitted review window of 6:00 a.m. to 10:00 p.m. on the gov network.

Outside the 6:00 a.m. to 10:00 p.m. window, no request to clear a security check may proceed, even if the requesting investigator is the one properly assigned to it.

An adjudication officer may adjudicate a case that has completed its security check.

A records clerk may record intake for a new case.

A request by a background investigator to clear a security check assigned to them, submitted between 6:00 a.m. and 10:00 p.m. on the gov network, must be able to succeed.

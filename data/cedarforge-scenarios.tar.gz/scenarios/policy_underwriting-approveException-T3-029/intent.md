# Insurance Underwriting Exception Approval

## Natural-Language Scenario

The system manages insurance policy underwriting and binding.

The people involved are underwriters, senior underwriters, underwriting managers, chief underwriters, and auditors. One person may hold both the underwriter and senior underwriter role at the same time.

The resources are applications and policies. Every application records its assigned underwriter, risk tier, coverage lines, segment, premium, product code, exposure count, status, and effective date.

Every policy records its application, who bound it, its premium, and its effective date.

Each request carries the current time, whether it is on the corporate network, whether a catastrophe surge has been declared, and whether a staffing emergency has been declared.

A senior underwriter, underwriting manager, or chief underwriter may approve an authority exception only while the application is in the referred state.

A senior underwriter, underwriting manager, or chief underwriter must not approve an authority exception while the application is not in the referred state.

When the coverage lines include a line that requires escalated exception review, the referred-state requirement applies.

When the coverage lines do not include a line that requires escalated exception review, the referred-state requirement does not apply.

When the requested effective date has not yet passed relative to the current time, the exception may be approved.

A senior underwriter, underwriting manager, or chief underwriter must not approve an exception when the requested effective date has already passed.

A request by a senior underwriter to approve an exception that does not trip any prohibition above must be able to succeed.
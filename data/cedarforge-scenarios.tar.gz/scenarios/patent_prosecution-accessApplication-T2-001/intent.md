# Patent Application Access — Clearance Gate with Publication Exception

## Natural-Language Scenario

The system manages the patent prosecution docket of a law firm.

The people involved are patent attorneys, docket clerks, examiners, and inventors. One person may hold both the patent attorney and docket clerk roles at the same time, and one person may hold both the examiner and inventor roles at the same time.

The resources are patent applications, office actions, and filings. Every patent application records its inventor, prosecuting attorney, assigned examiner, team, confidentiality level, bar date, and status. Every office action records the application it responds to, its author, and its status. Every filing records the application it relates to, who filed it, and its status.

Each request carries the requester's clearance level, the current date, whether it was made from the firm's network, whether a court order was presented, and whether multi-factor authentication was used.

A patent attorney, docket clerk, or examiner may not access a patent application unless their clearance level is equal to or higher than the application's confidentiality level.

This clearance requirement is waived once the application has reached published status; a patent attorney, docket clerk, or examiner may access a published application even if their clearance level is lower than its confidentiality level.

A patent attorney, docket clerk, or examiner must not access a patent application that is still unpublished if the application's confidentiality level is higher than that person's own clearance level.

A request by a patent attorney whose clearance level meets or exceeds the confidentiality level of an unpublished patent application to access it must be able to succeed.

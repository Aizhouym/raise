# Equipment Calibration then Return-to-Service — Competence, then Approval Gates

## Natural-Language Scenario

The system manages equipment calibration and return-to-service approval in a plant metrology program.

The people involved are calibration technicians, senior technicians, metrology managers, quality inspectors, and maintenance supervisors. One person may hold both the calibration technician and the senior technician role at the same time.

The resources are assets and calibration records. Every asset records its assigned technician, its equipment class, its status, its calibration due date, whether it is out of service, its measurement point count, its asset tag, and its hazard class. Every calibration record records its asset, the technician who calibrated it, the result, and when it was calibrated.

Each request carries the current time, whether it comes from the plant network, whether the requester is clean-room certified, and whether an emergency has been declared.

In this workflow an asset is first calibrated and then its return to service is approved, and the approval step can see the asset's status and equipment class as recorded through the calibration step.

A calibration technician or senior technician may perform a calibration only when their certification level is high enough for the asset's equipment class, and one whose certification level is below the asset's equipment class may not perform it.

A quality inspector or metrology manager may approve a return to service only after the asset has reached the calibrated state, and a request to approve one in any earlier state is refused.

A return to service may be approved only when the approver holds a current clean-room re-entry certification, and without that certification neither a quality inspector nor a metrology manager may approve it.

When the asset carries a hazardous-material tag its return to service requires an additional sign-off before it may be approved, while an asset with no hazardous-material tag needs no additional sign-off.

A run through the workflow, begun by a calibration technician who calibrates an asset within their certification level and carried through to a return to service approved with the required clean-room certification and any hazardous-material sign-off, tripping no prohibition above, must be able to succeed.

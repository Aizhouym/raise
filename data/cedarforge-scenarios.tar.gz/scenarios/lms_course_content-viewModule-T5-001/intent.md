# Learning Module Visibility and Content-Lock Rules

## Natural-Language Scenario

The system manages course content and gradebook access for an online learning platform.

The people involved are instructors of record, teaching assistants, learners, and coordinators, and one person may hold both the instructor of record and teaching assistant roles at the same time.

The resources are modules and grade entries; every module records its course, its instructor of record, its roster, its prerequisite level, its release time, whether it is content-locked, and its status, while every grade entry records its learner, its module, who posted it, and its status.

A module may be viewed only once it has reached released status, and it may not be viewed while it is still in draft or scheduled status.

An instructor of record may view a module only when they are recorded as that module's instructor of record.

An instructor of record who is not the instructor of record listed on a given module may not view it under this rule.

A learner may view a module only when they appear on that module's roster.

A learner who does not appear on the roster may not view the module.

A coordinator may view any released module across any course by virtue of holding the coordinator role, without needing to be its instructor of record or to appear on its roster.

A teaching assistant, a learner, or an instructor of record who does not hold the coordinator role does not receive this blanket viewing right and must instead satisfy the instructor-of-record or roster rules above.

When a module carries a content-lock flag, it may be viewed only by a requester whose completed level is at least the module's prerequisite level.

When a module does not carry a content-lock flag, a requester may view it regardless of their completed level.

A teaching assistant, a learner, a coordinator, or an instructor of record must not view a module that is not yet released, that they are not authorized to view under the instructor-of-record, roster, or coordinator rules above, or that is content-locked while their completed level falls below the module's prerequisite level.

A request by an instructor of record to view a released module that does not trip any of these restrictions must be able to succeed.

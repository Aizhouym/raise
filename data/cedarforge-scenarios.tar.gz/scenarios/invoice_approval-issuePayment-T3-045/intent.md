# Invoice Payment

## Natural-Language Scenario

The system manages invoice approval and payment.

The people involved are clerks, approvers, finance managers, and auditors. One person may hold both the clerk and the approver role at the same time.

The resources are invoices and payments. Every invoice records its creator, approver, amount, surcharge, line item count, status, cost center, and submission time.

Every payment records its invoice, issuer, and amount.

Each request carries the current time, whether it is on the corporate network, and whether an emergency has been declared.

A finance manager may issue a payment only during business hours.

Outside business hours, a finance manager must not issue a payment.

When the request is not on the corporate network, a finance manager may issue a payment only for an approved invoice.

When the request is on the corporate network, the approved-invoice requirement does not prevent the finance manager from issuing the payment.

A request by a finance manager to issue a payment that does not trip any rule above must be able to succeed.
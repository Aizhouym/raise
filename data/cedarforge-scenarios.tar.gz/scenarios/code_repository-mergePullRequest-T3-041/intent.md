# Repository Pull Request Merge

## Natural-Language Scenario

The system manages source-code repository access and pull request merging.

The people involved are developers, reviewers, maintainers, and security leads. One person may hold both the developer and reviewer role at the same time.

The resources are repositories, pull requests, and branches. Every repository records its owner, team, sensitivity, whether its default branch is protected, its topics, and its status.

Every pull request records its repository, author, approver, target branch, approval count, lines changed, whether security review is required, and status.

Every branch records its name and whether it is protected.

Each requester carries clearance.

Each request carries the current time, whether the requester is on VPN, and whether break glass is being used.

A maintainer who authored a pull request must not merge it when that pull request requires security review and the request falls within a permitted merge window.

If a pull request does not require security review, its author may merge it.

If the request falls outside a permitted merge window, the author may merge their own pull request.

A request by a maintainer to merge a pull request that does not trip any prohibition above must be able to succeed.
# Insurance Claim Approval

## Natural-Language Scenario

The system manages insurance claim adjudication and payout.

The people involved are adjusters, reviewers, claims managers, payout officers, fraud analysts, and auditors. One person may hold both the adjuster and reviewer roles, or both the reviewer and payout officer roles, at the same time.

The resources are claims and payouts. Every claim records its handler, approver, claim amount, deductible, line item count, status, claim code, fraud hold, and filing time.

Each request carries the current time, whether it is on the corporate network, and whether a catastrophe has been declared.

A claim may be approved only after it has been reviewed when its line item count crosses the applicable threshold.

When the claim's line item count does not cross that threshold, this reviewed-status requirement does not bind approval.

A claim may be approved only after it has been reviewed when its claim code matches the covered code or has the covered prefix.

When the claim code does not match the covered code and does not have the covered prefix, this claim-code requirement does not bind approval.

A reviewer or claims manager must not approve a claim that requires prior review before the claim has been reviewed.

A request by a reviewer to approve a claim that does not trip any prohibition above must be able to succeed.
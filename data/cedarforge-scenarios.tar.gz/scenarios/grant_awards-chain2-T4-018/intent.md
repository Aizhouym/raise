# Approving a grant award and obligating its funds with amount and network gates

## Natural-Language Scenario

This document describes how a federal grant award is approved and then its funds are obligated.
The people involved are reviewers, program officers, grants officers, and applicants, and one person may serve as both a reviewer and a program officer, or as both a program officer and a grants officer, at the same time.
The resources are applications, which note the applicant, the assigned reviewers, the funding tier, the requested amount, the program code, and the status; and awards, which note the application, who approved them, who obligated their funds, the amount, whether they are high risk, and the status.
Each request carries the current time, whether it is on the government network, and whether an emergency is declared.
An award is first approved and then its funds are obligated on the same record, and the obligate step can see the award's status, who approved it, and who obligated it.
When approving an award, the officer's approval authority must be high enough to cover the application's funding tier.
An award may be approved only when its amount crosses the money threshold, and when the amount stays below that threshold this approval requirement does not bind.
An award may be approved only when the request comes from the government network, and a request from off that network may not approve it.
When obligating funds, the officer who approved the award may not be the one who obligates its funds.
A program officer must not obligate funds, since obligating funds is reserved for a grants officer.
A run through the workflow by a program officer that trips none of the prohibitions above must be able to succeed.

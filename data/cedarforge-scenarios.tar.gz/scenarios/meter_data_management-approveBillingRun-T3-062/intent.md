# Billing Run Approval

## Natural-Language Scenario

The system manages meter data management and billing runs.

The people involved are meter readers, billing analysts, billing managers, data stewards, and auditors. One person may hold both the meter reader and data steward roles, or both the billing analyst and meter reader roles, at the same time.

The resources are billing runs and meter accounts. Every billing run records its account, preparer, approver, bill amount, usage, rate, rate class, region, account tier, status, and when it was prepared.

Every meter account records its account holder, last reader, tier, adjustment count, last bill amount, rate class, region, status, and last read time.

Each request carries the current time, whether it comes from the corporate network, and whether an emergency has been declared.

A billing run may be approved only after it has reached the submitted stage when the approver is acting as a billing manager and the run is not tagged with a regulated rate class.

For billing runs tagged with a regulated rate class, the submitted-stage requirement does not apply.

When the approver is not acting as a billing manager, the submitted-stage requirement does not bind the approval request.

A billing analyst and a billing manager must not approve a billing run that has not reached the submitted stage when the approver is acting as a billing manager and the run is not tagged with a regulated rate class.

A request by a billing analyst to approve a billing run that does not trip any prohibition above must be able to succeed.
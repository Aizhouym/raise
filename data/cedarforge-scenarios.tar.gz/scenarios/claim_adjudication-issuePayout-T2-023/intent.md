# Claim Payout

## Natural-Language Scenario

The system manages insurance claim adjudication and payout.

The people involved are adjusters, reviewers, claims managers, payout officers, fraud analysts, and auditors. One person may hold both the adjuster and reviewer roles, or both the reviewer and payout officer roles, at the same time.

The resources are claims and payouts. Every claim records its handler, approver, claim amount, deductible, line item count, status, claim code, fraud hold, and filing time.

Each request carries the current time, whether it is on the corporate network, and whether a catastrophe has been declared.

A payout officer may issue a payout only after the claim has been approved.

A claims manager may issue a payout only after the claim has been approved.

A payout may be issued for an approved claim only when the claim is not flagged with a fraud hold.

When an approved claim is not flagged with a fraud hold, the fraud-hold rule does not block the payout.

A payout officer or claims manager must not issue a payout for an unapproved claim or for a claim flagged with a fraud hold.

A request by a payout officer to issue a payout that does not trip any prohibition above must be able to succeed.
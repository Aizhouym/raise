# Retail Orders and Refunds

## Natural-Language Scenario

The system manages retail orders, refunds, and refund oversight.

The people involved are customers, service reps, managers, and auditors. One person may hold both the service rep and the manager role at the same time.

The resources are orders and refunds. Every order records its customer, who placed it, item total, tax amount, loyalty tier, whether it contains card data, and its status.

Every refund records its order, who issued it, and its amount.

Each request carries whether it is inside the cardholder-data zone, whether MFA was used, and the current time.

A customer may place an order.

A service rep or manager may issue a refund only when the request is inside the cardholder-data zone.

A service rep or manager must not issue a refund when the request is outside the cardholder-data zone.

Inside the cardholder-data zone, a service rep or manager may issue a refund for a shipped order.

Inside the cardholder-data zone, a service rep or manager may not issue a refund for an order that has not shipped when the refund amount does not cross the money threshold.

When the refund amount crosses the money threshold, the shipped-order requirement does not block the refund.

A manager may approve a refund.

An auditor may review refund activity.

A request by a service rep to issue a refund inside the cardholder-data zone for a shipped order with an amount that does not trip any prohibition above must be able to succeed.
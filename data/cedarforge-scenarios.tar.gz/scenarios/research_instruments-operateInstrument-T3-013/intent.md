# Instrument Operation

## Natural-Language Scenario

The system manages access to research facility instruments.

The people involved are technicians, supervisors, safety officers, and visitors. One person may hold both the supervisor and the technician role at the same time.

The resources are instruments, samples, and access badges. Every instrument records its hazard class, whether it is under maintenance, and its status.

Each requester carries their certifications.

Each request carries the local time, whether the requester is on site, and whether a supervisor is present.

A technician may operate an instrument only when their certification level covers the instrument's hazard class.

When the requester is not acting as a technician, the technician certification rule does not bind that request.

The certification requirement does not apply when the instrument is marked as under maintenance.

When the instrument is not marked as under maintenance, the certification requirement applies to technicians.

A technician or supervisor must not operate an instrument as a technician when their certification level does not cover the instrument's hazard class.

A request by a technician to operate an instrument that does not trip any prohibition above must be able to succeed.
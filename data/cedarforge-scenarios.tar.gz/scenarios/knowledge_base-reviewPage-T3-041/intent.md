# Internal Wiki Review

## Natural-Language Scenario

The system manages review of pages in an internal wiki knowledge base.

The people involved are contributors, reviewers, space admins, and readers. One person may hold both the contributor and reviewer role at the same time.

The resources are pages and spaces. Every page records its author, reviewer, space, classification, whether external sharing is enabled, labels, and status, and every space records its members.

Each request carries whether it is on the corporate network, the current time, and whether emergency access is being used.

A reviewer or space admin may review a page only while the page is in review status.

A reviewer or space admin may not review a page that is still draft or already published.

A reviewer or space admin may review a page only during a permitted time window.

Outside the permitted time window, neither a reviewer nor a space admin may review a page.

Neither a reviewer nor a space admin may review a page they authored.

A reviewer or space admin who did not author the page may review it when the page is in review status and the request is within the permitted time window.

A request by a reviewer to review a page that does not trip any prohibition above must be able to succeed.
# Meter Data Management and Billing Runs

## Natural-Language Scenario

The system manages meter readings, billing runs, and audit review for utility accounts.

The people involved are meter readers, billing analysts, billing managers, data stewards, and auditors. One person may hold both the meter reader and data steward roles, and one person may hold both the billing analyst and meter reader roles.

The resources are billing runs and meter accounts. Every billing run records its account, preparer, approver, bill amount, usage, rate, rate class, region, account tier, status, and when it was prepared.

Every meter account records its account holder, who last read it, its tier, adjustment count, last bill amount, rate class, region, status, and when it was last read.

Each request carries the current time, whether it is on the corporate network, and whether an emergency has been declared.

A meter reader or data steward who recorded the last reading on a meter account may not adjust that reading when the account's adjustment count has crossed the threshold and the request is within business hours.

When the account's adjustment count has not crossed the threshold, the person who recorded the last reading may adjust it.

Outside business hours, the no-self-adjustment rule does not apply.

A meter reader must not adjust a reading they recorded when the adjustment count has crossed the threshold and the request is within business hours.

A data steward must not adjust a reading they recorded when the adjustment count has crossed the threshold and the request is within business hours.

A request by a meter reader to adjust a reading that does not trip any prohibition above must be able to succeed.
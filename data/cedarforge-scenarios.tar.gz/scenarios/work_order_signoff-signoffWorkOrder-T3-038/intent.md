# Manufacturing Work-Order QA Sign-Off

## Natural-Language Scenario

The system manages QA sign-off and production release for manufacturing work orders.

The people involved are operators, inspectors, quality managers, production supervisors, and auditors. One person may hold both the operator and inspector roles, or both the inspector and quality manager roles, at the same time.

The resources are work orders and production releases. Every work order records its operator, inspector, part code, defect count, hold flag, status, station, and creation time, and every production release records its work order, who released it, and its batch code.

Each request carries the current time, whether it comes from the plant floor network, and whether a deviation has been authorized.

An inspector or quality manager who performed the work as the operator may not sign off that work order.

An inspector or quality manager who did not perform the work as the operator may sign off the work order if no other prohibition applies.

A work order may be signed off only while its status is in progress.

An inspector or quality manager must not sign off a work order whose status is not in progress.

A work order may be signed off only when the request comes from the plant floor network.

An inspector or quality manager must not sign off a work order from outside the plant floor network.

A request by an inspector to sign off an in-progress work order from the plant floor network, where the inspector was not the operator who performed the work, must be able to succeed.
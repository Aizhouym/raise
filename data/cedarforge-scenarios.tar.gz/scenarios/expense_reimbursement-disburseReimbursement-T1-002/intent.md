# Employee Expense Reimbursement

## Natural-Language Scenario

The system manages employee expense reports and reimbursement disbursement.

The people involved are employees, line managers, finance reviewers, and controllers. One person may hold both the employee and line manager role at the same time.

The resources are expense reports and reimbursements. Every expense report records its submitter, approver, total amount, meal total, lodging total, category, amount tier, whether a receipt is attached, its status, and when it was submitted.

Every reimbursement records its expense report, who disbursed it, and its amount.

Each requester carries an approval tier.

Each request carries whether it is on the corporate network, the current time, and whether it is an emergency approval.

A controller may disburse a reimbursement only when the related expense report has approved status.

A controller must not disburse a reimbursement for an expense report that has not been approved.

A request by a controller to disburse a reimbursement that does not trip any prohibition above must be able to succeed.
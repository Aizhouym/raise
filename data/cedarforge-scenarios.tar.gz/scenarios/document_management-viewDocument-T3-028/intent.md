# Enterprise Document Management

## Natural-Language Scenario

The system manages viewing documents in an enterprise document management workspace.

The people involved are authors, editors, viewers, and compliance officers. One person may hold both the author and the editor role at the same time.

The resources are documents and workspaces. Every document records its owner, share list, classification, whether its version is locked, labels, and status.

Each requester carries a clearance, and each request carries whether it comes from the corporate network and the current time.

An author, editor, viewer, or compliance officer on a document's share list may view it only when their clearance dominates the document's classification.

When the requester is not on the document's share list, the clearance rule does not block the view request.

When the document is in the specified lifecycle stage, the clearance rule does not block the view request.

An author, editor, viewer, or compliance officer must not view a shared document outside that lifecycle stage when their clearance does not dominate the document's classification.

A request by an author to view a document that does not trip any prohibition above must be able to succeed.
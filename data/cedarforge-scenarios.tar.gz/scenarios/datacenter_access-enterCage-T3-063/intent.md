# Datacenter Cage Physical Access

## Natural-Language Scenario

The system manages physical entry to datacenter cages.

The people involved are facility techs, tenant engineers, security ops, and escorts. One person may hold both the facility tech and escort role at the same time.

The resources are cages, work orders, and access badges. Every cage records its tenant, zone clearance, occupant list, site zone, whether an escort is required, and its status.

Each requester carries a clearance level and membership information.

Each request carries the current time, whether an escort is present, the maintenance window, and whether the requester is on the site network.

A facility tech, tenant engineer, or escort may enter a cage only while the cage is active.

A facility tech, tenant engineer, or escort must not enter a cage that is locked or decommissioned.

A facility tech, tenant engineer, or escort may enter a cage only when they are on that cage's authorized-occupant list.

A facility tech, tenant engineer, or escort who is not on the cage's authorized-occupant list must not enter it.

A facility tech, tenant engineer, or escort may enter a cage only when an escort is physically present.

A facility tech, tenant engineer, or escort must not enter a cage when no escort is physically present.

A request by a facility tech to enter a cage that does not trip any prohibition above must be able to succeed.
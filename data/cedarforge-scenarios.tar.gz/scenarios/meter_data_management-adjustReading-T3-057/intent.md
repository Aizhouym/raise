# Meter Data Adjustment Review

## Natural-Language Scenario

The system manages meter data adjustments and billing runs for utility accounts.

The people involved are meter readers, billing analysts, billing managers, data stewards, and auditors. One person may hold both the meter reader and data steward roles, or both the billing analyst and meter reader roles.

The resources are billing runs and meter accounts. Every billing run records its account, preparer, approver, bill amount, usage, rate, rate class, region, account tier, status, and when it was prepared.

Every meter account records its account holder, who last read it, tier, adjustment count, last bill amount, rate class, region, status, and when it was last read.

Each request carries the current time, whether it is from the corporate network, and whether an emergency has been declared.

A meter reader or data steward may adjust a reading only while the account is under review when the account's most recent bill amount crosses the money threshold and the rate class is regulated.

For accounts whose most recent bill amount does not cross the money threshold, the under-review requirement does not bind this adjustment.

For accounts whose rate class is not regulated, the under-review requirement does not bind this adjustment.

Neither a meter reader nor a data steward may adjust a reading for a regulated account above the money threshold when the account is not under review.

A request by a meter reader to adjust a reading that does not trip any requirement above must be able to succeed.
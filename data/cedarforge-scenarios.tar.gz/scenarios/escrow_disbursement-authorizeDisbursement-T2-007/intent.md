# Escrow Fund Disbursement — Authority Rule Within the Officer's Region

## Natural-Language Scenario

The system manages clear-to-close approval and fund disbursement for real-estate escrow files.

The people involved are escrow officers, senior escrow officers, escrow managers, title officers, and auditors. One person may hold both the escrow officer and senior escrow officer roles at the same time, or both the senior escrow officer and escrow manager roles at the same time.

The resources are escrow files and disbursements. Every escrow file records its escrow officer, its disbursement tier, the amount held, the number of payees, its file code, its region, its parties, its lien status, whether its title has been cleared, its status, and its closing date. Every disbursement records its escrow file, who authorized it, its amount, and when it was wired.

Each request carries the current time, whether it comes from the corporate network, whether dual control has been confirmed, and whether a settlement emergency has been declared.

An escrow officer may open an escrow file, and a title officer or an escrow manager may approve a file clear to close before its funds are disbursed.

A senior escrow officer or an escrow manager may authorize a disbursement only when their granted authority level is at least as high as the file's disbursement tier, while a request to authorize a disbursement for a file whose tier sits above the officer's granted authority must be refused.

A senior escrow officer or an escrow manager may authorize a disbursement only when the file falls within their own regional hierarchy, while a request to authorize a disbursement for a file that lies outside the officer's region must be refused.

A title officer or an auditor must not authorize a disbursement, and an auditor may only view the audit log.

A request by a senior escrow officer to authorize a disbursement that trips none of the prohibitions above must be able to succeed.

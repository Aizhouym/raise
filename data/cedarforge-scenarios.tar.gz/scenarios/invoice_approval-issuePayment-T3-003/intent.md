# Invoice Payment Issuance

## Natural-Language Scenario

The system manages invoice approval and payment issuance for a finance department.

The people involved are clerks, approvers, finance managers, and auditors.

One person may hold both the clerk and the approver role at the same time.

The resources are invoices and payments.

Every invoice records its creator, its approver, its amount, its surcharge, its number of line items, its status, its cost center, and when it was submitted.

Every payment records the invoice it pays, who issued it, and its amount.

Each request carries whether it originates from the corporate network.

A clerk may create an invoice and submit it for approval.

An approver may approve a submitted invoice.

A finance manager who approved an invoice may not issue its payment when the payment amount is over $25,000.

For payments of $25,000 or less, the finance manager who approved the invoice may also issue its payment.

A finance manager who approved an invoice may not issue its payment when the request is made from the corporate network.

When the request does not come from the corporate network, the finance manager who approved the invoice may issue its payment.

An auditor may view the audit log.

A request by a finance manager who did not approve the invoice to issue its payment must be able to succeed.

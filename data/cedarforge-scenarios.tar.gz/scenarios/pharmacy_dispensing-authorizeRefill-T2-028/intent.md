# Outpatient Controlled-Substance Refills

## Natural-Language Scenario

The system manages controlled-substance prescriptions, dispensing, and refill authorization in an outpatient pharmacy.

The people involved are pharmacy technicians, staff pharmacists, the pharmacist in charge, and prescribers. One person may hold both the staff pharmacist and pharmacist in charge role at the same time.

The resources are prescriptions and dispense records. Every prescription records its prescriber, patient, entered by, verified by, prescriber DEA, schedule level, refills remaining, and status.

Every dispense record records its prescription, who dispensed it, the quantity, and the copay amount.

Each requester carries dispense authority and a state license.

Each request carries whether the PDMP was checked, whether MFA was used, whether the request came from the pharmacy network, the current time, and whether an emergency override was used.

The pharmacist in charge who authorizes a refill must be the same pharmacist who verified the prescription.

A pharmacist in charge who did not verify the prescription must not authorize its refill.

A refill may be authorized only after the prescription has been dispensed.

Before the prescription has been dispensed, the pharmacist in charge must not authorize its refill.

A request by a pharmacist in charge to authorize a refill that does not trip any prohibition above must be able to succeed.
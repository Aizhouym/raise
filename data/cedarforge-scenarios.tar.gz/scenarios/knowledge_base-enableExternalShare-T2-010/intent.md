# Internal Wiki External Sharing

## Natural-Language Scenario

The system manages external sharing for pages in an internal wiki knowledge base.

The people involved are contributors, reviewers, space admins, and readers. One person may hold both the contributor and reviewer role at the same time.

The resources are pages and spaces. Every page records its author, reviewer, space, classification, whether external sharing is enabled, its labels, and its status.

Each requester carries their clearance and the spaces they belong to.

Each request carries whether it is on the corporate network, the current time, and whether emergency access is being used.

A space admin may enable external sharing for a page only when the page is published and carries the external-share flag.

A space admin must not enable external sharing for an unpublished page that carries the external-share flag.

For a page without the external-share flag, the published-page requirement does not apply.

A request by a space admin to enable an external share that does not trip any prohibition above must be able to succeed.
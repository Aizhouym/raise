# Order Picking then Zone Access — Requester Independence, Controlled SKU, Badge-In, Clearance, and Zone Group

## Natural-Language Scenario

The system manages the picking of warehouse orders and access to the zones they are destined for.

The people involved are pickers, forklift operators, zone supervisors, warehouse managers, and security officers. One person may hold both the picker and the forklift operator role at the same time.

The resources are orders and zones. Every order records who requested it, its picker, its items, its item count, its pick-list code, its status, its destination zone, and when it was released. Every zone records its zone code, its sensitivity, its zone group, whether it is locked, and its operational status.

Each request carries the current time, whether the associate has badged in on site, and whether an emergency has been declared.

In this workflow an order is first picked and then its destination zone is accessed, and the zone-access step can see the order's status, its destination zone, and who picked it as recorded by the picking step.

A picker or a forklift operator may pick an order, but the associate who requested it may not pick it themselves, and an associate who did not request it may pick it.

An order may be picked only when its item set includes a controlled or hazardous SKU, and an order with no such SKU is not picked under this rule.

An order may be picked only when the picker has badged in on site for this shift, and a picker who has not badged in may not pick it.

A picker, a forklift operator, or a zone supervisor may access a zone only when their badge clearance is high enough for the zone's sensitivity, and an associate whose clearance falls short may not enter it.

A zone may be accessed only when it belongs to a zone group the associate is assigned to, and a zone outside the associate's assigned zone groups may not be entered.

A zone may be accessed only when the associate has badged in on site, and an associate who has not badged in may not enter it.

Neither a picker nor a forklift operator who requested an order may pick it themselves.

A run through the workflow begun by a picker, badged in on site, who did not request an order that carries a controlled SKU, picking it and then accessing its destination zone within an assigned zone group, tripping no prohibition above, must be able to succeed.

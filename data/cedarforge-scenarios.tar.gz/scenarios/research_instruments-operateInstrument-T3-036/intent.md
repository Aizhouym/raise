# Research Facility Instruments

## Natural-Language Scenario

The system manages access to research facility labs and instruments.

The people involved are technicians, supervisors, safety officers, and visitors. One person may hold both the supervisor and technician role at the same time.

The resources are instruments, samples, and access badges. Every instrument records its hazard class, whether it is under maintenance, and its status.

Every sample records who opened it and its status.

Every access badge records its holder and when it expires.

Each requester carries certifications, and each request carries the local time, whether the requester is on site, and whether a supervisor is present.

A technician or supervisor may operate an instrument.

Neither a technician nor a supervisor may operate an instrument that is faulted when the badge is valid and the request is within staffed hours, unless the requester is physically on site.

When the badge is not valid or the request is outside staffed hours, the faulted-instrument rule does not block operation.

When the requester is physically on site, the faulted-instrument rule does not block operation.

A request by a technician to operate an instrument that does not trip any prohibition above must be able to succeed.
# Grant Award Approval and Fund Obligation

## Natural-Language Scenario

This document describes the access rules for a federal grant award management system.
The people involved are reviewers, program officers, grants officers, and applicants, and a single person may act as both reviewer and program officer, or as both program officer and grants officer, at the same time.
The resources are applications, each recording its applicant, its assigned reviewers, its funding tier, its requested amount, its program code, and its status, and awards, each recording its application, who approved it, who obligated it, its amount, whether it is high risk, and its status.
Each requester carries a list of conflicted applications and an approval authority, and each request carries the current time, whether it is on the government network, and whether an emergency has been declared.
In this workflow an award is first approved and then its funds are obligated on the same award record, and the obligation step can see the award's status and who approved it earlier.
When an award is approved, the officer's approval authority must be at least as high as the application's funding tier, and an officer whose approval authority is below the application's funding tier may not approve the award.
Approval is allowed only when the person requesting is the applicant on the application, and anyone who is not the applicant may not approve the award.
The officer who approved an award may not obligate its funds, and a grants officer who did not approve the award may obligate its funds.
The program officer or grants officer who approved an award must not obligate its funds.
A run through the workflow by a program officer that trips none of the prohibitions above must be able to succeed.

# Smart-Building Commission Approval

## Natural-Language Scenario

The system manages smart-building automation and zone control.

The people involved are facility managers, zone controllers, maintenance techs, and tenants. One person may hold both the facility manager and zone controller roles at the same time.

The resources are actuators, zones, and commission requests. Every actuator records its owner, zone group, device tags, maintenance flag, and status.

Every zone records its controller, criticality, and status.

Every commission request records its device, who requested it, and its status.

Each request carries the current time, whether occupancy is detected, whether it is on the site network, and whether there is a maintenance override.

A facility manager may approve a commission request only while it is in the requested stage when the requester holds the required role.

When the requester does not hold the required role, the requested-stage limit does not bind this approval rule.

When the approval request falls within a permitted window, the requested-stage limit does not bind this approval rule.

Outside a permitted window, a facility manager must not approve a commission request unless it is in the requested stage and the requester holds the required role.

A request by a facility manager to approve a commission that does not trip any prohibition above must be able to succeed.
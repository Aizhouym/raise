# Immigration Case Adjudication

## Natural-Language Scenario

The system manages immigration case adjudication and applicant records.

The people involved are adjudication officers, supervisory officers, background investigators, and records clerks. One person may hold both the adjudication officer and background investigator roles, or both the supervisory officer and adjudication officer roles, at the same time.

The resources are cases, security checks, and applicant records. Every case records its applicant, assigned officer, case team, field office, and status.

Every security check records its case, investigator, and status.

Every applicant record records its applicant, assigned officer, need-to-know team, data sensitivity, and status.

Each requester carries their clearance and recused cases, and each request carries whether it comes from the government network, the current time, and supervisor approval.

An adjudication officer, supervisory officer, or background investigator may view applicant data only when the request comes from the government network.

An adjudication officer, supervisory officer, or background investigator must not view applicant data from outside the government network.

An adjudication officer, supervisory officer, or background investigator whose clearance is lower than an applicant record's data sensitivity must not view that applicant data unless they are the officer assigned to the record.

An adjudication officer, supervisory officer, or background investigator who is assigned to an applicant record may view that applicant data even when their clearance is lower than the record's data sensitivity, provided the request comes from the government network.

A request by an adjudication officer to view applicant data that does not trip any prohibition above must be able to succeed.
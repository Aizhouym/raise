# Warehouse Zone Access

## Natural-Language Scenario

The system manages warehouse zone access and order picking.

The people involved are pickers, forklift operators, zone supervisors, warehouse managers, and security officers. One person may hold both the picker and the forklift operator role at the same time.

The resources are orders and zones. Every order records who requested it, its picker, its items, its item count, its pick list code, its status, its destination zone, and when it was released.

Every zone records its zone code, sensitivity, zone group, whether it is locked, and its operational status.

Each request carries the current time, whether the requester has an on-site badge, and whether an emergency has been declared.

Pickers, forklift operators, and zone supervisors may access zones in this scenario.

A zone may be entered only while it is in the open operational state.

A picker, forklift operator, and zone supervisor must not access a zone while its operational state is anything other than open.

A request by a picker to access an open zone that does not trip any prohibition above must be able to succeed.
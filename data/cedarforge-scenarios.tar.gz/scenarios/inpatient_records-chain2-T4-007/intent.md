# Prescription Writing then Countersignature — Self-Prescribing and Continuity

## Natural-Language Scenario

The system manages prescription writing and countersignature for inpatient records.

The people involved are attending physicians, residents, nurses, and pharmacists. One person may hold both the attending-physician and pharmacist roles at the same time, and one person may hold both the resident and pharmacist roles at the same time.

The resources are medical records, prescriptions, and lab orders. Every prescription records its patient, its prescriber, and its status, and every medical record records its patient, its care team, its ward, its sensitivity, and its status.

Each request carries the current shift, whether an emergency was declared, and whether multi-factor authentication was used.

In this workflow a prescription is first written and then it is countersigned, and the countersignature step can see the prescription's status and who prescribed it as recorded by the writing step.

A physician may not write a prescription for themselves, and a physician may write a prescription for a patient who is not themselves.

The physician who prescribed must be the one who countersigns it, and a physician who did not prescribe it may not countersign it.

That continuity requirement is waived when the prescription is in the designated lifecycle stage, so another physician may countersign it in that stage.

That continuity requirement is also waived when multi-factor authentication was used, so another physician may countersign it in that case.

An attending physician must not write a prescription for themselves.

A run through the workflow by an attending physician who writes a prescription for another patient and then countersigns it themselves, tripping no prohibition above, must be able to succeed.

# Payroll Approval — Status Gate, Role Restriction, and VPN Requirement

## Natural-Language Scenario

The system manages personnel records and payroll processing for a company's human resources department.

The people involved are employees, managers, HR specialists, and payroll admins. One person may hold both the manager and employee roles at the same time.

The resources are payroll runs, employee records, and leave requests. Every payroll run records who prepared it, who approved it, its amount, and its status.

Each request carries whether it is made over the corporate VPN and the time it is made.

A manager or a payroll admin may approve a payroll run.

A payroll run may be approved only after it has reached submitted status.

Neither a manager nor a payroll admin may approve a payroll run that is still in an earlier status such as draft.

Approval may proceed only when the requester holds the manager role or the payroll admin role.

An employee or an HR specialist who holds neither of those roles must not approve a payroll run.

Approval may proceed only when the request is made over the corporate VPN.

A request to approve payroll that is not made over the corporate VPN must not be permitted to succeed.

A request by a manager, made over the corporate VPN, to approve a payroll run that has already reached submitted status must be able to succeed.

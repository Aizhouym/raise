# Streaming Content Moderation

## Natural-Language Scenario

The system manages content publishing and moderation for a streaming platform.

The people involved are subscribers, moderators, editors, and admins. One person may hold both the editor and moderator role at the same time.

The resources are content and reports. Every content item records its publisher, required tier, embargo time, allowed regions, labels, and status.

Each requester carries a subscription tier and region, and each request carries the current time and whether the device is trusted.

The actions are watching content, publishing content, moderating content, and removing content.

A moderator may moderate content.

A moderator must not moderate content they published unless they also hold the role named for this exception.

A moderator who holds the exception role may moderate content they published.

A request by a moderator to moderate content they did not publish, or that otherwise does not trip any prohibition above, must be able to succeed.
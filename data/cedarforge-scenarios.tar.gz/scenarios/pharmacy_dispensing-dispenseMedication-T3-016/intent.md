# Controlled-Substance Dispensing

## Natural-Language Scenario

The system manages outpatient dispensing of controlled-substance prescriptions.

The people involved are pharmacy technicians, staff pharmacists, the pharmacist in charge, and prescribers. One person may hold both the staff pharmacist and pharmacist in charge roles at the same time.

The resources are prescriptions and dispense records. Every prescription records its prescriber, patient, enterer, verifier, prescriber DEA, schedule level, refills remaining, and status.

Each requester carries their dispense authority and state license.

Each request carries whether the PDMP was checked, whether MFA was used, whether the request came from the pharmacy network, the current time, and whether an emergency override was used.

A pharmacist's dispense authority must be high enough for the prescription's DEA schedule level before dispensing medication.

A staff pharmacist or pharmacist in charge must not dispense medication when their dispense authority is lower than the prescription's DEA schedule level.

A prescription may be dispensed only after it has been verified.

A staff pharmacist or pharmacist in charge must not dispense medication for an unverified prescription.

Medication may be dispensed only when the request comes from the pharmacy network.

When the request does not come from the pharmacy network, neither a staff pharmacist nor the pharmacist in charge may dispense the medication.

A request by a staff pharmacist to dispense a medication that does not trip any prohibition above must be able to succeed.
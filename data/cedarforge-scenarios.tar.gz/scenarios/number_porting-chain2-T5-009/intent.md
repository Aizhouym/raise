# Number Porting — Port-Freeze Override of Separation and Binding of Duty

## Natural-Language Scenario

The system manages the authorization and cutover of carrier number-portability requests, which move a subscriber's phone number from one carrier to another.

The people involved are porting specialists, porting supervisors, fraud reviewers, line technicians, and auditors. One person may hold both the porting specialist and fraud reviewer roles at the same time, and one person may hold both the line technician and porting specialist roles at the same time.

The resources are port requests and port completions. Every port request records who initiated it, who authorized it, the technician assigned to it, its account numbers, the size of its number block, its carrier code, its port type, its subscriber region, its status, and when it was requested. Every port completion records the request it belongs to, who completed it, and when the port was carried out.

Each request carries the current time, whether it comes in over the carrier operations network, whether a port-freeze override has been declared, and whether a regulator escalation flag is present.

In this workflow a port request is first authorized and then its cutover is completed, and the completion step can see the request's status, who initiated it, and which technician was assigned as recorded by the earlier steps.

A porting specialist who submitted a port request may not authorize that same request, while a porting specialist or porting supervisor who did not submit it may authorize it.

The technician assigned to a port request must be the one who executes its cutover, and the cutover may proceed only when it falls within the scheduled porting window, so outside the scheduled window the port may not be completed, and a line technician or porting supervisor who is not the assigned technician may not complete it within the window either.

When a port-freeze override has been declared, that override wins over the separation-of-duty rule, and a porting supervisor may authorize a request they themselves submitted.

When a port-freeze override has been declared, that override also wins over the binding-of-duty rule, and a porting supervisor may complete the cutover in place of the assigned technician.

A run through the workflow by a porting specialist who authorizes a port request they did not submit, followed by the assigned technician completing its cutover within the scheduled window, tripping no prohibition above, must be able to succeed.

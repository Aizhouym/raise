# Approving a datacenter work order and performing its maintenance with network and zone limits

## Natural-Language Scenario

This document describes how a datacenter cage work order is approved and then carried out.
The people involved are facility techs, tenant engineers, security ops staff, and escorts, and one person may serve as both a facility tech and an escort at the same time.
The resources are cages, which note the tenant, the zone clearance, the occupant list, the site zone, whether an escort is required, and the status; work orders, which note the cage, who raised them, who approved them, and the status; and access badges, which note the holder and when they expire.
Each request carries the current time, whether an escort is present, the maintenance window, and whether it is on the on-site network.
A work order is first approved and then its maintenance is performed on the same record, and the maintenance step can see the work order's status, who raised it, and who approved it.
A work order may be approved only while it is open, and a work order that is not open may not be approved.
A work order may be approved only when the request comes from the on-site management network, and a request from off that network may not approve it.
A work order may be approved only when the approver belongs under the cage's site zone, and someone outside that site zone may not approve it.
Maintenance may be performed only after the work order has been approved, and maintenance may not be performed on a work order that is not yet approved.
A tenant engineer must not approve a work order, since approving is reserved for security ops staff.
A run through the workflow by a security ops staff member that trips none of the prohibitions above must be able to succeed.

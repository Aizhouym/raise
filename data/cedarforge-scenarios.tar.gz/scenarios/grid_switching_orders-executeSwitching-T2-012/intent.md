# Grid Switching Execution — Separation from the Authorizer

## Natural-Language Scenario

The system manages the field execution of grid switching orders.

The people involved are planners, shift supervisors, operators, control room operators, and auditors. One person may hold both the planner and the shift supervisor role at the same time, and one person may hold both the operator and the control room operator role at the same time.

The resources are switching orders and lockout tags. Every switching order records its planner, the operator designated to execute it, its feeder, its voltage level, its circuit count, its status, its scheduled start, and its scheduled end. Every lockout tag records its order, who applied it, and its feeder.

Each request carries the current time, whether it is on the control network, whether lockout-tagout has been verified, and whether an outage emergency has been declared.

An operator or a control room operator may execute a switching order in the field, but the planner who authorized that order may not be the one who executes it.

This separation is set aside only when the number of circuits switched crosses the threshold that requires a control room operator, in which case a control room operator carries out the execution; for orders below that circuit threshold the planner who authorized the order still may not execute it.

Neither an operator nor a control room operator who authorized an order as its planner may execute that order below the circuit threshold.

A request by an operator, who did not authorize the order, to execute a switching order that trips none of the prohibitions above must be able to succeed.

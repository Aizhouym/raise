# Number Porting — Region- and Network-Scoped Self-Authorization Bar

## Natural-Language Scenario

The system manages the authorization and cutover of carrier number-portability requests, which move a subscriber's phone number from one carrier to another.

The people involved are porting specialists, porting supervisors, fraud reviewers, line technicians, and auditors. One person may hold both the porting specialist and fraud reviewer roles at the same time, and one person may hold both the line technician and porting specialist roles at the same time.

The resources are port requests and port completions. Every port request records who initiated it, who authorized it, the technician assigned to it, its account numbers, the size of its number block, its carrier code, its port type, its subscriber region, its status, and when it was requested. Every port completion records the request it belongs to, who completed it, and when the port was carried out.

Each request carries the current time, whether it comes in over the carrier operations network, whether a port-freeze override has been declared, and whether a regulator escalation flag is present.

In this workflow a port request is first authorized and then its cutover is completed, and the completion step can see the request's status, who initiated it, and which technician was assigned as recorded by the earlier steps.

A porting specialist who submitted a port request may not authorize that same request, but this bar applies only when the subscriber's region falls within the specialist's assigned region hierarchy, so when the subscriber's region lies outside the specialist's assigned regions the submitting specialist is not barred on that ground.

The bar on self-authorization also applies only when the request comes in over the carrier operations network, so when the request does not arrive over the carrier operations network the submitting specialist is not barred on that ground either.

The technician assigned to a port request must be the one who executes its cutover, and a line technician or porting supervisor who is not the assigned technician may not complete the port.

An auditor may view the audit log.

A run through the workflow by a porting specialist who authorizes a port request they did not submit, followed by the assigned technician completing its cutover, tripping no prohibition above, must be able to succeed.

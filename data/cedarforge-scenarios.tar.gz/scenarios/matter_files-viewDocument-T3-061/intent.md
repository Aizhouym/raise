# Law-Firm Matter File Viewing

## Natural-Language Scenario

The system manages matter files and document access in a law firm.

The people involved are attorneys, paralegals, records managers, and clients. One person may hold both the attorney and the paralegal role at the same time.

The resources are matters and documents. Every matter records its lead attorney, team, client, legal hold, and status.

Every document records its matter, author, privileged status, and status.

Each requester carries the matters they are conflicted from, and each request carries the current date and the retention expiry.

An attorney may not view a document for a matter they are conflicted from when the requester is acting as an attorney and the request is outside the permitted window.

Within the permitted window, an attorney conflicted from the matter may view the document.

When the requester is not acting as an attorney, the attorney-conflict restriction does not block the viewing request.

An attorney, including one who also serves as a paralegal, must not view a document for a conflicted matter outside the permitted window.

A request by an attorney to view a document that does not trip any prohibition above must be able to succeed.
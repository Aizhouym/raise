# Patent Application Access

## Natural-Language Scenario

The system manages access to patent prosecution docket materials.

The people involved are patent attorneys, docket clerks, examiners, and inventors.

One person may hold both the patent attorney and docket clerk roles, and one person may hold both the examiner and inventor roles.

The resources are patent applications, office actions, and filings.

Every patent application records its inventor, prosecuting attorney, assigned examiner, team, confidentiality level, bar date, and status.

Every office action records its application, author, and status.

Every filing records its application, who filed it, and its status.

Each requester carries a clearance level.

Each request carries the current date, whether it is made on the firm network, whether there is a court order, and whether multifactor authentication was used.

A patent attorney, docket clerk, or examiner may access a patent application only when the requester’s clearance is high enough for the application’s confidentiality level.

When the request falls within a permitted window, the clearance requirement is relaxed.

A patent attorney, docket clerk, or examiner whose clearance is not high enough and whose request is not within a permitted window must not access the application.

A request by a patent attorney to access an application that does not trip any prohibition above must be able to succeed.
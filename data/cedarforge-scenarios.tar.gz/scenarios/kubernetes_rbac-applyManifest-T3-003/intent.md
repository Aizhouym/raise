# Kubernetes Manifest Deployment — Two-Person Control and Namespace Membership

## Natural-Language Scenario

This system manages Kubernetes namespace role-based access control for a cloud platform.
The people involved are deployers, maintainers, cluster operators, and service accounts, and one person may hold both the deployer and maintainer roles at the same time.
The resources are namespaces, workloads, namespace secrets, and service account tokens.
Every namespace records its members, its team group, and its environment.
Every workload records its namespace, its creator, the verb it requires, its replica count, its labels, and its environment.
Every namespace secret records its namespace, its owner, its sensitivity, and its status.
Every service account token records its subject, its bound namespace, who issued it, when it expires, and its status.
Each requester carries a clearance level, a granted scope, and a record of the groups they belong to.
Each request carries the source IP address, the current time, whether it is an emergency change, and whether multi-factor authentication was used.
A deployer, maintainer, or cluster operator must not apply a manifest that they themselves authored.
A deployer, maintainer, or cluster operator may apply a manifest only when they are a member of the workload's namespace.
A deployer, maintainer, or cluster operator who is not a member of the workload's namespace must not be allowed to apply it.
A deployer, maintainer, or cluster operator may apply a manifest only when they belong under the namespace's team group.
A deployer, maintainer, or cluster operator who does not belong under the namespace's team group must not be allowed to apply it.
A request by a deployer who did not author the manifest, who is a member of the workload's namespace, and who belongs under the namespace's team group to apply the manifest must be able to succeed.

# Switching Authorization then Execution — Separation, then Sequence

## Natural-Language Scenario

The system manages the authorization of grid switching orders and their execution in the field.

The people involved are planners, shift supervisors, operators, control-room operators, and auditors.

One person may hold both the planner and shift supervisor roles, or both the operator and control-room operator roles, at the same time.

The resources are switching orders and lockout tags.

Every switching order records its planner, its designated executor, its feeder, its voltage level, its circuit count, its status, its scheduled start, and its scheduled end.

Every lockout tag records its order, who applied it, and its feeder.

Each request records the current time.

In this workflow a switching order is first authorized and then executed, and the execution step can see the order's status and who authorized it as recorded by the authorization step.

The operator designated to execute a switching order may not be the one who authorizes it, unless the request falls within the order's scheduled switching window, between its scheduled start and scheduled end, in which case the designated executor may authorize it.

Neither a planner nor a shift supervisor may authorize a switching order they are designated to execute, except when the request falls within the order's scheduled switching window.

A switching order may be executed only after it has been authorized, and neither an operator nor a control-room operator may execute an order that has not been authorized.

A run through the workflow by a planner who authorizes an order they are not designated to execute, which is then executed, tripping no prohibition above, must be able to succeed.

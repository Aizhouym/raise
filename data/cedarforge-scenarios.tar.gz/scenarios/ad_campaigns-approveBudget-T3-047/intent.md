# Campaign Budget Approval

## Natural-Language Scenario

The system manages advertising campaigns, creatives, and launch preparation.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors. One person may hold both the account manager and the campaign director role at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, who prepared it, its budget, its contingency, its budget tier, its risk labels, its scheduled start, and its status.

Each request carries the current time, whether MFA was used, whether the device is trusted, and whether the launch is an emergency launch.

When a campaign's budget plus contingency crosses the approval threshold, a campaign director or account manager may approve the budget only while the campaign is in review.

When a campaign's budget plus contingency does not cross the approval threshold, the review-status requirement does not block budget approval.

When MFA was used, the review-status requirement does not block budget approval.

A campaign director or account manager must not approve a budget for a campaign that crosses the approval threshold, is not in review, and was requested without MFA.

A request by a campaign director to approve a budget that does not trip any prohibition above must be able to succeed.
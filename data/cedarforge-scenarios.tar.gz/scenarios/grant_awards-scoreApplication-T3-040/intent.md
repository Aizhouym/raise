# Federal Grant Award Scoring

## Natural-Language Scenario

The system manages federal grant applications and award decisions.

The people involved are reviewers, program officers, grants officers, and applicants. One person may hold both reviewer and program officer roles, or both program officer and grants officer roles.

The resources are applications and awards. Every application records its applicant, assigned reviewers, funding tier, requested amount, program code, and status.

Every award records its application, who approved it, who obligated it, its amount, its high risk flag, and its status.

Each requester carries a list of conflicted applications and their approval authority.

Each request carries the current time, whether it comes from the government network, and whether an emergency has been declared.

A reviewer conflicted out of an application may not score it when the requested amount crosses the money limit and the request falls within the review period.

When the requested amount does not cross the money limit, the conflict rule does not block the reviewer from scoring the application.

When the request falls outside the review period, the conflict rule does not block the reviewer from scoring the application.

A reviewer must not score an application they are conflicted out of when both the money limit and review-period conditions are met.

A request by a reviewer to score an application that does not trip any prohibition above must be able to succeed.
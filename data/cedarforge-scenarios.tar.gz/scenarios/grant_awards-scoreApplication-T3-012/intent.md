# Federal Grant Award Scoring

## Natural-Language Scenario

The system manages federal grant applications, award approval, and fund obligation.

The people involved are reviewers, program officers, grants officers, and applicants. One person may hold both the reviewer and program officer roles at the same time, and one person may hold both the program officer and grants officer roles at the same time.

The resources are applications and awards. Every application records its applicant, assigned reviewers, funding tier, requested amount, program code, and status.

Every award records its application, who approved it, who obligated it, its amount, its high risk flag, and its status.

Each requester carries the applications they are conflicted out of and their approval authority.

A reviewer may not score an application when the reviewer is conflicted out of it and is also the applicant.

A reviewer who is conflicted out but is not the applicant is not blocked by this self-applicant restriction.

A reviewer who is the applicant is not blocked by this restriction when they hold the specified exception role.

A reviewer who is conflicted out of an application and is the applicant must not score it unless they hold the specified exception role.

A request by a reviewer to score an application that does not trip any prohibition above must be able to succeed.
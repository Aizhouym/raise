# Shipment Dispatch

## Natural-Language Scenario

The system manages carrier shipment dispatch and delivery confirmation.

The people involved are planners, drivers, dispatch managers, depot supervisors, and auditors. One person may hold both the planner and the dispatch manager role at the same time.

The resources are shipments and delivery receipts. Every shipment records its planner, driver of record, piece count, gross weight in kilograms, status, tracking code, origin depot, hazmat class, and delivery window end, and every delivery receipt records its shipment, recipient, and signed-at time.

Each request carries the current time, whether it is on the depot network, whether expedite handling was declared, and proof of delivery.

A driver or dispatch manager may dispatch a shipment only after it has reached the created state when the request is not on the origin depot network and the tracking code does not carry the assigned carrier prefix.

When the request is on the origin depot network, the created-state requirement does not block dispatch.

When the tracking code carries the assigned carrier prefix, the created-state requirement does not block dispatch.

Neither a driver nor a dispatch manager may dispatch a shipment before it reaches the created state when the request is not on the origin depot network and the tracking code does not carry the assigned carrier prefix.

A request by a driver to dispatch a shipment that does not trip any prohibition above must be able to succeed.
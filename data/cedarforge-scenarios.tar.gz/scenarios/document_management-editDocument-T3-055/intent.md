# Document Editing

## Natural-Language Scenario

The system manages enterprise documents and their editing workflow.

The people involved are authors, editors, viewers, and compliance officers. One person may hold both the author and the editor role at the same time.

The resources are documents and workspaces. Every document records its owner, share list, classification, version lock state, labels, and status.

Each requester carries a clearance, and each request carries whether it is on the corporate network and the current time.

An author or editor who owns a document may edit it only while it is in draft status.

An author or editor who owns a document may edit it outside draft status when the document carries the specified label.

For a document not owned by the requester, the draft-only editing rule does not apply.

An author must not edit a document they own when it is not in draft status and does not carry the specified label.

An editor must not edit a document they own when it is not in draft status and does not carry the specified label.

A request by an author to edit a document that does not trip any prohibition above must be able to succeed.
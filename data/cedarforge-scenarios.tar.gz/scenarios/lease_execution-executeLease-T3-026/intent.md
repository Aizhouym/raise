# Brokerage Lease Execution

## Natural-Language Scenario

The system manages brokerage lease review and execution.

The people involved are leasing agents, transaction coordinators, brokers, compliance officers, and auditors. One person may hold both the leasing agent and transaction coordinator roles, or both the broker and compliance officer roles, at the same time.

The resources are leases and executed leases. Every lease records its listing agent, reviewer, lease code, monthly rent, term months, square footage, region, premises class, contingencies, segment, fair housing hold, status, and sign window end.

Each request carries the current time, whether it comes from the brokerage network, whether the counterparty's identity has been verified, and whether a court order has been declared.

A broker or compliance officer may execute a lease only after it has reached the signed state.

A broker or compliance officer may execute a lease before it has reached the signed state when the lease code matches or carries a controlled-template prefix.

A broker or compliance officer may execute a lease before it has reached the signed state when the counterparty's identity has been verified for the request.

Neither a broker nor a compliance officer may execute a lease before it has reached the signed state unless the lease code matches or carries a controlled-template prefix or the counterparty's identity has been verified for the request.

A request by a broker to execute a lease that does not trip any prohibition above must be able to succeed.
# Patent Response Filing — Attorney of Record and Docket Team Gate

## Natural-Language Scenario

The system manages the filing docket for patent prosecution at a law firm.

The people involved are patent attorneys, docket clerks, examiners, and inventors. One person may hold both the patent attorney and docket clerk roles at the same time, and one person may hold both the examiner and inventor roles at the same time.

The resources are patent applications, office actions, and filings. Every patent application records its inventor, its prosecuting attorney of record, its assigned examiner, its docket team, its confidentiality level, its bar date, and its status. Every office action records the application it concerns, its author, and its status. Every filing records the application it belongs to, who filed it, and its status.

Each request carries the current date, whether it was made from the firm's network, whether a court order accompanies it, and whether multi-factor authentication was used.

Only the patent attorney who is the prosecuting attorney of record for a patent application may file a response to it.

A patent attorney must not file a response to an application for which someone else is the prosecuting attorney of record.

A response may be filed only while the filing is still in draft status.

A patent attorney may file a response only when they are a member of the application's docket team.

A patent attorney who is not on the application's docket team must not file a response to it, unless multi-factor authentication was used for the request.

When multi-factor authentication was used, a patent attorney who is not on the docket team may still file the response.

A request by the prosecuting attorney of record, who is a member of the docket team, to file a response to a draft filing must be able to succeed.

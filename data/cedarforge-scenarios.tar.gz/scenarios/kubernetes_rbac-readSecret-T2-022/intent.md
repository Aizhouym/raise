# Kubernetes Namespace RBAC

## Natural-Language Scenario

The system manages access to Kubernetes namespace secrets.

The people involved are deployers, maintainers, cluster operators, and service accounts. One person may hold both the deployer and maintainer roles at the same time.

The resources are namespaces, workloads, namespace secrets, and service account tokens. Every namespace secret records its namespace, owner, sensitivity, and status.

A namespace secret may be read only while it is active when the requester does not own it.

A requester who owns a namespace secret may read it even when it is rotating or revoked.

A deployer, maintainer, cluster operator, and service account must not read a namespace secret they do not own while it is rotating or revoked.

A request by a deployer to read a namespace secret that does not trip any prohibition above must be able to succeed.
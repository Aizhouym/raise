# Streaming Content Tier Access with Region, Status, and Label Exceptions

## Natural-Language Scenario

The system controls who may watch content on a streaming media platform.

The people involved are subscribers, moderators, editors, and admins, and one person may hold both the editor and moderator roles at the same time.

The resources are content and reports; every content item records its publisher, its required subscription tier, the date it goes off embargo, the regions where it is allowed, any labels attached to it, and its status, while every report records the content it concerns and the person who filed it.

A subscriber may watch content only when their subscription tier meets that content's required tier.

This tier requirement is waived when the content is licensed in the subscriber's own region, so a subscriber in a region where the content is licensed may watch it even if their tier is below the required level.

When the content is not licensed in the subscriber's region, the subscriber must still meet the tier requirement to watch it.

The tier requirement is also waived for content whose status is published rather than removed, letting any subscriber watch a published title regardless of tier.

For content whose status is removed, this waiver does not apply, and the tier requirement is enforced as normal.

The tier requirement is waived a third way for content carrying a "free preview" label, which any subscriber may watch regardless of their tier.

For content without the "free preview" label, the standard tier requirement applies.

A subscriber whose tier is below the content's required tier must not be able to watch it unless the region, status, or label exception applies.

A request by a subscriber to watch content that does not trip any of these tier prohibitions must be able to succeed.

# Cloud Resource Modification — Production Restriction and Break-Glass Override

## Natural-Language Scenario

The system manages access to cloud infrastructure resources within an organization.

The people involved are owners, developers, operators, and org admins.

One person may hold both the owner and developer role at the same time.

The resources are cloud resources, secrets, and org units.

Every cloud resource records its owner, its org unit, its tags, its environment, and any temporary grant placed on it.

Every secret records the cloud resource it belongs to and when it was last rotated.

Every org unit records its parent org unit.

An owner, a developer, or an operator may modify a cloud resource only when its environment is not production.

When a cloud resource has been promoted for production changes, an owner, a developer, or an operator may modify it even while its environment is production.

When a cloud resource carries an active break-glass temporary grant, an owner, a developer, or an operator may modify it in production even if it has not been promoted.

An owner, a developer, or an operator must not modify a cloud resource that is in the production environment, has not been promoted, and does not carry an active temporary grant.

When a cloud resource's temporary grant is active, that grant overrides the production restriction and takes priority over the promotion requirement.

A request by an owner to modify a cloud resource that trips none of these restrictions must be able to succeed.

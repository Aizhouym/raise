# Source-Code Repository Merging

## Natural-Language Scenario

The system manages source-code repositories and pull request merging.

The people involved are developers, reviewers, maintainers, and the security lead. One person may hold both the developer and reviewer role at the same time.

The resources are repositories, pull requests, and branches. Every repository records its owner, team, sensitivity, whether its default branch is protected, its topics, and its status.

Every pull request records its repository, author, approvers, target branch, approval count, lines changed, whether it requires security review, and its status.

Every branch records its name and whether it is protected.

Each requester carries a clearance, and each request carries the current time, whether it is on VPN, and whether break glass was invoked.

A maintainer who authored a pull request may not merge it.

A pull request targeting a branch whose name matches the protected pattern or has the protected prefix, such as release/*, may be merged only after it has been approved.

For pull requests targeting other branch names, the approval requirement does not block the merge.

A maintainer must not merge their own pull request.

A request by a maintainer to merge a pull request that does not trip any prohibition above must be able to succeed.
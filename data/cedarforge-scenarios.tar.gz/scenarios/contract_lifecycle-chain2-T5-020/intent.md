# Contract Review then Signature — Independence and Authority at Value

## Natural-Language Scenario

The system manages the review and signing of contracts through their lifecycle.

The people involved are drafters, reviewers, signatories, and contract admins; one person may hold both the drafter and reviewer roles at the same time, and one person may hold both the reviewer and signatory roles at the same time.

The resources are contracts and signatures; every contract records its drafter, its reviewer, its counterparty, its contract value, its required authority, its effective date, and its status, and every signature records its contract, who signed it, and its amount.

Each requester carries a signing authority and a list of counterparties they are conflicted against, and each request carries the current date, whether it is on the corporate network, whether multi-factor authentication was used, and whether an escalation was approved.

In this workflow a contract is first reviewed and then signed, and the signing step can see the contract's status, its drafter, and its reviewer as recorded by the review step.

The drafter of a contract may not review it, while a reviewer who did not draft it may review it.

This bar on the drafter reviewing applies only when the reviewer is conflicted against the contract's counterparty, and when the reviewer carries no such conflict the bar does not apply.

The bar also applies only when the contract's value crosses the money threshold, and for contracts whose value stays at or below that threshold the drafter is not barred from reviewing.

A signatory or contract admin may sign a contract only when their delegated authority tier reaches the contract's required authority tier, and one whose authority tier falls short may not sign it.

This authority-match requirement applies only when the contract's value crosses the money threshold, and for contracts at or below that threshold the authority match is not required to sign.

A signatory or contract admin whose authority tier falls below the required tier must not sign a contract whose value crosses the money threshold.

A run through the workflow by a reviewer who reviews a contract they did not draft and then, holding an authority tier reaching the contract's required tier, signs it, tripping no prohibition above, must be able to succeed.

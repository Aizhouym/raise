# Student Records and Grades

## Natural-Language Scenario

The system manages student records and grades for a school.

The people involved are instructors, students, parents, and the registrar. One person may hold both the instructor and parent role at the same time.

The resources are student records, grades, and courses. Every student record records the student, the advisor, the student's age, any FERPA block, and its status.

Each request carries the current date and whether it comes from the campus network.

An instructor, student, or parent may not view a withdrawn student's record when the student is under 18.

The registrar may view a withdrawn student's record when the student is under 18.

For withdrawn students who are 18 or older, the under-18 withdrawal restriction does not block viewing.

An instructor may view a student record that is not withdrawn or that otherwise trips no prohibition above.

A student may view their own record when it trips no prohibition above.

A parent may view a student record when it trips no prohibition above.

A request by an instructor to view a record that does not trip any prohibition above must be able to succeed.
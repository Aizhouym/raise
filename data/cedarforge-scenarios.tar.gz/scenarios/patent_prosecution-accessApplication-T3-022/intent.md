# Patent Application Access

## Natural-Language Scenario

The system manages patent prosecution dockets for patent applications.

The people involved are patent attorneys, docket clerks, examiners, and inventors. One person may hold both the patent attorney and docket clerk roles at the same time, and one person may hold both the examiner and inventor roles at the same time.

The resources are patent applications, office actions, and filings. Every patent application records its inventor, prosecuting attorney, assigned examiner, team, confidentiality level, bar date, and status.

Each requester carries a clearance, and each request carries the current date, whether it is on the firm network, whether there is a court disclosure order, and whether MFA was used.

A patent attorney, docket clerk, or examiner may access a patent application only when their clearance is at least as high as the application's confidentiality level.

A patent attorney, docket clerk, or examiner whose clearance is below the application's confidentiality level must not access the application unless a court disclosure order applies.

When a court disclosure order applies, it overrides the confidentiality clearance requirement.

A patent attorney, docket clerk, or examiner may access a patent application only when the requester is the attorney of record for that application.

When the requester is not the attorney of record for the application, that requester must not access it.

When the requester is the attorney of record for the application, the attorney-of-record requirement does not block the request.

A request by a patent attorney to access an application that does not trip any prohibition above must be able to succeed.
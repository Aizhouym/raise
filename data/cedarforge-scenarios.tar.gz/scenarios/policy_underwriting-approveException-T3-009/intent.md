# Underwriting Exception Approval — Accountable Owner, Coverage, and Premium

## Natural-Language Scenario

The system manages insurance policy underwriting and the binding of policies.

The people involved are underwriters, senior underwriters, underwriting managers, chief underwriters, and auditors. One person may hold both the underwriter and senior underwriter roles at the same time.

The resources are applications and policies. Every application records its assigned underwriter, its risk tier, its coverage lines, its market segment, its premium, its product code, its exposure count, its status, and its effective date. Every policy records its application, who bound it, its premium, and its effective date.

A senior underwriter, an underwriting manager, or a chief underwriter may approve an authority exception on an application only when the application's coverage lines include a line that requires escalated exception review; when the coverage includes no such line, there is no exception to approve.

Such an exception may be approved only when the annual premium is above the senior-sign-off threshold; when the premium is at or below that threshold, no senior sign-off is required.

Whoever approves the exception must be the same underwriter assigned to handle that application, keeping one accountable owner across the file.

A senior underwriter, an underwriting manager, or a chief underwriter who is not the underwriter assigned to the application may not approve an exception on it.

A request by a senior underwriter who is the assigned underwriter on an application to approve an exception, tripping none of the prohibitions above, must be able to succeed.

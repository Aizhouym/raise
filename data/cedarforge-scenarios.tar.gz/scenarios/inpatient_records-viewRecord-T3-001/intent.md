# Inpatient Record Access — Clearance, Seniority, and Ward Match

## Natural-Language Scenario

The system manages access to inpatient medical records, prescriptions, and lab orders in a hospital.

The people involved are attending physicians, residents, nurses, and pharmacists.

One person may hold both the attending physician and pharmacist roles at the same time, and one person may hold both the resident and pharmacist roles at the same time.

The resources are medical records, prescriptions, and lab orders.

Every medical record notes the patient it belongs to, the care team assigned to it, the ward it is held on, its sensitivity level, and its status.

Every prescription notes its patient, the prescriber who wrote it, and its status.

Every lab order notes the patient it belongs to.

An attending physician, a resident, or a nurse must not view a medical record whose sensitivity level is higher than their own cleared access level.

A caregiver may view a medical record only when their position sits at or above resident level on the clinical seniority ladder, which runs from nurse up through resident to attending physician.

A nurse, who sits below resident level on that ladder, may not view any medical record, no matter how their clearance or ward line up.

A caregiver may view a medical record only when their assigned ward matches the ward the record is held on.

A caregiver whose assigned ward differs from the record's ward may not view that record, even if their clearance and seniority would otherwise qualify them.

A request by an attending physician whose cleared access level covers the record's sensitivity, whose seniority meets the ladder threshold, and whose assigned ward matches the record's ward must be able to succeed.

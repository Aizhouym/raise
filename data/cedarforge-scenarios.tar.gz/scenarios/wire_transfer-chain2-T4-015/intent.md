# Wire Approval and Release with High-Risk and Network Exceptions

## Natural-Language Scenario

This document sets out the access rules for the bank's wire-transfer authorization system.
The people involved are originators, verifiers, treasury officers, and compliance reviewers, and one person may act as both an originator and a verifier.
The resources are wire transfers, each recording who initiated it, who verified it, who screened it, its account, amount, fee, amount tier, beneficiary, currency code, whether it is high risk, and its status; and accounts, each recording their holder and their allowed beneficiaries.
Each request carries the current time, the daily cutoff, whether it is on the secure banking network, whether multi-factor authentication was used, and whether an emergency has been declared.
A wire is first approved and then released on the same transfer, and the release step can see the wire's status and who initiated, verified, and approved it earlier.
Approving a wire may be performed by a verifier or a treasury officer.
A verifier or treasury officer may approve a wire only if their authority tier is at least as high as the wire's amount tier.
Releasing a wire may be performed by a treasury officer.
When the wire does not carry a high-risk flag and the request is not on the secure banking network, the officer who approved a wire may not release it.
When the wire carries a high-risk flag, or the request is on the secure banking network, the officer who approved the wire may also release it.
A treasury officer who approved a wire must not release it unless the wire carries a high-risk flag or the request is on the secure banking network.
A run through the workflow by a verifier that trips no prohibition above must be able to succeed.

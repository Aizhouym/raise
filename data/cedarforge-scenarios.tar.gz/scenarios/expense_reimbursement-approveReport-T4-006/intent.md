# Expense Report Approval

## Natural-Language Scenario

The system manages the approval of employee expense reports at a company.

The people involved are employees, line managers, finance reviewers, and controllers. One person may hold both the employee and the line manager role at the same time.

The resources are expense reports and reimbursements. Every expense report records its submitter, its approver, its total amount, its meal total, its lodging total, its expense category, the submitter's approval tier, whether a receipt is attached, its status, and when it was submitted. Every reimbursement records the expense report it pays, who disbursed it, and its amount.

Each request carries whether it comes from the corporate network, the current time, and whether it is a declared emergency approval, and each requester carries an approval tier.

A line manager or a finance reviewer may approve an expense report.

A line manager or a finance reviewer who submitted an expense report may not approve that same report when the combined meal and lodging total on the report exceeds the $200 daily per-diem threshold and the expense category is travel or a travel-prefixed category such as TRAVEL-AIRFARE.

When the combined meal and lodging total is $200 or less, or the expense category is not travel or travel-prefixed, the submitter may approve their own report.

If the request carries a declared emergency approval, a finance reviewer may approve an expense report they themselves submitted even though the self-approval prohibition above would otherwise apply.

Absent a declared emergency approval, a finance reviewer who submitted the report may not approve it themselves, just like any other submitter.

Neither a line manager nor a finance reviewer may approve an expense report they submitted themselves unless the declared emergency approval exception above applies.

When a request carries a declared emergency approval, that emergency exception overrides the self-approval prohibition.

A controller may disburse a reimbursement for an approved expense report.

A request by a line manager to approve an expense report that does not trip any of the restrictions above must be able to succeed.

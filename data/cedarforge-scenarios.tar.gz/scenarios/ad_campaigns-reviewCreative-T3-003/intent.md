# Advertising Creative Review — Independence, Status Gate, and Sensitive-Tag Gate

## Natural-Language Scenario

The system manages the review and launch workflow for online advertising campaigns and their creative assets.

The people involved are advertisers, account managers, brand safety reviewers, and campaign directors. One person may hold both the account manager and the campaign director roles at the same time.

The resources are campaigns and creatives. Every campaign records its advertiser, the person who prepared it, its budget, its contingency amount, its budget tier, its risk labels, its scheduled start time, and its status. Every creative records the campaign it belongs to, the person who submitted it, its risk rating, its content tags, and its status.

A brand safety reviewer must not review a creative that they themselves submitted.

A brand safety reviewer may review a creative only when its status is pending review. If the creative is in any other status, such as draft or already launched, no brand safety reviewer may review it yet.

A brand safety reviewer may review a creative only when it carries a political content tag. For creatives that do not carry the political tag, no brand safety review is required before the creative can proceed.

A request by a brand safety reviewer who did not submit a pending, politically tagged creative to review it must be able to succeed.

# Order Picking then Zone Access — Emergency Overrides of Release and Clearance

## Natural-Language Scenario

The system manages warehouse zone access and order picking.

The people involved are pickers, forklift operators, zone supervisors, warehouse managers, and security officers, and one person may hold both the picker and forklift-operator roles at the same time.

The resources are orders and zones, where every order records who requested it, its picker, its items, its item count, its pick-list code, its status, its destination zone, and when it was released, and every zone records its zone code, its sensitivity, its zone group, whether it is locked, and its operational status.

Each request carries the current time, whether the associate is on-site with a badge, and whether an emergency has been declared.

In this workflow an order is first picked and then its destination zone is accessed, and the zone-access step can see the order's destination zone, its status, and its picker as recorded by the picking step.

A picker or a forklift operator may pick an order only after it has been released, and a request to pick an order that has not yet been released is refused.

When a stock-out emergency has been declared a warehouse manager may pick an order that has not yet been formally released, and when no such emergency has been declared an order that is not yet released may not be picked.

A picker, a forklift operator, or a zone supervisor may access a zone only when their badge clearance level is at least the zone's sensitivity, and one whose clearance does not reach it may not access the zone.

An associate may access a zone only when it belongs to a zone group they are assigned to, and a zone in a group they are not assigned to may not be accessed.

When a safety emergency has been declared a zone supervisor may enter a zone whose sensitivity is above their badge clearance, and when no such emergency has been declared a zone supervisor may not enter a zone above their clearance.

If these rules disagree, a declared emergency wins: it lets a warehouse manager pick an order not yet released, and it lets a zone supervisor enter a zone above their badge clearance.

Absent a declared emergency, neither a picker nor a forklift operator may pick an order that has not been released.

A run through the workflow in which a picker picks a released order and then accesses its destination zone, which belongs to a group they are assigned to and whose sensitivity is within their badge clearance, tripping no prohibition above, must be able to succeed.

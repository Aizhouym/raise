# Wire-Transfer Beneficiary Screening

## Natural-Language Scenario

The system manages beneficiary screening for bank wire transfers.

The people involved are originators, verifiers, treasury officers, and compliance reviewers. One person may hold both the originator and verifier role at the same time.

The resources are wire transfers and accounts. Every wire transfer records who initiated it, who verified it, who screened it, its account, amount, fee, amount tier, beneficiary, currency code, high-risk flag, and status.

Every account records its holder and its allowed beneficiaries.

Each requester carries an approval tier.

Each request carries the current time, the daily cutoff, whether it comes from a secure network, whether mfa was used, and whether an emergency has been declared.

A compliance reviewer or treasury officer may screen a beneficiary only while the wire transfer is still drafted.

If the beneficiary is already on the account's allowlist, the drafted-status requirement does not apply.

A compliance reviewer or treasury officer may screen a beneficiary only when the wire transfer carries a high-risk flag.

For a wire transfer that does not carry a high-risk flag, neither a compliance reviewer nor a treasury officer may screen the beneficiary.

A request by a compliance reviewer to screen a high-risk drafted wire transfer for a beneficiary that is not already on the account's allowlist must be able to succeed.
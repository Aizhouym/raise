# Cloud Resource Modification — Org Scope, Environment Gate, and Tag Exception

## Natural-Language Scenario

The system manages access to cloud infrastructure resources within an organization's cloud platform.

The people involved are owners, developers, operators, and org admins, and one person may hold both the owner and developer roles at the same time.

The resources are cloud resources, secrets, and org units.

Every cloud resource records its owner, the org unit it belongs to, its tags, its environment, and any temporary grant placed on it.

Every secret records the cloud resource it belongs to and when it was last rotated.

Every org unit records its parent org unit.

Each request carries the network address it originates from, whether multi-factor authentication was used, and how long the current session has lasted.

An owner, a developer, or an operator may modify a cloud resource only when the resource is outside the production environment.

When a resource has been promoted for release, an owner, a developer, or an operator may modify it even while it sits in the production environment.

An owner, a developer, or an operator may modify a cloud resource only when the requester belongs under the resource's org unit.

When the cloud resource carries the "public-sandbox" tag, an owner, a developer, or an operator may modify it even if the requester does not belong under the resource's org unit.

An owner, a developer, or an operator must not modify a cloud resource that sits in the production environment and has not been promoted.

A request by an owner to modify a cloud resource that is outside the production environment and that the owner belongs under the org unit of must be able to succeed.

# Student Record Viewing — Withdrawal, Self-Access, and Network/Time Gating

## Natural-Language Scenario

The system manages student records, grades, and courses for a university registrar's office.

The people involved are instructors, students, parents, and registrars, and one person may hold both the instructor and parent roles at the same time.

The resources are student records, grades, and courses; every student record records its student, advisor, the student's age, whether a FERPA directory-information block is set, and its status, and every grade records its student, course, the instructor who assigned it, and its status.

Each request carries the current date and whether it originates on the campus network.

A withdrawn student's record may be viewed only by the registrar.

An instructor, a student, or a parent must not view a withdrawn student's record.

A student may view their own record only when a FERPA directory-information block is set on that record; if no such block is set, the student may not view their own record.

A student may view their own record only when the request comes from the campus network; a request made off the campus network must not be allowed to view it.

A student may view their own record only when the request falls within a permitted viewing window; a request made outside that window must not be allowed to view it.

A request by an instructor to view a record that does not trip any of the prohibitions above must be able to succeed.

# Contract Review then Signature — Draft Gate, Authority, and Conflicts

## Natural-Language Scenario

The system manages the drafting, review, and signing of contracts through their lifecycle.

The people involved are drafters, reviewers, signatories, and contract admins. One person may hold the drafter and reviewer roles together, or the reviewer and signatory roles together, at the same time.

The resources are contracts and signatures. Every contract records its drafter, its reviewer, its counterparty, its contract value, its required authority level, its effective date, and its status. Every signature records the contract it is on, who signed it, and its amount.

Each request carries the current date, whether it comes from the corporate network, whether multi-factor authentication was used, and whether an escalation has been approved.

In this workflow a contract is first reviewed and then signed, and the signing step can see the contract's status, its drafter, and its reviewer as recorded by the review step.

A contract may be reviewed only while it is still in draft, and a request to review a contract that has left draft status is refused.

A signatory may sign a contract only when their signing authority reaches the contract's required authority level, and a request by a signatory whose authority falls short of that level is refused.

A signatory who is conflicted out against a contract's counterparty may not sign it, while a signatory who is not conflicted against that counterparty may sign it once their authority is sufficient.

A contract admin who is conflicted out against a contract's counterparty likewise may not sign it.

A run through the workflow that begins with a reviewer reviewing a draft contract and ends with a signatory of sufficient authority who is not conflicted against the counterparty signing it, tripping no prohibition above, must be able to succeed.

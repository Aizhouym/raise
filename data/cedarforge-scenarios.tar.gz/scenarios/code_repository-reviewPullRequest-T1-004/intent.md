# Repository Pull Request Review

## Natural-Language Scenario

The system manages source-code repository access.

The people involved are developers, reviewers, maintainers, and security leads. One person may hold both the developer and reviewer role at the same time.

The resources are repositories, pull requests, and branches. Every repository records its owner, team, sensitivity, whether its default branch is protected, its topics, and its status.

Every pull request records its repository, author, approvers, target branch, approval count, lines changed, whether it requires security review, and its status.

Every branch records its name and whether it is protected.

Each requester carries a clearance.

Each request carries the current time, whether the requester is on VPN, and whether break glass is being used.

A reviewer or maintainer may review a pull request only while it is open.

A reviewer must not review a pull request that is not open, and a maintainer must not review a pull request that is not open.

A request by a reviewer to review an open pull request that does not trip any prohibition above must be able to succeed.
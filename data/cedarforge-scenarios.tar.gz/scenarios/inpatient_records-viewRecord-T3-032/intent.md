# Inpatient Record Viewing

## Natural-Language Scenario

The system manages inpatient medical records and prescriptions.

The people involved are attending physicians, residents, nurses, and pharmacists. One person may hold both the attending physician and pharmacist roles, and one person may hold both the resident and pharmacist roles.

The resources are medical records, prescriptions, and lab orders. Every medical record records its patient, care team, ward, sensitivity, and status.

Each requester carries the areas they are cleared for and their ward.

Each request carries the current shift, whether an emergency has been declared, and whether MFA was used.

An attending physician, resident, or nurse may view a medical record only when their clearance is at least as high as the record's sensitivity.

An attending physician, resident, or nurse may view a medical record only when they are on that record's care team.

An attending physician, resident, or nurse who is not on the record's care team may not view it.

An attending physician, resident, or nurse may view a medical record only when the request is made during the current shift and MFA was used.

An attending physician, resident, or nurse must not view a medical record when the request is outside the current shift or MFA was not used.

A request by an attending physician to view a record that does not trip any prohibition above must be able to succeed.
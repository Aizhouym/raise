# Controlled-Substance Dispensing

## Natural-Language Scenario

The system manages outpatient dispensing of controlled-substance prescriptions.

The people involved are pharmacy technicians, staff pharmacists, pharmacists in charge, and prescribers. One person may hold both the staff pharmacist and pharmacist in charge role at the same time.

The resources are prescriptions and dispense records. Every prescription records its prescriber, patient, entered by person, verified by person, prescriber DEA, schedule level, refills remaining, and status, and every dispense record records its prescription, dispensed by person, quantity, and copay amount.

Each requester carries dispensing authority and a state license.

When the copay amount crosses the money threshold, a staff pharmacist or pharmacist in charge may dispense medication only if their dispensing authority is high enough for the prescription's DEA schedule level.

When the copay amount does not cross the money threshold, this dispensing-authority requirement does not block the medication from being dispensed.

A staff pharmacist or pharmacist in charge must not dispense medication when the copay amount crosses the money threshold and their dispensing authority is not high enough for the prescription's DEA schedule level.

A request by a staff pharmacist to dispense a medication that does not trip any prohibition above must be able to succeed.
# Folio Adjustment Approval

## Natural-Language Scenario

The system manages guest folio adjustment posting and approval.

The people involved are front desk agents, night auditors, accounting clerks, revenue managers, and auditors. One person may hold both the front desk agent and night auditor roles, and one person may hold both the accounting clerk and revenue manager roles.

The resources are folios and credit notes. Every folio records its guest, who posted it, who approved it, its folio balance, adjustment amount, original charge, line item count, folio code, dispute category, property region, guest segment, charges, VIP flag, status, and checkout deadline.

Each request carries the current time, whether it is on the property network, whether the dispute is verified, and whether a general manager override has been declared.

An accounting clerk or revenue manager may approve an adjustment only after the folio has reached adjustment-posted status.

When the folio code carries a controlled property prefix, the adjustment may be approved even if the folio has not reached adjustment-posted status.

Neither an accounting clerk nor a revenue manager may approve an adjustment before it has been posted unless the folio code carries a controlled property prefix.

A request by an accounting clerk to approve an adjustment that does not trip any prohibition above must be able to succeed.